package pw.sentire.client.utility;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.item.Item;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.UseAction;
import pw.sentire.client.Main;

import java.util.Arrays;

public class InventoryUtility {
    public static int HOTBAR_OFFSET = 8 + 27;

    public static int findSlotInMain(Item... items) {
        if (Main.mc.player != null) {
            for (var ref = new Object() {
                int i = 9;
            }; ref.i < 36; ref.i++) {
                if (Arrays.stream(items).anyMatch(item -> item == Main.mc.player.getInventory().getStack(ref.i).getItem())) {
                    return ref.i;
                }
            }
        }
        return -1;
    }

    public static int findSlotInHotbar(Item... items) {
        if (Main.mc.player != null) {
            for (var ref = new Object() {
                int i = 0;
            }; ref.i < 9; ref.i++) {
                if (Arrays.stream(items).anyMatch(item -> item == Main.mc.player.getInventory().getStack(ref.i).getItem())) {
                    return ref.i;
                }
            }
        }
        return -1;
    }

    public static int findSlotInMainOrHotbar(Item... items) {
        var ref1 = new Object() {
            int i = -1;
        };
        if (Main.mc.player != null) {
            for (var ref = new Object() {
                int i = 0;
            }; ref.i < Main.mc.player.playerScreenHandler.slots.size(); ref.i++) {
                if (Arrays.stream(items).anyMatch(item -> item == Main.mc.player.getInventory().getStack(ref.i).getItem())) {
                    ref1.i = Main.mc.player.playerScreenHandler.slots.get(ref.i).id;
                }
            }
        }
        return ref1.i;
    }

    public static int findBlocksInHotbar() {
        var ref1 = new Object() {
            int i = -1;
        };
        if (Main.mc.player != null) {
            for (var ref = new Object() {
                int i = HOTBAR_OFFSET;
            }; ref.i < Main.mc.player.playerScreenHandler.slots.size() - 1; ref.i++) {
                if (Main.mc.player.playerScreenHandler.slots.get(ref.i).getStack().getUseAction() == UseAction.BLOCK) {
                    ref1.i = Main.mc.player.playerScreenHandler.slots.get(ref.i).id;
                }
            }
        }
        return ref1.i;
    }

    public static int findBlocksInMain() {
        var ref1 = new Object() {
            int i = -1;
        };
        if (Main.mc.player != null) {
            for (var ref = new Object() {
                int i = 8;
            }; ref.i < Main.mc.player.playerScreenHandler.slots.size() - 10; ref.i++) {
                if (Main.mc.player.playerScreenHandler.slots.get(ref.i).getStack().getUseAction() == UseAction.BLOCK) {
                    ref1.i = Main.mc.player.playerScreenHandler.slots.get(ref.i).id;
                }
            }
        }
        return ref1.i;
    }

    public static void moveItem(int from, int to) {
        PlayerScreenHandler handler = Main.mc.player.playerScreenHandler;
        ClientPlayerInteractionManager interact = Main.mc.interactionManager;
        interact.clickSlot(handler.syncId, from, 0, SlotActionType.PICKUP, Main.mc.player);
        interact.clickSlot(handler.syncId, to, 0, SlotActionType.PICKUP, Main.mc.player);
        if (!handler.getCursorStack().isEmpty()) {
            if (Main.mc.player.getInventory().getEmptySlot() != -1) {
                interact.clickSlot(handler.syncId, from, 0, SlotActionType.PICKUP, Main.mc.player);
            } else {
                interact.clickSlot(handler.syncId, -999, 0, SlotActionType.THROW, Main.mc.player);
            }
        }
    }
}
