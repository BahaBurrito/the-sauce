package pw.sentire.client.events.utility;

import lombok.Getter;
import net.minecraft.entity.Entity;
import pw.sentire.client.events.Event;

import java.util.Optional;

@Getter
public class TickEvent extends Event {
    private final Type type;
    private Entity entity;

    public TickEvent(Type type, Optional<Entity> entity) {
        super(false, "tick-event");
        this.type = type;
        if (entity.isPresent()) this.entity = entity.get();
    }

    public enum Type {
        CLIENT_PLAYER,
        PLAYER,
        ENTITY,
        WORLD
    }
}
