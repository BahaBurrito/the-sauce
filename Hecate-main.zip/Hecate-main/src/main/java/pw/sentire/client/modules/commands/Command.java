package pw.sentire.client.modules.commands;

public class Command {
}
