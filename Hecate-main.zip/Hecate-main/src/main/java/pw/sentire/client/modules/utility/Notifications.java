package pw.sentire.client.modules.utility;

import pw.sentire.client.modules.Category;
import pw.sentire.client.modules.Module;

public class Notifications extends Module {
    public Notifications() {
        super("notifications", Category.MISC, true);
        this.setTooltip("Shows notifications.");
    }
}
