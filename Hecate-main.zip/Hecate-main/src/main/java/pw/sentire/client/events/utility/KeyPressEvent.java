package pw.sentire.client.events.utility;

import lombok.Getter;
import pw.sentire.client.events.Event;

@Getter
public class KeyPressEvent extends Event {
    private final int key, action;

    public KeyPressEvent(int key, int action) {
        super(true, "key-press");
        this.key = key;
        this.action = action;
    }
}
