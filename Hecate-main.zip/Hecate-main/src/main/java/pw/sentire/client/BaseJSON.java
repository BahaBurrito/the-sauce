package pw.sentire.client;

public class BaseJSON {
}
