package pw.sentire.client.modules;

import lombok.Getter;
import net.minecraft.client.MinecraftClient;
import pw.sentire.client.Main;
import pw.sentire.client.gui.widgets.HecateWidget;
import pw.sentire.client.modules.options.*;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

@Getter
public class Module {
    public static boolean statActive;
    public final MinecraftClient mc = Main.mc;
    private final String name;
    private final Category category;
    private final List<DefOption<?>> options = new ArrayList<>();
    private boolean active, visible = true;
    private String tooltip = "";

    public Module(String name, Category category, boolean active) {
        this.name = name;
        this.category = category;
        this.active = active;
        statActive = active;
    }

    public void onClick(HecateWidget button) {
        Main.log.info(MessageFormat.format("[{0}] was set to {1}", name, active));
        Main.notificationWidget.notify(this, "was " + (active ? "activated." : "disabled."));
    }

    public Module addOption(DefOption<?> option) {
        if (!this.options.contains(option)) {
            this.options.add(option);
        }
        return this;
    }

    public Module setActive(boolean val) {
        this.active = val;
        statActive = active;
        Main.config.updateActivity(this);
        return this;
    }

    public Module setVisible(boolean val) {
        this.visible = val;
        statActive = active;
        return this;
    }

    public void loadConfig() {
        this.setActive(Main.config.isActive(this));
        this.getOptions().forEach((opt) -> {
            switch (opt.getType()) {
                case INT:
                    ((IntOption) opt).setValue(Main.config.getInt(this, (IntOption) opt, ((IntOption) opt).getValue()));
                    break;
                case BOOLEAN:
                    ((BooleanOption) opt).setValue(Main.config.getBoolean(this, (BooleanOption) opt, ((BooleanOption) opt).getValue()));
                    break;
                case FLOAT:
                    ((FloatOption) opt).setValue(Main.config.getFloat(this, (FloatOption) opt, ((FloatOption) opt).getValue()));
                    break;
                case STRING:
                    ((StringOption) opt).setValue(Main.config.getString(this, (StringOption) opt, ((StringOption) opt).getValue()));
                    break;
            }
        });
    }

    public Module setTooltip(String tooltip) {
        this.tooltip = tooltip;
        return this;
    }
}
