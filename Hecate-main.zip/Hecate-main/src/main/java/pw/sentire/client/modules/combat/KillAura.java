package pw.sentire.client.modules.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import pw.sentire.client.events.EventDefiner;
import pw.sentire.client.events.EventListener;
import pw.sentire.client.events.utility.TickEvent;
import pw.sentire.client.modules.Category;
import pw.sentire.client.modules.Module;
import pw.sentire.client.modules.options.BooleanOption;
import pw.sentire.client.modules.options.FloatOption;
import pw.sentire.client.modules.options.IntOption;
import pw.sentire.client.utility.EntityUtility;
import pw.sentire.client.utility.Friends;

import java.util.Comparator;
import java.util.List;

@EventListener
public class KillAura extends Module {
    public FloatOption distance = new FloatOption("distance", 4.5f, 0.5f, 6.5f, 1, "The distance to hit an entity from.");
    public BooleanOption attackDelay = new BooleanOption("weapon-cooldown", true, "Whether or not to attack wait for weapon cooldown, overwrites tick delay.");
    public BooleanOption players = new BooleanOption("attack-players", true, "Whether or not to attack other players.");
    public BooleanOption friends = new BooleanOption("attack-friends", false, "Whether or not to attack friends.");
    public BooleanOption pets = new BooleanOption("attack-pets", false, "Whether or not to attack pets.");
    public BooleanOption passives = new BooleanOption("attack-passives", false, "Whether or not to attack passive entities.");
    public BooleanOption neutrals = new BooleanOption("attack-neutrals", false, "Whether or not to attack neutral entities.");
    public BooleanOption hostiles = new BooleanOption("attack-hostiles", true, "Whether or not to attack hostile entities.");
    public BooleanOption explosives = new BooleanOption("attack-explosives", true, "Whether or not to attack animate explosive entities.");
    public BooleanOption rideable = new BooleanOption("attack-rideable", false, "Whether or not to attack rideable mobs.");
    public BooleanOption attackLowest = new BooleanOption("attack-lowest", false, "Whether or not to attack the entity with the lowest health, otherwise the closest.");
    public BooleanOption attackFurthest = new BooleanOption("attack-furthest", false, "Whether or not to attack the furthest entity, priority under Attack Lowest.");
    public IntOption tickDelay = new IntOption("tick-delay", 20, 1, 320, "Tick Delay to function, TLDR; the tick type is world.");
    public int ticksPassed = 0;

    public KillAura() {
        super("kill-aura", Category.COMBAT, false);
        this.addOption(distance)
                .addOption(attackDelay)
                .addOption(players)
                .addOption(friends)
                .addOption(pets)
                .addOption(passives)
                .addOption(neutrals)
                .addOption(hostiles)
                .addOption(explosives)
                .addOption(rideable)
                .addOption(attackLowest)
                .addOption(attackFurthest)
                .addOption(tickDelay);
        this.setTooltip("Automatically hit entities in the radius.");
    }

    @EventDefiner
    public void onTick(TickEvent event) {
        if (event.getType() == TickEvent.Type.WORLD && mc.player != null) {
            if (attackDelay.getValue() && mc.player.getAttackCooldownProgress(0.5f) < 1) return;
            else {
                if (tickDelay.getValue() > ticksPassed) {
                    ticksPassed = 0;
                } else {
                    ticksPassed++;
                    return;
                }
            }
            List<Entity> entities = mc.player.world.getOtherEntities(mc.player, new Box(mc.player.getPos().add(distance.getValue(), distance.getValue(), distance.getValue()), mc.player.getPos().add(-distance.getValue(), -distance.getValue(), -distance.getValue())), entity -> {
                EntityUtility.TypeOfEntity type = EntityUtility.getType(entity);
                if (type == EntityUtility.TypeOfEntity.UNKNOWN) return false;
                if (!entity.getPos().isInRange(mc.player.getPos(), distance.getValue()) ||
                        entity.distanceTo(mc.player) > distance.getValue()) return false;
                if (type == EntityUtility.TypeOfEntity.SELF) return false;
                if (!pets.getValue() && type == EntityUtility.TypeOfEntity.PET) return false;
                if (!rideable.getValue() && type == EntityUtility.TypeOfEntity.RIDEABLE) return false;
                if (!neutrals.getValue() && type == EntityUtility.TypeOfEntity.NEUTRAL) return false;
                if ((!passives.getValue() && type == EntityUtility.TypeOfEntity.PASSIVE)
                        || (!hostiles.getValue() && type == EntityUtility.TypeOfEntity.HOSTILE))
                    return false;
                if (!players.getValue() && type == EntityUtility.TypeOfEntity.PLAYER) return false;
                if (friends.getValue() && type == EntityUtility.TypeOfEntity.PLAYER && Friends.isFriend(entity.getName().asString())) return false;
                if (!explosives.getValue() && type == EntityUtility.TypeOfEntity.EXPLOSION) return false;
                return true;
            });

            entities.sort(Comparator.comparingDouble(o -> attackLowest.getValue() ? (o instanceof LivingEntity ? ((LivingEntity) o).getHealth() : 0) : o.distanceTo(mc.player)));
            if (!entities.isEmpty() && entities.get(Math.min(entities.size() - 1, 0)) != null) {
                mc.getNetworkHandler().sendPacket(PlayerInteractEntityC2SPacket.attack(entities.get((attackFurthest.getValue() && !attackLowest.getValue() ? 0 : Math.min(0, entities.size() - 1))), false));
                mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
                mc.player.resetLastAttackedTicks();
            }
        }
    }


}
