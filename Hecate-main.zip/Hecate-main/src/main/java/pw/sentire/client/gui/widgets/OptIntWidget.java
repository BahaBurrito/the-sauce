package pw.sentire.client.gui.widgets;

import lombok.Setter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import pw.sentire.client.Main;
import pw.sentire.client.modules.options.IntOption;
import pw.sentire.client.utility.StringUtility;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.regex.Pattern;

public class OptIntWidget extends DefOptionWidget<IntOption> {
    private final Pattern pattern = Pattern.compile("[^0-9]");
    private final int maxLength;
    public int value;
    private boolean needsPurified = false;
    @Setter
    private LiteralText text;
    @Setter
    private String typedText;

    public OptIntWidget(int x, int y, IntOption option) {
        super(x, y, option);
        this.setSelectable(true);
        this.typedText = option.getValue().toString();
        this.text = new LiteralText(StringUtility.prettify(option.getName()));
        this.value = option.getValue();
        this.maxLength = Integer.toString(option.getMax()).length() - 1;
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        if (!isFocused()) {
            if (needsPurified) {
                this.save();
            }
        }
        if (!isVisible()) return;
        super.render(matrices, mouseX, mouseY, delta);
        drawTextWithShadow(matrices, Main.mc.textRenderer, text, x + 5, y + 5, DefHecateWidget.textColor.getRGB());
        drawTextWithShadow(matrices, Main.mc.textRenderer, new LiteralText(typedText), x + 75, y + 10, Color.LIGHT_GRAY.getRGB());
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!this.isFocused()) return false;
        if (!typedText.equals("") && (keyCode == 259 || keyCode == 261)) {
            if (typedText.length() > 0) {
                typedText = this.typedText.substring(0, typedText.length() - 1);
            } else {
                typedText = "";
            }
            needsPurified = true;
            return true;
        } else {
            String character = KeyEvent.getKeyText(keyCode);
            if (typedText.length() > maxLength) return true;
            if (!pattern.matcher(character).find()) {
                typedText += character;
                needsPurified = true;
            }
            return true;
        }
    }

    @Override
    public void save() {
        if (needsPurified) {
            if (typedText.equals("")) typedText = Integer.toString(option.getMax());
            value = Math.min(Integer.parseInt(typedText), option.getMax());
            option.setValue(value);
            typedText = String.valueOf(value);
            needsPurified = false;
        }
    }
}
