package pw.sentire.client.modules;

public enum Category {
    COMBAT,
    MOVEMENT,
    RENDER,
    PLAYER,
    MISC,
    CATS,
    HIDDEN
}
