package pw.sentire.client.modules.utility;

import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import pw.sentire.client.events.EventDefiner;
import pw.sentire.client.events.EventListener;
import pw.sentire.client.events.utility.MouseClickEvent;
import pw.sentire.client.modules.Category;
import pw.sentire.client.modules.Module;
import pw.sentire.client.utility.Friends;

@EventListener
public class MidClickFriend extends Module {
    public MidClickFriend() {
        super("add-friends", Category.MISC, true);
        this.setTooltip("Add friends via middle clicking.");
    }

    @EventDefiner
    public void onMouseClick(MouseClickEvent event) {
        if (event.getAction() == 1) {
            if (mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
                Vec3d pos = mc.crosshairTarget.getPos();
                Friends.friendAOR(mc.player.world.getClosestPlayer(pos.x, pos.y, pos.z, 1, true).getName().asString());
            }
        }
    }
}
