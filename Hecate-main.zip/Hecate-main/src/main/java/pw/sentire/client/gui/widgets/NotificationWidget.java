package pw.sentire.client.gui.widgets;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Text;
import pw.sentire.client.Main;
import pw.sentire.client.modules.Module;
import pw.sentire.client.utility.StringUtility;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public class NotificationWidget extends DefHecateWidget {
    public List<Text> notifications = new ArrayList<>();

    public NotificationWidget() {
        super(Main.mc.getWindow().getScaledWidth() - 200, Main.mc.getWindow().getScaledHeight() - 40);
        this.width = 200;
        this.height = 40;
        this.setSelectable(true);
    }

    public void render(MatrixStack matrices, float delta) {
        if (!isVisible()) return;
        this.x = Main.mc.getWindow().getScaledWidth() - 200;
        this.y = Main.mc.getWindow().getScaledHeight() - 40;
        for (int i = 0; i < notifications.size(); i++) {
            drawTextWithShadow(matrices, Main.mc.textRenderer, notifications.get(i), x + 4, y + 2 + (12 * i), DefHecateWidget.textColor.getRGB());
        }
    }

    @Override
    public void onClick() {
        this.setVisible(false);
        this.notifications.clear();
    }

    public void notify(Module module, String str) {
        if (notifications.size() >= 3) {
            notifications.remove(notifications.get(notifications.size() - 1));
        }

        notifications.add(0, new LiteralText(MessageFormat.format("[{0}] {1}", StringUtility.prettify(module.getName()), str)));
    }
}
