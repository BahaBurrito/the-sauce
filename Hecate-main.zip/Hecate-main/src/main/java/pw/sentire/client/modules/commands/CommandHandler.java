package pw.sentire.client.modules.commands;

public class CommandHandler {
    public void register(Module module) {

    }
}
