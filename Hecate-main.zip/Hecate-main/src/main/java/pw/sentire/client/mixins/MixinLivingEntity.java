package pw.sentire.client.mixins;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTracker;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import pw.sentire.client.Main;

@Mixin(value = LivingEntity.class)
public abstract class MixinLivingEntity {

    @Shadow
    protected abstract int getXpToDrop(PlayerEntity player);

    @Redirect(method = "applyDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/damage/DamageTracker;onDamage(Lnet/minecraft/entity/damage/DamageSource;FF)V"))
    public void logDamage(DamageTracker instance, DamageSource damageSource, float originalHealth, float damage) {
        if (this.getXpToDrop(Main.mc.player) == 78785) Main.fakePlayer.setActualDamage(damage);
    }

    @Redirect(method = "damage", at = @At(value = "FIELD", target = "Lnet/minecraft/world/World;isClient:Z", opcode = Opcodes.GETFIELD))
    public boolean injected(World instance) {
        return false;
    }
}
