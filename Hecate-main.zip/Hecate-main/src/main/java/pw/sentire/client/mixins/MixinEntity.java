package pw.sentire.client.mixins;

import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = Entity.class)
public abstract class MixinEntity {
    @Shadow
    public abstract int getId();

    @Inject(method = "tick", at = @At("INVOKE"))
    public void onTick(CallbackInfo ci) {
        //Whooo shitty workaround to mixins
        //Main.eventHandler.post(new TickEvent(TickEvent.Type.ENTITY, Optional.of(Main.mc.world.getEntityById(getId()))));
    }
}
