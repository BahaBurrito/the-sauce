package pw.sentire.client.utility;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.passive.*;
import net.minecraft.util.registry.Registry;
import pw.sentire.client.Main;

import java.util.Objects;

public class EntityUtility {
    public static TypeOfEntity getType(Entity entity) {
        switch (Registry.ENTITY_TYPE.getId(entity.getType()).getPath()) {
            case "creeper":
                if (((CreeperEntity) entity).isIgnited()) return TypeOfEntity.EXPLOSION;
            case "tnt":
                return TypeOfEntity.EXPLOSION_INANIMATE;
            case "end_crystal":
                return TypeOfEntity.EXPLOSION;
            case "llama":
                if (((LlamaEntity) entity).isAngry()) return TypeOfEntity.HOSTILE;
                return TypeOfEntity.RIDEABLE;
            case "wolf":
                if (((WolfEntity) entity).getOwnerUuid() != null && ((WolfEntity) entity).getOwnerUuid() == Main.mc.player.getUuid()) return TypeOfEntity.PET;
                if (((WolfEntity) entity).getAngryAt() == Main.mc.player.getUuid())
                    return TypeOfEntity.HOSTILE;
                return TypeOfEntity.NEUTRAL;
            case "cat":
                if (((CatEntity) entity).getOwnerUuid() != null) return TypeOfEntity.PET;
                return TypeOfEntity.PASSIVE;
            case "enderman":
                if (((EndermanEntity) entity).isProvoked() && ((EndermanEntity) entity).getAngryAt() == Objects.requireNonNull(Main.mc.player).getUuid())
                    return TypeOfEntity.HOSTILE;
                return TypeOfEntity.NEUTRAL;
            case "pig":
                if (((PigEntity) entity).isSaddled()) return TypeOfEntity.RIDEABLE;
                return TypeOfEntity.PASSIVE;
            case "mule":
            case "donkey":
            case "skeleton_horse":
            case "zombie_horse":
            case "horse":
                if (((HorseBaseEntity) entity).getOwnerUuid() != null) return TypeOfEntity.PET;
                return TypeOfEntity.RIDEABLE;
            case "minecart":
            case "boat":
                return TypeOfEntity.RIDEABLE;
            default:
                if (!entity.isAlive() && entity.isLiving() && ((LivingEntity) entity).getHealth() <= 0)
                    return TypeOfEntity.UNKNOWN;
                if (entity.isPlayer()) {
                    if (entity.getUuid() == Objects.requireNonNull(Main.mc.player).getUuid()) return TypeOfEntity.SELF;
                    return TypeOfEntity.PLAYER;
                }

                if (!entity.isAttackable()) {
                    return TypeOfEntity.INANIMATE;
                }

                if (entity.getType().getSpawnGroup().isPeaceful()) {
                    return TypeOfEntity.PASSIVE;
                } else {
                    return TypeOfEntity.HOSTILE;
                }
        }
    }

    public enum TypeOfEntity {
        RIDEABLE,
        NEUTRAL,
        PASSIVE,
        HOSTILE,
        INANIMATE,
        EXPLOSION_INANIMATE,
        EXPLOSION,
        UNKNOWN,
        PLAYER,
        PET,
        SELF
    }
}
