package pw.sentire.client.gui.widgets;

import lombok.Getter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import pw.sentire.client.Main;
import pw.sentire.client.gui.Menu;
import pw.sentire.client.modules.Category;
import pw.sentire.client.utility.StringUtility;

@Getter
public class CategoryWidget extends DefHecateWidget {
    private final Category category;

    public CategoryWidget(int x, int y, Category category) {
        super(x, y);
        this.category = category;
        this.setText(new LiteralText(StringUtility.prettify(category.name())));
    }

    @Override
    public void onClick() {
        Menu.currentCategory = category;
        Menu.categories.values().forEach(widgets -> widgets.forEach(toggleWidget -> toggleWidget.setVisible(toggleWidget.getModule().getCategory() == (Menu.ghostCategory != Category.HIDDEN ? Menu.ghostCategory : Menu.currentCategory))));
    }

    public void ratHovered(double mouseX, double mouseY) {
        this.setHovered(mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height);
    }

    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        super.render(matrices, mouseX, mouseY, delta);
        drawTextWithShadow(matrices, Main.mc.textRenderer, this.getText(), x + 4, y + 7, DefHecateWidget.textColor.getRGB());
    }

    public void onMouseMoved(double mouseX, double mouseY) {
        if (this.isHovered()) {
            if (Menu.ghostCategory != category) {
                Menu.ghostCategory = category == Menu.currentCategory ? Category.HIDDEN : category;
                Menu.categories.values().forEach(widgets -> widgets.forEach(toggleWidget -> toggleWidget.setVisible(toggleWidget.getModule().getCategory() == (Menu.ghostCategory != Category.HIDDEN ? Menu.ghostCategory : Menu.currentCategory))));
            }
        } else if (mouseX > x + width || mouseY > height * Menu.categoryWidgets.size() + 1) {
            Menu.ghostCategory = Category.HIDDEN;
            Menu.categories.values().forEach(widgets -> widgets.forEach(toggleWidget -> toggleWidget.setVisible(toggleWidget.getModule().getCategory() == (Menu.ghostCategory != Category.HIDDEN ? Menu.ghostCategory : Menu.currentCategory))));
        }
    }
}
