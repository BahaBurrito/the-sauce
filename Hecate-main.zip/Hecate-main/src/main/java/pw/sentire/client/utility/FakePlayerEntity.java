package pw.sentire.client.utility;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.explosion.Explosion;
import pw.sentire.client.Main;

public class FakePlayerEntity extends LivingEntity {
    public static LivingEntity mockEntity;
    public float actualDamage = 0f;

    public FakePlayerEntity() {
        super(EntityType.CREEPER, Main.mc.player.world);

    }

    @Override
    public int getXpToDrop(PlayerEntity entity) {
        return 78785;
    }

    @Override
    public boolean isImmuneToExplosion() {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource damageSource) {
        return false;
    }

    @Override
    public float getAbsorptionAmount() {
        return 0;
    }

    @Override
    public Iterable<ItemStack> getArmorItems() {
        return (mockEntity != null ? mockEntity.getArmorItems() : Main.mc.player.getArmorItems());
    }

    @Override
    public int getArmor() {
        return (mockEntity != null ? mockEntity.getArmor() : Main.mc.player.getArmor());
    }

    @Override
    public ItemStack getEquippedStack(EquipmentSlot slot) {
        return (mockEntity != null ? mockEntity.getEquippedStack(slot) : Main.mc.player.getEquippedStack(slot));
    }

    @Override
    public void equipStack(EquipmentSlot slot, ItemStack stack) {

    }

    @Override
    public void onDeath(DamageSource source) {
        this.setHealth(20);
        if (this.isRemoved()) this.unsetRemoved();

    }


    @Override
    public boolean isDead() {
        this.setHealth(20);
        this.dead = false;
        return false;
    }

    @Override
    public Arm getMainArm() {
        return Main.mc.player.getMainArm();
    }

    public void setActualDamage(float f) {
        this.actualDamage = f;
    }

    @Override
    public boolean isAlive() {
        this.setHealth(20);
        return true;
    }

    public float getExplosionDamage(Vec3d pos, Entity entity2, int power) {
        return getExplosionDamage(pos, entity2, power, false, 0);
    }

    public float getExplosionDamage(Vec3d pos, Entity entity2, float power, boolean wfr, int wfrt) {
        if (wfr && Main.mc.player.timeUntilRegen > wfrt) {
            return 0f;
        }
        mockEntity = (LivingEntity) entity2;
        this.lastDamageTaken = 0;
        this.timeUntilRegen = 0;
        this.dead = false;
        this.setPosition(entity2.getPos().x, entity2.getPos().y, entity2.getPos().z);
        Explosion explosion = new Explosion(world, null, pos.getX(), pos.getY(), pos.getZ(), power, true, Explosion.DestructionType.NONE);
        explosion.collectBlocksAndDamageEntities();
        explosion.clearAffectedBlocks();
        this.knockbackVelocity = 0;

        return this.actualDamage;
    }
}
