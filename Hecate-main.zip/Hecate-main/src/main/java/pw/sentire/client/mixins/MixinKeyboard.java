package pw.sentire.client.mixins;

import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pw.sentire.client.Main;
import pw.sentire.client.events.Event;
import pw.sentire.client.events.utility.KeyPressEvent;

@Mixin(value = Keyboard.class, priority = Integer.MAX_VALUE)
public class MixinKeyboard {
    @Inject(method = "onKey", at = @At("HEAD"), cancellable = true)
    public void keyEvent(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (Main.mc.currentScreen == Main.getOptionsMenu() || Main.mc.currentScreen == Main.getMenu()) return;
        Event event = Main.eventHandler.post(new KeyPressEvent(key, action));
        if (event.isCancelled()) ci.cancel();
    }
}
