package pw.sentire.client.utility;

import lombok.Getter;

import java.util.List;

@Getter
public class UUIDLock {
    private List<String> uuids;
    private boolean hardLock;
}
