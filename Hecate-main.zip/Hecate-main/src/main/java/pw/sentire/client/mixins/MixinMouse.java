package pw.sentire.client.mixins;

import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pw.sentire.client.Main;
import pw.sentire.client.events.Event;
import pw.sentire.client.events.utility.MouseClickEvent;

@Mixin(value = Mouse.class)
public class MixinMouse {
    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    public void mouseClickEvent(long window, int button, int action, int mods, CallbackInfo ci) {
        if (window == Main.mc.getWindow().getHandle() &&
                Main.mc.currentScreen == null) {
            Event event = new MouseClickEvent(button, action);
            Main.eventHandler.post(event);
            if (event.isCancelled()) ci.cancel();
        }
    }
}
