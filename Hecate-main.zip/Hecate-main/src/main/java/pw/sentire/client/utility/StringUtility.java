package pw.sentire.client.utility;

import net.minecraft.text.LiteralText;
import pw.sentire.client.modules.Module;

import java.util.Locale;

public class StringUtility {
    public static String prettify(String ostr) {
        String nstr = "";
        if (ostr.contains("-")) {
            for (String str : ostr.split("-")) {
                String first = str.split("")[0];
                nstr += str.replaceFirst(first, first.toUpperCase(Locale.ROOT)) + "-";
            }
        } else {
            nstr = ostr.toLowerCase(Locale.ROOT);
            String first = nstr.split("")[0];
            nstr = nstr.replaceFirst(first, first.toUpperCase(Locale.ROOT));
        }

        nstr = nstr.replaceAll("-", " ");
        nstr = nstr.trim();

        return nstr;
    }

    public static LiteralText getModuleLT(Module module) {
        return new LiteralText((module.isActive() ? ">" : "<") + prettify(module.getName()));
    }
}
