package pw.sentire.client.events.utility;

import lombok.Getter;
import net.minecraft.network.Packet;
import pw.sentire.client.events.Event;

@Getter
public class PacketEvent extends Event {
    private final Packet<?> packet;
    private final Type type;

    public PacketEvent(Packet<?> packet, Type type) {
        super(true, "packet-event");
        this.packet = packet;
        this.type = type;
    }

    public enum Type {
        SENT,
        RECEIVED
    }
}
