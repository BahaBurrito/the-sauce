package pw.sentire.client.gui.widgets;

import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import pw.sentire.client.Main;
import pw.sentire.client.gui.OptionsMenu;
import pw.sentire.client.modules.options.BooleanOption;
import pw.sentire.client.utility.StringUtility;

@Getter
public class OptBooleanWidget extends DefOptionWidget<BooleanOption> {
    @Setter
    private LiteralText text;
    @Setter
    private int color = DefHecateWidget.textColor.getRGB();

    public OptBooleanWidget(int x, int y, BooleanOption option) {
        super(x, y, option);
        this.text = new LiteralText(StringUtility.prettify(option.getName()));
        if (option.getValue()) this.setColor(HecateWidget.activatedColor.getRGB());
        else this.setColor(HecateWidget.disabledColor.getRGB());
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        if (!isVisible()) return;
        super.render(matrices, mouseX, mouseY, delta);
        drawTextWithShadow(matrices, Main.mc.textRenderer, text, x + 4, y + 7, color);
    }

    @Override
    public void onMiddleClick() {
        this.onClick();
    }

    @Override
    public void onRightClick() {
        this.onClick();
    }

    @Override
    public void onClick() {
        Main.config.setValue(OptionsMenu.module, option);
        option.setValue(!option.getValue());
        if (option.getValue()) this.setColor(HecateWidget.activatedColor.getRGB());
        else this.setColor(HecateWidget.disabledColor.getRGB());
    }
}