package pw.sentire.client.utility;

import com.google.gson.Gson;
import lombok.Getter;
import lombok.Setter;
import pw.sentire.client.Main;
import pw.sentire.client.modules.Module;
import pw.sentire.client.modules.options.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
public class Config {
    private final int clickGui = 92;
    private final int prefix = 46;
    private final Map<String, Map<String, Object>> modules = new HashMap<>();
    private final Map<String, Integer> keybindings = new HashMap<>();
    @Setter
    private boolean changed = false;
    private List<String> friendsUUID = new ArrayList<>();
    private List<String> friendsName = new ArrayList<>();

    public boolean isActive(Module module) {
        if (!modules.containsKey(module.getName())) {
            modules.put(module.getName(), new HashMap<>());
            modules.get(module.getName()).put("active", module.isActive());
            changed = true;
        }

        return (boolean) modules.get(module.getName()).get("active");
    }

    public void updateActivity(Module module) {
        if (!modules.containsKey(module.getName())) modules.put(module.getName(), new HashMap<>());
        modules.get(module.getName()).put("active", module.isActive());
        changed = true;
    }

    public boolean getBoolean(Module module, BooleanOption option, boolean def) {
        if (!modules.containsKey(module.getName())) modules.put(module.getName(), new HashMap<>());
        if (modules.get(module.getName()).containsKey(option.getName()))
            return (boolean) modules.get(module.getName()).get(option.getName());
        else {
            modules.get(module.getName()).put(option.getName(), def);
            changed = true;
        }
        return def;
    }

    public boolean getBoolean(Module module, BooleanOption option) {
        return this.getBoolean(module, option, false);
    }

    public int getInt(Module module, IntOption option, int def) {
        if (!modules.containsKey(module.getName())) modules.put(module.getName(), new HashMap<>());
        if (modules.get(module.getName()).containsKey(option.getName()))
            return (int) Math.round((double) modules.get(module.getName()).get(option.getName()));
        else {
            modules.get(module.getName()).put(option.getName(), def);
            changed = true;
        }
        return def;
    }

    public int getInt(Module module, IntOption option) {
        return this.getInt(module, option, 0);
    }

    public float getFloat(Module module, FloatOption option, float def) {
        if (!modules.containsKey(module.getName())) modules.put(module.getName(), new HashMap<>());
        if (modules.get(module.getName()).containsKey(option.getName()))
            return Float.parseFloat(modules.get(module.getName()).get(option.getName()).toString());
        else {
            modules.get(module.getName()).put(option.getName(), def);
            changed = true;
        }
        return def;
    }

    public float getFloat(Module module, FloatOption option) {
        return this.getFloat(module, option, 0f);
    }

    public String getString(Module module, StringOption option, String def) {
        if (!modules.containsKey(module.getName())) modules.put(module.getName(), new HashMap<>());
        if (modules.get(module.getName()).containsKey(option.getName()))
            return (String) modules.get(module.getName()).get(option.getName());
        else {
            modules.get(module.getName()).put(option.getName(), def);
            changed = true;
        }
        return def;
    }

    public void setValue(Module module, DefOption option) {
        if (!modules.containsKey(module.getName())) modules.put(module.getName(), new HashMap<>());
        modules.get(module.getName()).put(option.getName(), option.getValue());
        changed = true;
    }

    public String getString(Module module, StringOption option) {
        return this.getString(module, option, "");
    }

    public int getKeybind(Module module) {
        if (keybindings.containsKey(module.getName())) return keybindings.get(module.getName());
        return 0;
    }

    public void setKeybind(Module module, int key) {
        keybindings.put(module.getName(), key);
        changed = true;
    }

    public void save() {
        if (this.isChanged()) {
            this.setChanged(false);
            Main.modules.get().forEach(module -> module.getOptions().forEach((defOption -> this.setValue(module, defOption))));
            try {
                Fs.write(System.getProperty("user.dir") + "/config", "hecate.json", new Gson().toJson(Main.config));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}