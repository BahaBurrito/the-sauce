package pw.sentire.client.mixins;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value = MinecraftClient.class)
public interface AccesorMinecraftClient {
    @Accessor
    int getAttackCooldown();
}
