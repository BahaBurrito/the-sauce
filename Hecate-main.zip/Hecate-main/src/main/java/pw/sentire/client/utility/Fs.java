package pw.sentire.client.utility;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Fs {
    public static String read(String dir, String fl) throws java.io.IOException {
        File ndir = new File(dir);
        ArrayList<String> res = new ArrayList<>();
        if (!new File(ndir, fl).exists()) return null;
        File file = new File(ndir, fl);
        Scanner scn = new Scanner(file);
        while (scn.hasNextLine()) {
            res.add(scn.nextLine());
        }
        scn.close();
        return String.join("\n", res);
    }

    public static void write(String dir, String fl, String cont) throws java.io.IOException {
        File ndir = new File(dir);
        if (!ndir.exists()) ndir.mkdir();
        File file = new File(ndir, fl);
        if (!file.exists()) file.createNewFile();
        FileWriter fw = new FileWriter(file);
        fw.write(cont);
        fw.close();
    }
}
