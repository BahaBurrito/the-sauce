package pw.sentire.client.gui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import pw.sentire.client.Main;
import pw.sentire.client.gui.widgets.*;
import pw.sentire.client.modules.Category;
import pw.sentire.client.modules.Module;
import pw.sentire.client.modules.options.BooleanOption;
import pw.sentire.client.modules.options.DefOption;
import pw.sentire.client.modules.options.FloatOption;
import pw.sentire.client.modules.options.IntOption;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OptionsMenu extends Screen {
    public static Module module;
    public Map<Category, Integer> incrementHeight = new HashMap<>();
    public Map<Category, Integer> incrementWidth = new HashMap<>();
    public TooltipWidget widget = new TooltipWidget();
    public List<DefOptionWidget<?>> widgets = new ArrayList<>();

    public OptionsMenu() {
        super(new LiteralText("Hecate Module Options"));
    }

    public void loadWidgets() {
        Category cat = Category.CATS;
        for (DefOption option : OptionsMenu.module.getOptions()) {
            switch (option.getType()) {
                case INT -> {
                    addDrawableChild((new OptIntWidget(getCalcWidth(), getCalcHeight(), (IntOption) option)));
                    increment(cat);
                }
                case FLOAT -> {
                    addDrawableChild((new OptFloatWidget(getCalcWidth(), getCalcHeight(), (FloatOption) option)));
                    increment(cat);
                }
                case BOOLEAN -> {
                    addDrawableChild((new OptBooleanWidget(getCalcWidth(), getCalcHeight(), (BooleanOption) option)));
                    increment(cat);
                }
            }
        }
    }

    private int getCalcWidth() {
        return (int) Math.floor((100 * (getIncrement(Category.CATS, true) + 1)) + (Main.mc.getWindow().getScaledWidth() / 3));
    }

    private int getCalcHeight() {
        return (int) Math.floor((20 * getIncrement(Category.CATS, false)) + (Main.mc.getWindow().getScaledHeight() / 3));
    }

    @Override
    public void onClose() {
        this.children().forEach((child -> ((DefHecateWidget) child).save()));
        super.onClose();
    }

    @Override
    public void init() {
        if (module == null) return;
        if (width < 960 || height < 540) Main.log.info("Your screen is too small to render the gui properly!");
        incrementHeight.clear();
        incrementWidth.clear();
        loadWidgets();
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        super.render(matrices, mouseX, mouseY, delta);
        widget.render(matrices);
    }

    public int getIncrement(Category cat, boolean width) {
        if (!incrementHeight.containsKey(cat)) incrementHeight.put(cat, 0);
        if (!incrementWidth.containsKey(cat)) incrementWidth.put(cat, 0);
        return width ? incrementWidth.get(cat) : incrementHeight.get(cat);
    }

    public void increment(Category cat) {
        if (incrementHeight.get(cat) > 3) {
            incrementHeight.put(cat, 0);
            incrementWidth.put(cat, incrementWidth.get(cat) + 1);
        } else {
            incrementHeight.put(cat, incrementHeight.get(cat) + 1);
        }
    }

    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        var ref = new Object() {
            boolean wasHovering = false;
        };

        children().forEach(child -> {
            DefHecateWidget hecateWidget = (DefHecateWidget) child;
            if (hecateWidget.isTooltip() && !hecateWidget.getTooltipText().equals("") && hecateWidget.isMouseOver(mouseX, mouseY)) {
                ref.wasHovering = true;
                if (widget.hoveredWidget == null) widget.hoveredWidget = hecateWidget;
            }
        });
        if (!ref.wasHovering) widget.hoveredWidget = null;
    }
}
