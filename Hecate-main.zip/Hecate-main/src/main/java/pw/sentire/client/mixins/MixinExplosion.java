package pw.sentire.client.mixins;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.explosion.Explosion;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import pw.sentire.client.Main;

import java.util.List;

@Mixin(value = Explosion.class)
public class MixinExplosion {
    @Shadow
    @Final
    private boolean createFire;
    @Shadow
    @Final
    private Explosion.DestructionType destructionType;
    @Shadow
    @Final
    private @Nullable Entity entity;
    @Shadow
    @Final
    private double x;
    @Shadow
    @Final
    private double y;
    @Shadow
    @Final
    private double z;

    @ModifyVariable(method = "collectBlocksAndDamageEntities", at = @At(value = "STORE"), name = "list", ordinal = 0)
    private List<Entity> injCBADE(List<Entity> x) {
        if (this.createFire && destructionType == Explosion.DestructionType.NONE) {
            return List.of(Main.fakePlayer);
        }
        return x;
    }

    @Redirect(method = "collectBlocksAndDamageEntities", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;emitGameEvent(Lnet/minecraft/entity/Entity;Lnet/minecraft/world/event/GameEvent;Lnet/minecraft/util/math/BlockPos;)V"))
    private void injCBADE2(World instance, Entity entity, GameEvent gameEvent, BlockPos blockPos) {
        if (this.createFire && destructionType == Explosion.DestructionType.NONE) {

        } else {
            Main.mc.world.emitGameEvent(this.entity, GameEvent.EXPLODE, new BlockPos(this.x, this.y, this.z));
        }
    }
}
