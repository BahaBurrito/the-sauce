package pw.sentire.client.utility;

import lombok.SneakyThrows;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class URLUtility {

    @SneakyThrows
    public static String read(String link) {
        URL url = new URL(link);
        URLConnection con = url.openConnection();

        InputStream urlcont = con.getInputStream();
        StringBuilder res = new StringBuilder();
        String fcont;
        BufferedReader file = new BufferedReader(new InputStreamReader(urlcont));
        while ((fcont = file.readLine()) != null) {

            if (fcont.equals("")) {
                res.append(fcont);
            } else {
                res.append(fcont).append("\n");
            }
        }

        file.close();

        return res.toString();
    }
}
