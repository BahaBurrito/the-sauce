package pw.sentire.client.utility;

import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;

public class CFM {
    public Gson gson;
    public Config conf = null;

    public CFM() {
        this.gson = new Gson();
        try {
            if (!new File(System.getProperty("user.dir") + "/config", "hecate.json").exists())
                Fs.write(System.getProperty("user.dir") + "/config", "hecate.json", gson.toJson(new Config()));
            this.conf = gson.fromJson(Fs.read(System.getProperty("user.dir") + "/config", "hecate.json"), Config.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public Config get() {
        return conf;
    }
}
