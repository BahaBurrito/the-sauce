package pw.sentire.client.modules.utility;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.Hand;
import pw.sentire.client.events.EventDefiner;
import pw.sentire.client.events.EventListener;
import pw.sentire.client.events.utility.PacketEvent;
import pw.sentire.client.events.utility.TickEvent;
import pw.sentire.client.modules.Category;
import pw.sentire.client.modules.Module;
import pw.sentire.client.utility.EntityUtility;

@EventListener
public class AntiDismount extends Module {
    private Entity entity;
    private boolean awaitRemount = false;
    private int ticks = 0;

    public AntiDismount() {
        super("anti-dismount", Category.MISC, false);
        this.setTooltip("Automatically remount rideables.");
    }

    @EventDefiner
    public void packetEvent(PacketEvent event) {
        if (event.getPacket().getClass() == PlayerPositionLookS2CPacket.class) {
            PlayerPositionLookS2CPacket packet = ((PlayerPositionLookS2CPacket) event.getPacket());
            if (packet.shouldDismount()) {
                if (mc.player.getVehicle() != null) {
                    entity = mc.player.getVehicle();
                    awaitRemount = true;
                }
            }
        }

        if (event.getPacket().getClass() == PlayerInteractEntityC2SPacket.class) {
            PlayerInteractEntityC2SPacket packet = (PlayerInteractEntityC2SPacket) event.getPacket();

            Entity ent = packet.getEntity(null);
            if (packet.isPlayerSneaking()) return;
            if (EntityUtility.getType(entity).equals(EntityUtility.TypeOfEntity.RIDEABLE)) {
                if (mc.player.getVehicle() == null) {
                    entity = entity;
                }
            }
        }
    }

    @EventDefiner
    public void tickEvent(TickEvent event) {
        if (!event.getType().equals(TickEvent.Type.WORLD))
            if (awaitRemount && entity != null) {
                LivingEntity ent = (LivingEntity) entity;
                if (ent.getHealth() <= 0) {
                    awaitRemount = false;
                    entity = null;
                    return;
                }

                if (mc.player.distanceTo(ent) >= 7) {
                    awaitRemount = false;
                    entity = null;
                    return;
                }

                if (mc.player.getVehicle() != null || mc.player.getVehicle() == ent) {
                    awaitRemount = false;
                    entity = null;
                    return;
                }

                ticks++;
                if (ticks >= 3 && mc.player.getVehicle() == null) {
                    mc.getNetworkHandler().sendPacket(PlayerInteractEntityC2SPacket.interact(ent, false, mc.player.getMainHandStack().isUsedOnRelease() ? Hand.OFF_HAND : Hand.MAIN_HAND));
                }


            } else {
                if (ticks > 0) ticks = 0;
            }
    }
}
