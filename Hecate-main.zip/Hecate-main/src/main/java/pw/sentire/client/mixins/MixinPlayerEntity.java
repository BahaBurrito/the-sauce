package pw.sentire.client.mixins;

import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value = PlayerEntity.class)
public class MixinPlayerEntity {

}
