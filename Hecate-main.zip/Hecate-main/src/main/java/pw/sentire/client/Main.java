package pw.sentire.client;

import lombok.Getter;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import pw.sentire.client.events.EventHandler;
import pw.sentire.client.gui.Menu;
import pw.sentire.client.gui.OptionsMenu;
import pw.sentire.client.gui.widgets.NotificationWidget;
import pw.sentire.client.modules.Modules;
import pw.sentire.client.utility.CFM;
import pw.sentire.client.utility.Config;
import pw.sentire.client.utility.FakePlayerEntity;

public class Main implements ClientModInitializer {

    public static final String MOD_ID = "hecate";
    public static final String MOD_NAME = "Hecate";
    public static final Logger log = LogManager.getLogger();
    public static final EventHandler eventHandler = new EventHandler();
    public static final Modules modules = new Modules();
    public static MinecraftClient mc;
    public static Main inst;
    public static Config config = new CFM().get();
    public static boolean hasCheckedUUID = false;
    public static FakePlayerEntity fakePlayer;
    public static NotificationWidget notificationWidget;
    @Getter
    private static Menu menu;
    @Getter
    private static OptionsMenu optionsMenu;

    public static void main(String[] args) {

    }

    @Override
    public void onInitializeClient() {
        if (inst == null) {
            inst = this;
            mc = MinecraftClient.getInstance();
            return;
        }
        notificationWidget = new NotificationWidget();
        menu = new Menu();
        optionsMenu = new OptionsMenu();
        log.info("Hecate has been initialized.");
        config = new CFM().get();
        modules.init();
    }
}
