package pw.sentire.client.modules;

import pw.sentire.client.Main;
import pw.sentire.client.gui.Menu;
import pw.sentire.client.modules.combat.Hitbox;
import pw.sentire.client.modules.combat.KillAura;
import pw.sentire.client.modules.player.AutoTotem;
import pw.sentire.client.modules.player.AutoTotemV2;
import pw.sentire.client.modules.utility.Notifications;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class Modules {
    private final Map<String, Module> modules = new HashMap<>();

    public void init() {
        this.add(new ClickGUI());
        this.add(new KillAura());
        this.add(new Hitbox());
        this.add(new AutoTotem());
        this.add(new AutoTotemV2());
        this.add(new Notifications());
    }

    public void add(Module module) {
        module.loadConfig();
        modules.put(module.getName(), module);
        Main.eventHandler.register(module);
        if (module.getCategory() != Category.HIDDEN) Menu.queueButtons.add(module);
        /*
        * ToDo integrate the command handler to be with modules.
        if (module.getClass().isAnnotationPresent(CommandListener.class)) Main.commandHandler.register(module);
        */
    }

    public boolean isEnabled(String module) {
        if (modules.containsKey(module)) return modules.get(module).isActive();
        return false;
    }

    public Collection<Module> get() {
        return modules.values();
    }

    public Module get(String str) {
        if (modules.containsKey(str)) {
            return modules.get(str);
        }
        return null;
    }
}
