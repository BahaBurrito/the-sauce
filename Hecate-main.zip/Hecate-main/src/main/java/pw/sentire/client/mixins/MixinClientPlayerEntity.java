package pw.sentire.client.mixins;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pw.sentire.client.Main;
import pw.sentire.client.events.utility.TickEvent;

import java.util.Optional;

@Mixin(value = ClientPlayerEntity.class)
public abstract class MixinClientPlayerEntity {
    @Shadow
    public abstract void move(MovementType movementType, Vec3d movement);

    @Inject(method = "tick", at = @At("INVOKE"))
    public void tickEvent(CallbackInfo ci) {
        Main.eventHandler.post(new TickEvent(TickEvent.Type.CLIENT_PLAYER, Optional.of(Main.mc.player)));
    }

    @Inject(method = "move", at = @At("INVOKE"), cancellable = true)
    public void moveEvent(MovementType movementType, Vec3d movement, CallbackInfo ci) {
        /*ClientPlayerMoveEvent event = (ClientPlayerMoveEvent) Main.eventHandler.post(new ClientPlayerMoveEvent(movementType, movement));
        if (event.isCancelled()) {
            this.move(event.getMovementType(), event.getPos());
            ci.cancel();
        }*/
    }
}
