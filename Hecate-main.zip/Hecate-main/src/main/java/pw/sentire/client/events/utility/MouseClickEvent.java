package pw.sentire.client.events.utility;

import lombok.Getter;
import pw.sentire.client.events.Event;

@Getter
public class MouseClickEvent extends Event {
    private final int button;
    private final int action;

    public MouseClickEvent(int button, int action) {
        super(true, "mouse-click");
        this.button = button;
        this.action = action;
    }
}
