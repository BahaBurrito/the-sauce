package pw.sentire.client.gui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import pw.sentire.client.Main;
import pw.sentire.client.gui.widgets.CategoryWidget;
import pw.sentire.client.gui.widgets.HecateWidget;
import pw.sentire.client.gui.widgets.TooltipWidget;
import pw.sentire.client.modules.Category;
import pw.sentire.client.modules.Module;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Menu extends Screen {

    public static List<Module> queueButtons = new ArrayList<>();
    public static boolean hasLoadedWidgets = false;
    public static Map<Category, List<HecateWidget>> categories = new HashMap<>();
    public static Category currentCategory = Category.COMBAT;
    public static Category ghostCategory = Category.HIDDEN;
    public static List<CategoryWidget> categoryWidgets = new ArrayList<>();
    public Map<Category, Integer> incrementHeight = new HashMap<>();
    public Map<Category, Integer> incrementWidth = new HashMap<>();
    public TooltipWidget widget = new TooltipWidget();

    public Menu() {
        super(new LiteralText("Emotional Breakdown"));
    }

    public void addButton(Module module) {
        Category cat = module.getCategory();
        HecateWidget widget = new HecateWidget(80 * (getIncrement(cat, true) + 1), 20 * getIncrement(cat, false), module);
        increment(cat);
        this.getCategory(cat).add(widget);
    }

    @Override
    public void init() {
        if (width < 960 || height < 540) Main.log.info("Your screen is too small to render the gui properly!");
        incrementHeight.clear();
        incrementWidth.clear();

        if (categoryWidgets.isEmpty())
            for (Category category : Category.values()) {
                if (!(category == Category.CATS || category == Category.HIDDEN)) {
                    categoryWidgets.add(new CategoryWidget(0, 20 * getIncrement(Category.CATS, false), category));
                    increment(Category.CATS);
                }
            }

        categoryWidgets.forEach(this::addDrawableChild);

        if (hasLoadedWidgets) {
            categories.values().forEach(widgets -> widgets.forEach(this::addDrawableChild));
        } else {
            for (Module module : queueButtons) {
                addButton(module);
            }
            categories.values().forEach(widgets -> widgets.forEach(this::addDrawableChild));
            hasLoadedWidgets = true;
        }

        categories.values().forEach(widgets -> widgets.forEach(toggleWidget -> toggleWidget.setVisible(toggleWidget.getModule().getCategory() == (ghostCategory != Category.HIDDEN ? Menu.ghostCategory : Menu.currentCategory))));
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        super.render(matrices, mouseX, mouseY, delta);
        widget.render(matrices);
    }

    public List<HecateWidget> getCategory(Category cat) {
        if (!categories.containsKey(cat)) categories.put(cat, new ArrayList<>());
        return categories.get(cat);
    }

    public int getIncrement(Category cat, boolean width) {
        if (!incrementHeight.containsKey(cat)) incrementHeight.put(cat, 0);
        if (!incrementWidth.containsKey(cat)) incrementWidth.put(cat, 0);
        return width ? incrementWidth.get(cat) : incrementHeight.get(cat);
    }

    public void increment(Category cat) {
        if (incrementHeight.get(cat) >= Math.round(height / 20)) {
            incrementHeight.put(cat, 0);
            incrementWidth.put(cat, incrementWidth.get(cat) + 1);
        } else {
            incrementHeight.put(cat, incrementHeight.get(cat) + 1);
        }
    }

    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        categoryWidgets.forEach(categoryWidget -> {
            categoryWidget.ratHovered(mouseX, mouseY);
            categoryWidget.onMouseMoved(mouseX, mouseY);
        });

        var ref = new Object() {
            boolean wasHovering = false;
        };

        categories.values().forEach(hecateWidgets -> {
            hecateWidgets.forEach(hecateWidget -> {
                if (hecateWidget.isTooltip() && hecateWidget.getTooltipText() != "" && hecateWidget.isMouseOver(mouseX, mouseY)) {
                    ref.wasHovering = true;
                    if (widget.hoveredWidget == null) widget.hoveredWidget = hecateWidget;
                }
            });
        });
        if (!ref.wasHovering) widget.hoveredWidget = null;
    }
}
