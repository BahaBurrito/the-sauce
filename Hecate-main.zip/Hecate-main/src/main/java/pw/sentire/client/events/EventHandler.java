package pw.sentire.client.events;

import pw.sentire.client.Main;
import pw.sentire.client.modules.Module;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class EventHandler {
    public Map<String, ArrayList<Method>> events = new HashMap<>();
    public Map<Method, Module> methodClassMap = new HashMap<>();

    public void register(Module obj) {
        int count = 0;
        Class<?> clazz = obj.getClass();

        if (clazz.isAnnotationPresent(EventListener.class)) {
            for (Method method : clazz.getMethods()) {
                if (method.isAnnotationPresent(EventDefiner.class)) {
                    Class<?>[] params = method.getParameterTypes();

                    if (params.length == 1) {
                        if (!events.containsKey(params[0].getSimpleName())) {
                            events.put(params[0].getSimpleName(), new ArrayList<>());
                        }
                        methodClassMap.put(method, obj);
                        method.setAccessible(true);
                        events.get(params[0].getSimpleName()).add(method);
                        ArrayList<Method> methods = events.get(params[0].getSimpleName());
                        methods.sort(Comparator.comparingInt(o -> o.getAnnotation(EventDefiner.class).priority()));
                        events.put(params[0].getSimpleName(), methods);
                        count++;
                    } else {
                        Main.log.info(method.getName() + " in " + clazz.getSimpleName() + " is defined as a event but doesn't have the parameters of one.");
                    }
                }
            }
            if (count < 1) {
                Main.log.info(clazz.getSimpleName() + " had no methods.");
            } else {
                Main.log.info(clazz.getSimpleName() + " registered " + count + " methods.");
            }
        } else {
            Main.log.info(clazz.getSimpleName() + " object wasn't annotated.");
        }
    }

    public Event post(Event event) {
        Class<? extends Event> clazz = event.getClass();
        if (events.containsKey(clazz.getSimpleName())) {
            for (Method method : events.get(clazz.getSimpleName())) {
                try {
                    if (methodClassMap.get(method).isActive()) method.invoke(methodClassMap.get(method), event);
                    if (event.isCancellable() && event.isLoopEnded()) break;
                } catch (IllegalAccessException | InvocationTargetException e) {
                    e.printStackTrace();
                }
            }
        }
        return event;
    }

    public void remove(Object obj) {
        Class<?> clazz = obj.getClass();

        if (clazz.isAnnotationPresent(EventListener.class)) {
            for (Method method : clazz.getMethods()) {
                if (method.isAnnotationPresent(EventDefiner.class)) {
                    Class<?>[] params = method.getParameterTypes();
                    if (params.length == 1 && params[0].isInstance(Event.class)) {
                        if (events.containsKey(params[0].getSimpleName())) {
                            events.get(params[0].getSimpleName()).remove(method);
                        }
                        methodClassMap.remove(method);
                    }
                }
            }
        }
    }
}
