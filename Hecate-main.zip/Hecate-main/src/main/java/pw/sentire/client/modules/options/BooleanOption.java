package pw.sentire.client.modules.options;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class BooleanOption extends DefOption<Boolean> {
    public BooleanOption(@NotNull String name, @NotNull Boolean value, @Nullable String tooltip) {
        super(name, value, Type.BOOLEAN, tooltip);
    }
}
