package pw.sentire.client.mixins;

import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pw.sentire.client.Main;

@Mixin(value = PlayerInteractEntityC2SPacket.class)
public class MixinPlayerInteractionEntityC2SPacket {
    @Shadow
    @Final
    private int entityId;

    @Shadow
    @Final
    private PlayerInteractEntityC2SPacket.InteractTypeHandler type;

    @Shadow
    @Final
    private boolean playerSneaking;

    @Inject(method = "getEntity", at = @At("RETURN"), cancellable = true)
    public void overrideGetEntity(ServerWorld world, CallbackInfoReturnable<Entity> cir) {
        if (world == null && this.type.getType() == PlayerInteractEntityC2SPacket.InteractType.INTERACT) {
            if (this.playerSneaking) return;
            if (Main.mc.player.getMainHandStack().isUsedOnRelease() || Main.mc.player.getOffHandStack().isUsedOnRelease())
                return;
            cir.setReturnValue(Main.mc.player.clientWorld.getEntityById(this.entityId));
        }
    }
}
