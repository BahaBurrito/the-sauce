package pw.sentire.client.modules.options;

import lombok.Getter;
import lombok.Setter;
import org.jetbrains.annotations.Nullable;

@Getter
@Setter
public class IntOption extends DefOption<Integer> {
    private final int min;
    private final int max;

    public IntOption(String name, int def, int min, int max, @Nullable String tooltip) {
        super(name, def, Type.INT, tooltip);
        this.min = min;
        this.max = max;
    }
}
