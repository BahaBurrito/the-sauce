package pw.sentire.client.gui.widgets;

import net.minecraft.client.util.math.MatrixStack;
import pw.sentire.client.Main;

public class TooltipWidget extends DefHecateWidget {
    public DefHecateWidget hoveredWidget;

    public TooltipWidget() {
        super(Main.mc.getWindow().getScaledWidth() - 200, Main.mc.getWindow().getScaledHeight() - 10);
        this.setSelectable(true);
        this.setVisible(true);
    }

    public void render(MatrixStack matrices) {
        if (!isVisible() || hoveredWidget == null) return;
        this.x = Main.mc.getWindow().getScaledWidth() - Main.mc.textRenderer.getWidth(hoveredWidget.getTooltipText());
        this.y = Main.mc.getWindow().getScaledHeight() - 10;
        drawStringWithShadow(matrices, Main.mc.textRenderer, hoveredWidget.getTooltipText(), x, y, DefHecateWidget.textColor.getRGB());
    }
}
