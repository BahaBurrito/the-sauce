package pw.sentire.client.mixins;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Overlay;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pw.sentire.client.Main;

@Mixin(value = MinecraftClient.class, priority = Integer.MAX_VALUE)
public class MixinMinecraftClient {

    @Inject(method = "<init>", at = @At("TAIL"))
    private void onInit(CallbackInfo info) {
        Main.inst.onInitializeClient();
    }

    @Inject(method = "disconnect(Lnet/minecraft/client/gui/screen/Screen;)V", at = @At("INVOKE"))
    public void onDisconnect(Screen screen, CallbackInfo ci) {
        Main.config.save();
    }

    @Inject(method = "close", at = @At("INVOKE"))
    public void onClose(CallbackInfo ci) {
        Main.config.save();
    }

    @Inject(method = "getOverlay", at = @At("RETURN"), cancellable = true)
    public void onGO(CallbackInfoReturnable<Overlay> cir) {
        if (Main.mc.currentScreen == Main.getMenu() || Main.mc.currentScreen == Main.getOptionsMenu())
            cir.setReturnValue(null);
    }
}