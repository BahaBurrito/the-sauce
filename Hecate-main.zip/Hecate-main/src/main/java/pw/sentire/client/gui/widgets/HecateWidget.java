package pw.sentire.client.gui.widgets;

import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.util.math.MatrixStack;
import pw.sentire.client.Main;
import pw.sentire.client.gui.OptionsMenu;
import pw.sentire.client.modules.Module;
import pw.sentire.client.utility.StringUtility;

import java.awt.*;

@Getter
public class HecateWidget extends DefHecateWidget {
    public static final Color activatedColor = new Color(115, 224, 230);
    public static final Color disabledColor = new Color(208, 111, 237);
    private final Module module;
    @Setter
    private int color = DefHecateWidget.textColor.getRGB();

    public HecateWidget(int x, int y, Module module) {
        super(x, y);
        this.module = module;
        this.setText(StringUtility.getModuleLT(module));
        this.setTooltip(true);
        this.setTooltipText(module.getTooltip());
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        super.render(matrices, mouseX, mouseY, delta);
        if (this.isVisible()) {
            if (module.isActive()) this.setColor(HecateWidget.activatedColor.getRGB());
            else this.setColor(HecateWidget.disabledColor.getRGB());
            drawTextWithShadow(matrices, Main.mc.textRenderer, this.getText(), x + 4, y + 7, color);
        }
    }


    @Override
    public SelectionType getType() {
        return SelectionType.HOVERED;
    }

    @Override
    public void appendNarrations(NarrationMessageBuilder builder) {

    }

    @Override
    public void onMiddleClick() {
        this.onClick();
    }

    @Override
    public void onRightClick() {
        if (!module.getOptions().isEmpty()) {
            OptionsMenu.module = module;
            Main.mc.setScreen(Main.getOptionsMenu());
            return;
        }
        this.onClick();
    }

    @Override
    public void onClick() {
        module.setActive(!module.isActive());
        module.onClick(this);
        this.setText(StringUtility.getModuleLT(module));
    }
}
