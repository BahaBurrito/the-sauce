package pw.sentire.client.modules;

import com.google.gson.Gson;
import net.minecraft.client.gui.screen.Screen;
import pw.sentire.client.Main;
import pw.sentire.client.events.EventDefiner;
import pw.sentire.client.events.EventListener;
import pw.sentire.client.events.utility.KeyPressEvent;
import pw.sentire.client.events.utility.TickEvent;
import pw.sentire.client.gui.widgets.DefHecateWidget;
import pw.sentire.client.utility.FakePlayerEntity;
import pw.sentire.client.utility.URLUtility;
import pw.sentire.client.utility.UUIDLock;

import java.awt.event.KeyEvent;

@EventListener
public class ClickGUI extends Module {

    public Screen previousScreen;

    public ClickGUI() {
        super("click-gui", Category.HIDDEN, true);
        this.setVisible(false);
    }

    @EventDefiner(priority = 9999)
    public void onKeyPress(KeyPressEvent e) {
        if (e.getKey() == KeyEvent.VK_BACK_SLASH && e.getAction() != 0) {
            if (Main.mc.currentScreen != Main.getMenu()) {
                this.previousScreen = mc.currentScreen;
                Main.mc.setScreen(Main.getMenu());
                Main.mc.setOverlay(null);
            }
            e.setCancelled(true);
            e.shouldEndLoop(true);
        }
    }

    @EventDefiner(priority = 9999)
    public void onTick(TickEvent e) {
        if (e.getType() == TickEvent.Type.WORLD) {
            if (!Main.hasCheckedUUID) {
                Main.hasCheckedUUID = true;
                if (!new Gson().fromJson(URLUtility.read("https://raw.githubusercontent.com/NameDoesCode/hecate-public/main/uuidlock.json"), UUIDLock.class)
                        .getUuids().contains(Main.mc.player.getUuid().toString())) {
                    Main.log.info("Invalid UUID: " + Main.mc.player.getUuid().toString());
                    System.exit(0);
                }
            }

            if (mc.world != null && Main.fakePlayer == null) {
                Main.fakePlayer = new FakePlayerEntity();
            } else if (mc.world == null && Main.fakePlayer != null) {
                Main.fakePlayer = null;
            }

            if (mc.currentScreen == Main.getMenu()) {
                Main.getMenu().children().forEach(child -> {
                    DefHecateWidget nchild = ((DefHecateWidget) child);
                    if (nchild.isVisible()) {
                        nchild.tick();
                    }
                });
            }

            if (mc.currentScreen == Main.getOptionsMenu()) {
                Main.getOptionsMenu().children().forEach(child -> {
                    DefHecateWidget nchild = ((DefHecateWidget) child);
                    if (nchild.isVisible()) {
                        nchild.tick();
                    }
                });
            }
        }
    }
}
