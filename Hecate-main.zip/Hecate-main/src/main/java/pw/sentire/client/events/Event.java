package pw.sentire.client.events;

public class Event {
    private final boolean cancellable;
    private final String name;
    private boolean cancel = false, endLoop = false;

    public Event(boolean cancellable, String name) {
        this.cancellable = cancellable;
        this.endLoop = false;
        this.name = name;

    }

    public boolean cancel() {
        if (this.cancellable) this.cancel = !this.cancel;
        return this.cancel;
    }

    public boolean isCancelled() {
        return cancel;
    }

    public void setCancelled(boolean val) {
        if (this.cancellable) this.cancel = val;
    }

    public boolean isCancellable() {
        return cancellable;
    }

    public boolean isLoopEnded() {
        return this.endLoop;
    }

    public void shouldEndLoop(boolean val) {
        if (this.cancellable) this.endLoop = val;
    }
}
