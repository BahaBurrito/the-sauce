package pw.sentire.client.gui.widgets;

import pw.sentire.client.modules.options.DefOption;

public class DefOptionWidget<T extends DefOption> extends DefHecateWidget {
    public T option;

    public DefOptionWidget(int x, int y, T option) {
        super(x, y);
        this.option = option;
        this.width = 100;
        this.height = 20;
        this.setTooltip(true);
        this.setTooltipText(option.getTooltip());
    }
}
