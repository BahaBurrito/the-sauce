package pw.sentire.client.events.movement;

import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.Vec3d;
import pw.sentire.client.events.Event;

@Getter
@Setter
@NonNull
public class ClientPlayerMoveEvent extends Event {
    private MovementType movementType;
    private Vec3d pos;

    public ClientPlayerMoveEvent(MovementType movementType, Vec3d pos) {
        super(true, "client-player-move");
        this.movementType = movementType;
        this.pos = pos;
    }
}
