package pw.sentire.client.modules.options;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class StringOption extends DefOption<String> {
    public StringOption(@NotNull String name, @NotNull String value, @Nullable String tooltip) {
        super(name, value, Type.STRING, tooltip);
    }
}
