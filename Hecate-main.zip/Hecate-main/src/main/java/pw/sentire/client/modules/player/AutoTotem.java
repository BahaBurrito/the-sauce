package pw.sentire.client.modules.player;

import net.minecraft.item.Items;
import pw.sentire.client.Main;
import pw.sentire.client.events.EventDefiner;
import pw.sentire.client.events.EventListener;
import pw.sentire.client.events.utility.TickEvent;
import pw.sentire.client.gui.widgets.HecateWidget;
import pw.sentire.client.modules.Category;
import pw.sentire.client.modules.Module;
import pw.sentire.client.utility.InventoryUtility;

@EventListener
public class AutoTotem extends Module {

    public AutoTotem() {
        super("auto-totem", Category.PLAYER, false);
        this.setTooltip("Standard auto totem.");
    }

    @Override
    public void onClick(HecateWidget button) {
        if (this.isActive() && Main.modules.isEnabled("auto-totem-v2")) {
            Main.modules.get("auto-totem-v2").setActive(false);
        }
        super.onClick(button);
    }

    @EventDefiner
    public void onTick(TickEvent e) {
        if (e.getType() == TickEvent.Type.WORLD) {
            int totemSlot = InventoryUtility.findSlotInMainOrHotbar(Items.TOTEM_OF_UNDYING);
            if (totemSlot > -1 && Main.mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING) {
                InventoryUtility.moveItem(totemSlot, Main.mc.player.playerScreenHandler.slots.get(Main.mc.player.playerScreenHandler.slots.size() - 1).id);
            }
        }
    }
}
