package pw.sentire.client.mixins;

import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value = Entity.class)
public interface AccessorEntity {
    @Accessor
    Entity getVehicle();
}
