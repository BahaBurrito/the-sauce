package pw.sentire.client.mixins;

import net.minecraft.network.ClientConnection;
import net.minecraft.network.Packet;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pw.sentire.client.Main;
import pw.sentire.client.events.Event;
import pw.sentire.client.events.utility.PacketEvent;

@Mixin(value = ClientConnection.class)
public class MixinClientConnection {
    @Inject(method = "handlePacket", at = @At("HEAD"), cancellable = true)
    private static <T extends PacketListener> void spEvent(Packet<T> packet, PacketListener listener, CallbackInfo ci) {
        if (listener instanceof ServerPlayNetworkHandler) {
            Event event = Main.eventHandler.post(new PacketEvent(packet, PacketEvent.Type.RECEIVED));
            if (event.isCancelled()) ci.cancel();
        }
    }
}
