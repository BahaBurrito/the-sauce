package pw.sentire.client.utility;

import pw.sentire.client.Main;

import java.util.UUID;

public class Friends {
    public static void friendAOR(UUID uuid) {
        if (Main.config.getFriendsUUID().contains(uuid.toString())) Main.config.getFriendsUUID().remove(uuid.toString());
        else Main.config.getFriendsUUID().add(uuid.toString());
    }

    public static void friendAOR(String name) {
        if (Main.config.getFriendsUUID().contains(name)) Main.config.getFriendsUUID().remove(name);
        else Main.config.getFriendsUUID().add(name);
    }

    public static boolean isFriend(String friend) {
        return Main.config.getFriendsUUID().contains(friend) || Main.config.getFriendsName().contains(friend);
    }
}
