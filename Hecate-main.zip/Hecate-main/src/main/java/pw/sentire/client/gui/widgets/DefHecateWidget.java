package pw.sentire.client.gui.widgets;

import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.gui.Drawable;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;

import java.awt.*;

@Getter
public class DefHecateWidget extends DrawableHelper implements Drawable, Selectable, Element {
    @Setter
    public static Color textColor = new Color(157, 105, 240);
    @Setter
    private static Color mainColor = new Color(255, 255, 255, 80);
    @Setter
    private static Color outlineColor = new Color(0, 0, 20);
    public int x;
    public int y;
    public int height = 20;
    public int width = 80;
    @Setter
    private Color selectedColor = new Color(191, 191, 191, 80);
    @Setter
    private boolean visible = true;
    @Setter
    private LiteralText text;
    @Setter
    private boolean hovered;
    @Setter
    private boolean focused;
    @Setter
    private int ticks;
    @Setter
    private boolean selectable = false;
    @Setter
    private boolean tooltip = false;
    @Setter
    private String tooltipText = "";

    public DefHecateWidget(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        if (!isVisible()) {
            if (isFocused()) this.setFocused(false);
            return;
        }
        fill(matrices, x + 2, y + 2, x + width - 1, y + height - 1, this.isSelectable() && this.isFocused() ? selectedColor.getRGB() : mainColor.getRGB());
        drawHorizontalLine(matrices, x + 1, x + width - 1, y + 1, outlineColor.getRGB());
        drawHorizontalLine(matrices, x + 1, x + width - 1, y + height - 1, outlineColor.getRGB());
        drawVerticalLine(matrices, x + 1, y + 1, y + height - 1, outlineColor.getRGB());
        drawVerticalLine(matrices, x + width - 1, y + 1, y + height - 1, outlineColor.getRGB());
    }

    @Override
    public Selectable.SelectionType getType() {
        return SelectionType.HOVERED;
    }

    @Override
    public void appendNarrations(NarrationMessageBuilder builder) {
    }

    public void onClick() {
    }

    public void onRightClick() {
    }

    public void onMiddleClick() {
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (isVisible() && (mouseX > x && mouseX < x + width && mouseY > y && mouseY < y + height)) {
            this.setFocused(true);
            if (button == 0) this.onClick();
            else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) this.onRightClick();
            else if (button == GLFW.GLFW_MOUSE_BUTTON_MIDDLE) this.onMiddleClick();
            return true;
        } else {
            this.setFocused(false);
            return false;
        }
    }

    @Override
    public boolean changeFocus(boolean lookForwards) {
        return false;
    }

    public void onDrag(double mouseX, double mouseY, double deltaX, double deltaY) {

    }

    public void tick() {
        this.ticks++;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (button == 0) {
            this.onDrag(mouseX, mouseY, deltaX, deltaY);
            return true;
        } else {
            return false;
        }
    }

    public void save() {
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        return isVisible() && (mouseX > x && mouseX < x + width && mouseY > y && mouseY < y + height);
    }
}
