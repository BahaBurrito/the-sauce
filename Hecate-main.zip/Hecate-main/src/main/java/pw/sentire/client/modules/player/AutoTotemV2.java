package pw.sentire.client.modules.player;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import pw.sentire.client.Main;
import pw.sentire.client.events.EventDefiner;
import pw.sentire.client.events.EventListener;
import pw.sentire.client.events.utility.TickEvent;
import pw.sentire.client.modules.Category;
import pw.sentire.client.modules.Module;
import pw.sentire.client.modules.options.BooleanOption;
import pw.sentire.client.modules.options.FloatOption;
import pw.sentire.client.modules.options.IntOption;
import pw.sentire.client.utility.EntityUtility;
import pw.sentire.client.utility.InventoryUtility;

import java.util.List;

@EventListener
public class AutoTotemV2 extends Module {
    public BooleanOption explosives = new BooleanOption("anti-explode", true, "Factor in explosions.");
    public FloatOption radius = new FloatOption("explosive-radius", 11.0f, 5.0f, 11.0f, 1, "Radius to check for explosives.");
    public IntOption minimumHealth = new IntOption("minimum-health", 10, 1, 20, "Minimum health before switching to a totem.");
    public BooleanOption hostile = new BooleanOption("force-totem", true, "Forcefully switch to a totem.");
    public IntOption skipTicks = new IntOption("skip-ticks", 1, 1, 120, "Ticks to skip.");
    public BooleanOption notify = new BooleanOption("notify", false, "Notify when it triggers.");
    private int ticks = 0;

    public AutoTotemV2() {
        super("auto-totem-v2", Category.PLAYER, false);
        radius.addRequirement(explosives, true);
        this.addOption(explosives)
                .addOption(radius)
                .addOption(minimumHealth)
                .addOption(hostile)
                .addOption(skipTicks)
                .addOption(notify);
        this.setTooltip("More advanced auto totem.");
    }

    @EventDefiner
    public void onTick(TickEvent e) {
        if (e.getType() == TickEvent.Type.WORLD) {
            if (ticks >= skipTicks.getValue()) {
                ticks = 0;
            } else {
                ticks++;
                return;
            }
            var ref = new Object() {
                float highestDamage = 0.0f;
                float healthLeft = mc.player.getHealth() + mc.player.getAbsorptionAmount();
            };
            if (explosives.getValue()) {
                List<Entity> entities = mc.player.world.getOtherEntities(mc.player, new Box(mc.player.getPos().add(radius.getValue(), radius.getValue(), radius.getValue()), mc.player.getPos().add(-radius.getValue(), -radius.getValue(), -radius.getValue())), entity -> {
                    EntityUtility.TypeOfEntity type = EntityUtility.getType(entity);
                    if (type == EntityUtility.TypeOfEntity.EXPLOSION || type == EntityUtility.TypeOfEntity.EXPLOSION_INANIMATE) {
                        float dmg = Main.fakePlayer.getExplosionDamage(entity.getPos(), Main.mc.player, entity.getType() == EntityType.END_CRYSTAL ? 6.0f : 3.0f, true, 10);
                        if (dmg > ref.highestDamage) ref.highestDamage = dmg;
                        return true;
                    }
                    return false;
                });

                if (!entities.isEmpty() && ref.healthLeft - ref.highestDamage <= minimumHealth.getValue()) {
                    ref.healthLeft = ref.healthLeft - ref.highestDamage;
                }
            }

            if (ref.healthLeft <= minimumHealth.getValue()) {
                int totemSlot = InventoryUtility.findSlotInMainOrHotbar(Items.TOTEM_OF_UNDYING);
                if (totemSlot > -1 && hostile.getValue() ? Main.mc.player.getOffHandStack().getItem() != Items.TOTEM_OF_UNDYING : Main.mc.player.getOffHandStack() == ItemStack.EMPTY) {
                    if (notify.getValue()) Main.notificationWidget.notify(this, "was triggered.");
                    InventoryUtility.moveItem(totemSlot, Main.mc.player.playerScreenHandler.slots.get(Main.mc.player.playerScreenHandler.slots.size() - 1).id);
                }
            }
        }
    }
}
