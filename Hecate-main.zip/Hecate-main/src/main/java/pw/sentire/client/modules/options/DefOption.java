package pw.sentire.client.modules.options;

import lombok.Getter;
import lombok.NonNull;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import pw.sentire.client.Main;

import java.util.HashMap;
import java.util.Map;

@Getter
public class DefOption<T> {
    private final String name;
    private final Type type;
    @NonNull
    private T value;
    private String tooltip = "";
    private Map<DefOption<?>, Object> requires = new HashMap<>();

    public DefOption(@NotNull String name, @NotNull T value, Type type, @Nullable String tooltip) {
        this.value = value;
        this.name = name;
        this.type = type;
        this.tooltip = tooltip;
    }

    public boolean meetsRequirements() {
        var ref = new Object() {
            int count = 0;
        };
        requires.forEach((defOption, o) -> {
            if (defOption.getValue() == o) {
                ref.count++;
            }
        });

        Main.log.info("Count: " + ref.count + " : " + requires.size());
        return requires.isEmpty() || ref.count == requires.size()+1;
    }

    public DefOption<T> addRequirement(DefOption<?> option, Object obj) {
        requires.put(option, obj);
        return this;
    }

    public DefOption<T> setTooltip(@NotNull String str) {
        this.tooltip = str;
        return this;
    }

    public DefOption<T> setValue(@NotNull T val) {
        this.value = val;
        return this;
    }

    public enum Type {
        BOOLEAN,
        FLOAT,
        INT,
        STRING,
        SINGLE_STRING
    }
}
