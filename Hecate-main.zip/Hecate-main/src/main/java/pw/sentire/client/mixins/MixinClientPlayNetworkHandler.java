package pw.sentire.client.mixins;

import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pw.sentire.client.Main;
import pw.sentire.client.events.Event;
import pw.sentire.client.events.utility.PacketEvent;

@Mixin(value = ClientPlayNetworkHandler.class)
public class MixinClientPlayNetworkHandler {
    @Inject(method = "sendPacket", at = @At("HEAD"), cancellable = true)
    public void spEvent(Packet<?> packet, CallbackInfo ci) {
        Event event = Main.eventHandler.post(new PacketEvent(packet, PacketEvent.Type.SENT));
        if (event.isCancelled()) ci.cancel();
    }
}
