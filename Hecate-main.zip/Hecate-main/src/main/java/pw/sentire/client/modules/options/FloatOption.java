package pw.sentire.client.modules.options;

import lombok.Getter;
import org.jetbrains.annotations.Nullable;

@Getter
public class FloatOption extends DefOption<Float> {
    private final float min;
    private final float max;
    private final int decimals;

    public FloatOption(String name, float def, float min, float max, int decimals, @Nullable String tooltip) {
        super(name, def, Type.FLOAT, tooltip);
        this.min = min;
        this.max = max;
        this.decimals = decimals;
    }
}
