# Thrift
C++ Client for Minecraft Bedrock Edition
