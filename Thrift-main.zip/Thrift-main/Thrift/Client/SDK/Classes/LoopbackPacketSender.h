#pragma once

#include "Packet.h"

class LoopbackPacketSender {
public:
	//
};