#pragma once

#include "../../Utils/Utils.h"

class Actor {
public:
	BUILD_ACCESS(bool, isOnGround, 0x1B8);
};