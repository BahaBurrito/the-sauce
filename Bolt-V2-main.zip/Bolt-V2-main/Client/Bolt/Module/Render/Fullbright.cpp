#include "Fullbright.h"

auto Fullbright::onGamma(float* gamma) -> void {

    *gamma = 100.f;

};