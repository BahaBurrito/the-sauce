#include "Hook.h"

Hook::Hook(Manager* mgr) {

    this->manager = mgr;

};