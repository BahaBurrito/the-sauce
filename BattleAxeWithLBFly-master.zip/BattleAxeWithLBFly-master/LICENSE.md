# [Licensing information](https://github.com/BattleAxeClient/battle-axe-releases/blob/master/LICENSE.md)

Copyright (c) 2020 Battle Axe Client

Permission is hereby granted, free of charge, to any person using this, to use it. You may NOT modify this, and/or distrubute this client (or a modified version) without explicit permission from the owner. 

This license may update, if it does, you have to abide by the new/updated license, with or without notice. By not abiding to any license change, you give us the right to order a DMCA Takedown on you.
Using this source code to add or make a new product is not allowed, unless directly stated otherwise
# External code used

Based From [Horion](https://github.com/horionclient/Horion)
