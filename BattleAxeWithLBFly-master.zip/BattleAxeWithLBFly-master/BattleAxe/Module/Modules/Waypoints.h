#pragma once

#include <sstream>

#include "../../../Utils/Json.hpp"
#include "../../DrawUtils.h"
#include "Module.h"

class Waypoints : public IModule {
private:
	std::map<std::string, vec3_t> waypoints;

public:
	Waypoints();
	~Waypoints();

	float size = 0.6f;

	// Inherited via IModule
	virtual const char* getModuleName() override;
	virtual void onPreRender(C_MinecraftUIRenderContext* renderCtx) override;
	virtual void onLoadConfig(void* confVoid) override;
	virtual void onSaveConfig(void* confVoid) override;

	bool add(std::string text, vec3_t pos) {
		for (const auto& _wp : waypoints) {
			if (text == _wp.first) {
				return false;
			}
		}
		waypoints[text] = pos;
		return true;
	}

	bool remove(std::string name) {
		for (const auto& _wp : waypoints) {
			if (name == _wp.first) {
				waypoints.erase(name);
				return true;
			}
		}
		return false;
	}

	vec3_t* getWaypoint(std::string name) {
		if (waypoints.find(name) == waypoints.end())
			return nullptr;

		return &waypoints[name];
	};
};