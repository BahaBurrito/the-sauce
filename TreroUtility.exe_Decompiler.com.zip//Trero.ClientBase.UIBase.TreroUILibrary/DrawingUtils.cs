using System.Drawing;
using System.Windows.Forms;

namespace Trero.ClientBase.UIBase.TreroUILibrary
{
	internal class DrawingUtils
	{
		public static Vector2 screenCenter
		{
			get
			{
				//IL_0017: Unknown result type (might be due to invalid IL or missing references)
				//IL_001c: Unknown result type (might be due to invalid IL or missing references)
				//IL_0033: Unknown result type (might be due to invalid IL or missing references)
				//IL_0038: Unknown result type (might be due to invalid IL or missing references)
				Vector2 result = Base.Vec2();
				Size size = ((Form)Overlay.handle).get_Size();
				result.x = ((Size)(ref size)).get_Width() / 2;
				size = ((Form)Overlay.handle).get_Size();
				result.y = ((Size)(ref size)).get_Height() / 2;
				return result;
			}
		}

		public static Vector2 logoVCenter
		{
			get
			{
				//IL_0017: Unknown result type (might be due to invalid IL or missing references)
				//IL_001c: Unknown result type (might be due to invalid IL or missing references)
				//IL_0033: Unknown result type (might be due to invalid IL or missing references)
				//IL_0038: Unknown result type (might be due to invalid IL or missing references)
				Vector2 result = Base.Vec2();
				Size size = ((Form)Overlay.handle).get_Size();
				result.x = ((Size)(ref size)).get_Width() / 2;
				size = ((Form)Overlay.handle).get_Size();
				result.y = ((Size)(ref size)).get_Height() / 4;
				return result;
			}
		}

		public static Vector2 logoCenter
		{
			get
			{
				//IL_0017: Unknown result type (might be due to invalid IL or missing references)
				//IL_001c: Unknown result type (might be due to invalid IL or missing references)
				//IL_0033: Unknown result type (might be due to invalid IL or missing references)
				//IL_0038: Unknown result type (might be due to invalid IL or missing references)
				Vector2 result = Base.Vec2();
				Size size = ((Form)Overlay.handle).get_Size();
				result.x = ((Size)(ref size)).get_Width() / 2;
				size = ((Form)Overlay.handle).get_Size();
				result.y = ((Size)(ref size)).get_Height() / 5;
				return result;
			}
		}

		public static int screenSize
		{
			get
			{
				//IL_001a: Unknown result type (might be due to invalid IL or missing references)
				//IL_001f: Unknown result type (might be due to invalid IL or missing references)
				//IL_0031: Unknown result type (might be due to invalid IL or missing references)
				//IL_0036: Unknown result type (might be due to invalid IL or missing references)
				if (Overlay.handle == null)
				{
					return 0;
				}
				int num = 1;
				int num2 = 200;
				for (int i = 1; i < 255; i++)
				{
					Size size = ((Form)Overlay.handle).get_Size();
					if (((Size)(ref size)).get_Width() <= i * num2)
					{
						break;
					}
					size = ((Form)Overlay.handle).get_Size();
					if (((Size)(ref size)).get_Height() <= i * num2)
					{
						break;
					}
					num++;
				}
				return num;
			}
		}
	}
}
