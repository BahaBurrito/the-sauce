using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace Trero.ClientBase.UIBase.TreroUILibrary
{
	internal class RenderClass
	{
		public static bool destroy;

		[DllImport("User32.dll")]
		public static extern IntPtr GetDC(IntPtr hwnd);

		[DllImport("User32.dll")]
		public static extern int ReleaseDC(IntPtr hwnd, IntPtr dc);

		public static void CreateAction(Action<Graphics> RenderAction, IntPtr hwnd)
		{
			IntPtr context = GetDC(hwnd);
			Task.Run(delegate
			{
				while (!destroy)
				{
					while (true)
					{
						try
						{
							Graphics val = Graphics.FromHdc(context);
							try
							{
								RenderAction(val);
							}
							finally
							{
								((IDisposable)val)?.Dispose();
							}
						}
						catch
						{
							continue;
						}
						break;
					}
				}
				ReleaseDC(hwnd, context);
			});
		}

		public static void SingleAction(Action<Graphics> RenderAction, IntPtr hwnd)
		{
			IntPtr dC = GetDC(hwnd);
			while (true)
			{
				try
				{
					Graphics val = Graphics.FromHdc(dC);
					try
					{
						RenderAction(val);
					}
					finally
					{
						((IDisposable)val)?.Dispose();
					}
					return;
				}
				catch
				{
				}
			}
		}

		public static void ReleaseAction(IntPtr hwnd)
		{
			IntPtr dC = GetDC(hwnd);
			ReleaseDC(hwnd, dC);
		}

		public static void ClearActions()
		{
			destroy = true;
			Thread.Sleep(5);
			destroy = false;
		}
	}
}
