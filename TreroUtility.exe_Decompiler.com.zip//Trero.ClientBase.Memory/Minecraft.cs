using Trero.ClientBase.Memory.SDK;

namespace Trero.ClientBase.Memory
{
	public class Minecraft
	{
		public static ClientInstance CI => new ClientInstance(MCM.baseEvaluatePointer(69190304uL, new ulong[2]
		{
			0uL,
			80uL
		}));
	}
}
