namespace Trero.ClientBase.Memory.SDK
{
	public class Actor : SDKObj
	{
		public Actor(ulong addr)
			: base(addr)
		{
		}
	}
}
