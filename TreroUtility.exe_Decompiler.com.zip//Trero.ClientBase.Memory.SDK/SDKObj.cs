namespace Trero.ClientBase.Memory.SDK
{
	public abstract class SDKObj
	{
		public ulong addr;

		public SDKObj(ulong addr)
		{
			this.addr = addr;
		}
	}
}
