namespace Trero.ClientBase.Memory.SDK
{
	public class LocalPlayer : Actor
	{
		public PlayerAttributes playerAttributes => new PlayerAttributes(MCM.evaluatePointer(addr + 490, MCM.ceByte2uLong("18 2C0 0")));

		public LocalPlayer(ulong addr)
			: base(addr)
		{
		}
	}
}
