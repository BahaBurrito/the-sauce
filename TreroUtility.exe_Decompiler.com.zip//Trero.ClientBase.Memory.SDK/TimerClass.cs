namespace Trero.ClientBase.Memory.SDK
{
	public class TimerClass : SDKObj
	{
		public float timer
		{
			get
			{
				return MCM.readFloat(MCM.readInt64(addr));
			}
			set
			{
				MCM.writeFloat(MCM.readInt64(addr), value);
			}
		}

		public TimerClass(ulong addr)
			: base(addr)
		{
		}
	}
}
