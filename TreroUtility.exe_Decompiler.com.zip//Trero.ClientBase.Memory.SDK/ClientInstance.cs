using System.Drawing;

namespace Trero.ClientBase.Memory.SDK
{
	public class ClientInstance : SDKObj
	{
		public ulong packetFuncAddr => MCM.evaluatePointer(addr + 208, new ulong[3]
		{
			0uL,
			8uL,
			0uL
		});

		public LocalPlayer localPlayer => new LocalPlayer(MCM.readInt64(addr + 138));

		public TimerClass timerClass => new TimerClass(MCM.evaluatePointer(addr, MCM.ceByte2uLong("B0 D0")));

		public ClientInstance(ulong addr)
			: base(addr)
		{
		}

		public bool isIngame()
		{
			return localPlayer.addr != 0;
		}

		public void SendNotification(string str, int dur, Color colour)
		{
		}
	}
}
