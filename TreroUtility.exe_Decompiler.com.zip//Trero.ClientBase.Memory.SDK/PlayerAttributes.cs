namespace Trero.ClientBase.Memory.SDK
{
	public class PlayerAttributes : SDKObj
	{
		public float speed
		{
			get
			{
				return MCM.readFloat(addr + 156);
			}
			set
			{
				MCM.writeFloat(addr + 156, value);
			}
		}

		public PlayerAttributes(ulong addr)
			: base(addr)
		{
		}
	}
}
