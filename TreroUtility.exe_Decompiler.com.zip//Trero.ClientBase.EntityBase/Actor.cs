using System;
using System.Collections.Generic;
using System.Linq;
using Trero.ClientBase.VersionBase;

namespace Trero.ClientBase.EntityBase
{
	internal class Actor
	{
		public ulong addr;

		public bool isValid => MCM.readInt(addr) != 0;

		public Vector3 position
		{
			get
			{
				Vector3 result = Base.Vec3();
				result.x = MCM.readFloat(addr + VersionClass.GetData("positionX"));
				result.y = MCM.readFloat(addr + VersionClass.GetData("positionX") + 4);
				result.z = MCM.readFloat(addr + VersionClass.GetData("positionX") + 8);
				return result;
			}
			set
			{
				Teleport(value);
			}
		}

		public int gamemode
		{
			get
			{
				return (int)(MCM.readInt64(addr + VersionClass.GetData("positionX")) / 4294967296uL);
			}
			set
			{
				MCM.writeInt64(addr + VersionClass.GetData("positionX"), (ulong)(value * 4294967296L));
			}
		}

		public int isFalling
		{
			get
			{
				return (int)MCM.readInt64(addr + VersionClass.GetData("JumpForBHop"));
			}
			set
			{
				MCM.writeInt64(addr + VersionClass.GetData("JumpForBHop"), (ulong)value);
			}
		}

		public Vector3 velocity
		{
			get
			{
				Vector3 result = Base.Vec3();
				result.x = MCM.readFloat(addr + VersionClass.GetData("velocity"));
				result.y = MCM.readFloat(addr + VersionClass.GetData("velocity") + 4);
				result.z = MCM.readFloat(addr + VersionClass.GetData("velocity") + 8);
				return result;
			}
			set
			{
				MCM.writeFloat(addr + VersionClass.GetData("velocity"), value.x);
				MCM.writeFloat(addr + VersionClass.GetData("velocity") + 4, value.y);
				MCM.writeFloat(addr + VersionClass.GetData("velocity") + 8, value.z);
			}
		}

		public Vector2 rotation
		{
			get
			{
				Vector2 result = Base.Vec2();
				result.x = MCM.readFloat(addr + VersionClass.GetData("bodyRots"));
				result.y = MCM.readFloat(addr + VersionClass.GetData("bodyRots") + 4);
				return result;
			}
		}

		public Vector2 compassRotations
		{
			get
			{
				Vector2 vec = rotation;
				vec.y = Enumerable.First<float>((IEnumerable<float>)Enumerable.OrderBy<float, float>((IEnumerable<float>)new float[4]
				{
					1f,
					2f,
					3f,
					4f
				}, (Func<float, float>)((float v) => Math.Abs((float)(long)v - (vec.y + 180f) / 90f))));
				vec.x = Enumerable.First<float>((IEnumerable<float>)Enumerable.OrderBy<float, float>((IEnumerable<float>)new float[4]
				{
					1f,
					2f,
					3f,
					4f
				}, (Func<float, float>)((float v) => Math.Abs((float)(long)v - (vec.x + 90f) / 180f))));
				return vec;
			}
		}

		public bool onGround
		{
			get
			{
				return MCM.readInt(addr + VersionClass.GetData("onGround")) != 0;
			}
			set
			{
				if (value)
				{
					MCM.writeInt(addr + VersionClass.GetData("onGround"), 16777473);
				}
				else
				{
					MCM.writeInt(addr + VersionClass.GetData("onGround"), 0);
				}
			}
		}

		public bool onGround2 => MCM.readInt(addr + VersionClass.GetData("onGround2")) != 0;

		public string username => MCM.readString(addr + VersionClass.GetData("username"), 32uL);

		public string type => MCM.readString(addr + VersionClass.GetData("entityType"), 32uL);

		public Vector2 hitbox
		{
			get
			{
				Vector2 result = Base.Vec2();
				result.x = MCM.readFloat(addr + VersionClass.GetData("hitbox"));
				result.y = MCM.readFloat(addr + VersionClass.GetData("hitbox") + 4);
				return result;
			}
			set
			{
				MCM.writeFloat(addr + VersionClass.GetData("hitbox"), value.x);
				MCM.writeFloat(addr + VersionClass.GetData("hitbox") + 4, value.y);
			}
		}

		public int heldItemCount => MCM.readInt(addr + VersionClass.GetData("helditemCount"));

		public int holdItem => MCM.readInt(addr + VersionClass.GetData("holdItem"));

		public int holdItemId => MCM.readInt(addr + VersionClass.GetData("holdItemId"));

		public int swingAn
		{
			get
			{
				return MCM.readInt(addr + VersionClass.GetData("swingAn"));
			}
			set
			{
				MCM.writeInt(addr + VersionClass.GetData("swingAn"), value);
			}
		}

		public Actor(ulong addr)
		{
			this.addr = addr;
		}

		public void Teleport(AABB advancedAxis)
		{
			MCM.writeFloat(addr + VersionClass.GetData("positionX"), advancedAxis.lower.x);
			MCM.writeFloat(addr + VersionClass.GetData("positionX") + 4, advancedAxis.lower.y);
			MCM.writeFloat(addr + VersionClass.GetData("positionX") + 8, advancedAxis.lower.z);
			MCM.writeFloat(addr + VersionClass.GetData("positionX") + 12, advancedAxis.upper.x);
			MCM.writeFloat(addr + VersionClass.GetData("positionX") + 16, advancedAxis.upper.y);
			MCM.writeFloat(addr + VersionClass.GetData("positionX") + 20, advancedAxis.upper.z);
		}

		public void Teleport(float x, float y, float z)
		{
			Teleport(new AABB(Base.Vec3(x, y, z), Base.Vec3(x + 0.6f, y + 1.8f, z + 0.6f)));
		}

		public void Teleport(Vector3 _Vec3)
		{
			Teleport(_Vec3.x, _Vec3.y, _Vec3.z);
		}
	}
}
