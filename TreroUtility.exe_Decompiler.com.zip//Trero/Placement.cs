using System.Drawing;

namespace Trero
{
	public struct Placement
	{
		public int length;

		public int flags;

		public int showCmd;

		public Point ptMinPosition;

		public Point ptMaxPosition;

		public Rectangle rcNormalPosition;
	}
}
