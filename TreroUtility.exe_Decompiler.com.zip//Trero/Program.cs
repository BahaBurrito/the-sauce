using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.UIBase;
using Trero.ClientBase.VersionBase;
using Trero.Modules;
using Trero.Modules.vModuleExtra;

namespace Trero
{
	internal static class Program
	{
		public static bool quit;

		public static bool limiter;

		public static bool unlimiter;

		public static EventHandler<EventArgs> mainThread;

		public static EventHandler<EventArgs> moduleToggled;

		public static List<Module> Modules = new List<Module>();

		private static bool debugmode = true;

		public static Font font = new Font("Arial", 16f, (FontStyle)0);

		private static void Main(string[] args)
		{
			//IL_049e: Unknown result type (might be due to invalid IL or missing references)
			VersionClass.init();
			try
			{
				_ = Process.GetProcessesByName("Minecraft.Windows")[0];
			}
			catch
			{
				try
				{
					Process.GetProcessesByName("ApplicationFrameHost")[0].Kill();
				}
				catch
				{
				}
			}
			Process.Start("minecraft://");
			MCM.openGame("Minecraft.Windows");
			MCM.openWindowHost("ApplicationFrameHost", "Minecraft");
			new Keymap();
			Console.WriteLine(" _____                 ");
			Console.WriteLine("|_   _|___ ___ ___ ___ ");
			Console.WriteLine("  | | |  _| -_|  _| . |");
			Console.WriteLine("  |_| |_| |___|_| |___|");
			Console.WriteLine("Trero v" + VersionClass.currentVersion.name);
			Task.Run(delegate
			{
				Application.Run((Form)(object)new Overlay());
			});
			Console.WriteLine("Registering modules...");
			Modules.Add(new ClickGUI());
			Modules.Add(new Antibot());
			Modules.Add(new Trero.Modules.Debug());
			Modules.Add(new AirStuck());
			Modules.Add(new BulkFly());
			Modules.Add(new AirJump());
			Modules.Add(new FlickerExample());
			Modules.Add(new Phase());
			Modules.Add(new Noclip());
			Modules.Add(new NoYFly());
			Modules.Add(new PhaseDown());
			Modules.Add(new PhaseUp());
			Modules.Add(new Fly());
			Modules.Add(new Jetpack());
			Modules.Add(new Eject());
			Modules.Add(new Speed());
			Modules.Add(new Bhop());
			Modules.Add(new Spider());
			Modules.Add(new LBSH());
			Modules.Add(new Gamemode());
			Modules.Add(new Teleport());
			Modules.Add(new Step());
			Modules.Add(new HighJump());
			Modules.Add(new InventoryMove());
			Modules.Add(new KillGame());
			Modules.Add(new Jesus());
			Modules.Add(new NoSwing());
			Modules.Add(new CreativeFly());
			Modules.Add(new PlayerTP());
			Modules.Add(new ClickTP());
			Modules.Add(new Glide());
			Modules.Add(new Limiter());
			Modules.Add(new Unlimiter());
			Modules.Add(new Friends());
			Modules.Add(new Nofriends());
			Modules.Add(new MineplexFly());
			Modules.Add(new LongJump());
			Modules.Add(new Zoom());
			Modules.Add(new AutoWalk());
			Modules.Add(new StreamMode());
			Modules.Add(new Masturbator());
			Modules.Add(new Welcome());
			Modules.Add(new MineplexFlyv2());
			Modules.Add(new RainbowEffects());
			Modules.Add(new RapidHit());
			Modules.Add(new RapidPlace());
			Modules.Add(new OGMFly());
			Modules.Add(new FastFly());
			Modules.Add(new Velocity());
			Modules.Add(new Disabler());
			Modules.Add(new InPvPTower());
			Modules.Add(new FastWater());
			Modules.Add(new FixHitbox());
			Modules.Add(new MineplexStep());
			Modules.Add(new HiveBhop());
			Modules.Add(new Reach());
			Modules.Add(new HiveFly());
			Modules.Add(new TestModule());
			Console.WriteLine("Registered modules!");
			if (debugmode)
			{
				Console.WriteLine("Registering DEBUG_MODULES...");
				Console.WriteLine("Registered DEBUG_MODULES!");
			}
			Modules.Sort((Module c1, Module c2) => string.Compare(c2.name, c1.name, StringComparison.Ordinal));
			Console.WriteLine("Checking for config...");
			if (File.Exists("config.json"))
			{
				Console.WriteLine("Found config!");
				ConfigIO configIO = new JavaScriptSerializer().Deserialize<ConfigIO>(File.ReadAllText("config.json"));
				foreach (Module module in Modules)
				{
					int num = 0;
					foreach (string moduleName in configIO.moduleNames)
					{
						if (module.name == moduleName)
						{
							module.enabled = configIO.enableStates[num];
							int num2 = 0;
							foreach (BypassBox bypass in module.bypasses)
							{
								_ = bypass;
								module.bypasses[num2].curIndex = configIO.moduleBypasses[num][num2];
								num2++;
							}
							module.keybind = configIO.moduleKeybinds[num];
						}
						num++;
					}
				}
			}
			else
			{
				Console.WriteLine("No config found, ignoring...");
			}
			Console.WriteLine("Welcome to the trero terminal");
			Console.WriteLine("");
			mainThread = (EventHandler<EventArgs>)Delegate.Combine(mainThread, new EventHandler<EventArgs>(moduleTick));
			Task.Run(delegate
			{
				while (!quit)
				{
					try
					{
						if (limiter && !unlimiter)
						{
							Thread.Sleep(1);
						}
						if (!unlimiter)
						{
							Thread.Sleep(1);
						}
						Thread.Sleep(5);
						mainThread(null, new EventArgs());
					}
					catch
					{
					}
				}
			});
			Console.WriteLine(".help for help!");
			while (!quit)
			{
				string text = Console.ReadLine();
				if (!text.StartsWith("."))
				{
					continue;
				}
				string[] array = "0,0,0,0,0,0,0".Split(new char[1]
				{
					','
				});
				string text2 = text.Replace(".", "");
				try
				{
					array = text.Split(new char[1]
					{
						' '
					});
					text2 = array[0].Replace(".", "");
					array = Enumerable.ToArray<string>(Enumerable.Skip<string>((IEnumerable<string>)array, 1));
				}
				catch
				{
				}
				switch (text2)
				{
				case "help":
					Console.WriteLine("");
					Console.WriteLine("--- Commands ---");
					Console.WriteLine(".help - List commands");
					Console.WriteLine(".coords - Display your coords");
					Console.WriteLine(".gamemode (id) - Change your gamemode");
					Console.WriteLine(".tp (x) (y) (z) - Teleport to any coords you want");
					Console.WriteLine(".vclip (num) - VClip set amount of blocks");
					Console.WriteLine(".vflip (num) - VFlip set amount of blocks");
					Console.WriteLine(".modules - Prints list of modules to console");
					Console.WriteLine(".toggle (module) - Toggles a module");
					Console.WriteLine("");
					break;
				case "coords":
					Console.WriteLine((object)Game.position);
					Console.WriteLine("");
					break;
				case "gamemode":
					if (array.Length >= 1)
					{
						new GamemodeRegistery(out var list);
						for (int k = 0; k < list.Count; k++)
						{
							for (int l = 0; l < list[k].Count; l++)
							{
								if (array[0] == list[k][l])
								{
									Game.gamemode = k;
									Console.WriteLine("Gamemode changed to " + list[k][2]);
								}
							}
						}
					}
					Console.WriteLine("");
					break;
				case "tp":
					if (array.Length >= 3)
					{
						Game.position = Base.Vec3(array[0], array[1], array[2]);
						Console.WriteLine("Teleported to " + Game.position.ToString());
					}
					Console.WriteLine("");
					break;
				case "vclip":
					if (array.Length >= 1)
					{
						Game.vclip(Convert.ToInt32(array[0]));
						Console.WriteLine("VClipped " + array[0] + " blocks");
					}
					Console.WriteLine("");
					break;
				case "vflip":
					if (array.Length >= 1)
					{
						Game.vflip(Convert.ToInt32(array[0]));
						Console.WriteLine("VFlipped " + array[0] + " blocks");
					}
					Console.WriteLine("");
					break;
				case "modules":
				{
					Modules.Reverse();
					for (int j = 0; j < Modules.Count; j++)
					{
						Console.WriteLine(j + 1 + ". " + Modules[j].name);
					}
					Modules.Reverse();
					Console.WriteLine("");
					break;
				}
				case "toggle":
				{
					for (int i = 0; i < Modules.Count; i++)
					{
						if (Modules[i].name.ToLower() == array[0])
						{
							if (Modules[i].enabled)
							{
								Modules[i].OnDisable();
							}
							else
							{
								Modules[i].OnEnable();
							}
							Console.WriteLine("[" + Modules[i].enabled + "] " + Modules[i].name);
						}
					}
					moduleToggled(null, new EventArgs());
					Console.WriteLine("");
					break;
				}
				default:
					Console.WriteLine("Invalid command!");
					Console.WriteLine("");
					break;
				}
			}
		}

		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool GetWindowPlacement(IntPtr hWnd, ref Placement lpwndpl);

		private static void moduleTick(object sender, EventArgs e)
		{
			foreach (Module item in Enumerable.Where<Module>((IEnumerable<Module>)Modules, (Func<Module, bool>)((Module mod) => mod.enabled)))
			{
				item.OnTick();
			}
		}
	}
}
