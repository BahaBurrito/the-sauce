namespace Trero.Modules.vModuleExtra
{
	internal class BypassBox
	{
		public string[] list;

		public int curIndex;

		public BypassBox(string[] list)
		{
			this.list = list;
		}
	}
}
