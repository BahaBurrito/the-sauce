namespace Trero.ClientBase.KeyBase
{
	public enum VKeyCodes
	{
		KeyDown,
		KeyHeld,
		KeyUp
	}
}
