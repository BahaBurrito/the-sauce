using System;
using System.Runtime.InteropServices;

namespace Trero.ClientBase.KeyBase
{
	public class Mouse
	{
		[Flags]
		public enum MouseEventFlags
		{
			MOUSEEVENTF_LEFTDOWN = 0x2,
			MOUSEEVENTF_RIGHTDOWN = 0x8,
			MOUSEEVENTF_MIDDLEDOWN = 0x20
		}

		[DllImport("user32.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Auto)]
		public static extern void mouse_event(long dwFlags, long dx, long dy, long cButtons, long dwExtraInfo);

		public static void MouseEvent(MouseEventFlags keyFlag)
		{
			switch (keyFlag)
			{
			case MouseEventFlags.MOUSEEVENTF_LEFTDOWN:
				mouse_event(2L, 0L, 0L, 0L, 0L);
				mouse_event(4L, 0L, 0L, 0L, 0L);
				break;
			case MouseEventFlags.MOUSEEVENTF_RIGHTDOWN:
				mouse_event(8L, 0L, 0L, 0L, 0L);
				mouse_event(16L, 0L, 0L, 0L, 0L);
				break;
			case MouseEventFlags.MOUSEEVENTF_MIDDLEDOWN:
				mouse_event(32L, 0L, 0L, 0L, 0L);
				mouse_event(64L, 0L, 0L, 0L, 0L);
				break;
			}
		}
	}
}
