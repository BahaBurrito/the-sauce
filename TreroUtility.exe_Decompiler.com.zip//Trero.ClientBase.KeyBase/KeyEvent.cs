using System;
using System.Windows.Forms;

namespace Trero.ClientBase.KeyBase
{
	public class KeyEvent : EventArgs
	{
		public Keys key;

		public VKeyCodes vkey;

		public KeyEvent(char v, VKeyCodes c)
		{
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			key = (Keys)v;
			vkey = c;
		}

		public KeyEvent(Keys v, VKeyCodes c)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Unknown result type (might be due to invalid IL or missing references)
			key = v;
			vkey = c;
		}
	}
}
