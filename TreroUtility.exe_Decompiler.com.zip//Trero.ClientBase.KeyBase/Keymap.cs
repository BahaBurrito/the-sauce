using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace Trero.ClientBase.KeyBase
{
	internal class Keymap
	{
		public static int e;

		public static Keymap handle;

		public static EventHandler<KeyEvent> keyEvent;

		public static EventHandler<KeyEvent> globalKeyEvent;

		private readonly Dictionary<char, uint> _dBuff = new Dictionary<char, uint>();

		private readonly Dictionary<char, bool> _noKey = new Dictionary<char, bool>();

		private readonly Dictionary<char, uint> _rBuff = new Dictionary<char, uint>();

		private readonly Dictionary<char, bool> _yesKey = new Dictionary<char, bool>();

		public Keymap()
		{
			handle = this;
			for (char c = '\0'; c < 'ÿ'; c = (char)(c + 1))
			{
				_rBuff.Add(c, 0u);
				_dBuff.Add(c, 0u);
				_noKey.Add(c, value: true);
				_yesKey.Add(c, value: true);
			}
			Program.mainThread = (EventHandler<EventArgs>)Delegate.Combine(Program.mainThread, new EventHandler<EventArgs>(keyTick));
		}

		private void keyTick(object sender, EventArgs e)
		{
			try
			{
				for (char c = '\0'; c < 'ÿ'; c = (char)(c + 1))
				{
					_noKey[c] = true;
					_yesKey[c] = false;
					if (GetAsyncKeyState(c))
					{
						if (keyEvent != null && MCM.isGameFocused())
						{
							keyEvent(this, new KeyEvent(c, VKeyCodes.KeyHeld));
						}
						_noKey[c] = false;
						if (_dBuff[c] != 0)
						{
							continue;
						}
						_dBuff[c]++;
						try
						{
							if (keyEvent != null && MCM.isGameFocused())
							{
								keyEvent(this, new KeyEvent(c, VKeyCodes.KeyDown));
							}
						}
						catch
						{
						}
					}
					else
					{
						_yesKey[c] = true;
						if (_rBuff[c] != 0)
						{
							continue;
						}
						_rBuff[c]++;
						try
						{
							if (keyEvent != null && MCM.isGameFocused())
							{
								keyEvent(this, new KeyEvent(c, VKeyCodes.KeyUp));
							}
						}
						catch
						{
						}
					}
					if (_noKey[c])
					{
						_dBuff[c] = 0u;
					}
					if (!_yesKey[c])
					{
						_rBuff[c] = 0u;
					}
				}
			}
			catch
			{
			}
		}

		[DllImport("user32.dll")]
		public static extern bool GetAsyncKeyState(char v);

		[DllImport("user32.dll")]
		public static extern bool GetAsyncKeyState(Keys v);

		[DllImport("user32.dll")]
		public static extern bool GetAsyncKeyState(int v);

		[DllImport("user32.dll")]
		private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

		[DllImport("user32.dll")]
		private static extern IntPtr GetForegroundWindow();

		public static bool IsMinecraftFocused()
		{
			StringBuilder stringBuilder = new StringBuilder("Minecraft".Length + 1);
			GetWindowText(GetForegroundWindow(), stringBuilder, "Minecraft".Length + 1);
			return string.Compare(stringBuilder.ToString(), "Minecraft", StringComparison.Ordinal) == 0;
		}
	}
}
