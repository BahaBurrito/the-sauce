using System.Collections.Generic;
using System.Linq;

namespace Trero.ClientBase.VersionBase
{
	internal class IVersion
	{
		public string name;

		public object[] sdk;

		public IVersion(object[] list)
		{
			name = list[0].ToString();
			sdk = Enumerable.ToArray<object>(Enumerable.Skip<object>((IEnumerable<object>)list, 1));
		}
	}
}
