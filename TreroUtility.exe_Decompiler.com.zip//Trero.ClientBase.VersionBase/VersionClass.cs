using System.Collections.Generic;

namespace Trero.ClientBase.VersionBase
{
	internal class VersionClass
	{
		public static List<IVersion> versions = new List<IVersion>();

		public static IVersion versionStruct = new IVersion(new object[71]
		{
			"version",
			"baseOffset",
			"baseOffset+1",
			"baseOffset+2",
			"baseOffset+3",
			"onGround",
			"onGround2",
			"stepHeight",
			"worldAge",
			"gamemode",
			"isFlying",
			"blocksTraveled_Ex",
			"blocksTraveled",
			"helditemCount",
			"holdingItem",
			"holdingItemId",
			"selectedHotbarId",
			"viewCreativeItems",
			"viewCreativeItemsSelectedCategory",
			"entityType",
			"inInventory",
			"username",
			"gameDim",
			"gameDim+1",
			"positionX",
			"hitbox",
			"velocity",
			"swingAn",
			"lookingEntityId",
			"inWater",
			"bodyRots",
			"dimension",
			"level",
			"entitylist+1",
			"entitylist+2",
			"lookingAtBlock",
			"SelectedBlock",
			"SideSelect",
			"screenT+1",
			"screenT+2",
			"chatBase",
			"chatBase+1",
			"chatBase+2",
			"chatBase+3",
			"chatBase+4",
			"fieldOfView",
			"EffectsClass+1",
			"EffectsClass+2",
			"EffectsColor",
			"SpeedClass+1",
			"SpeedClass+2",
			"SpeedClass+3",
			"SpeedValue",
			"gameMap+1",
			"gameMap+2",
			"gameMap+3",
			"gameMap+4",
			"inMenu",
			"Hitting",
			"Placing",
			"Picking",
			"mouseX",
			"mouseY",
			"eKeymap",
			"onGround3",
			"isInLava",
			"walkingIntoBlock",
			"exactPos",
			"timer1",
			"timer2",
			"loopbackSender"
		});

		private static IVersion _cv;

		public static IVersion currentVersion => _cv ?? (_cv = versions[0]);

		public static void init()
		{
			versions.Add(new IVersion(new object[71]
			{
				"MCBE-1.19.20",
				72767512,
				0,
				24,
				184,
				472,
				476,
				568,
				680,
				7556,
				2432,
				576,
				600,
				9072,
				9066,
				0,
				9176,
				0,
				0,
				1024,
				4424,
				2000,
				864,
				0,
				1216,
				0,
				1272,
				1992,
				0,
				605,
				312,
				872,
				880,
				168,
				176,
				2600,
				2608,
				2716,
				0,
				0,
				0,
				0,
				0,
				0,
				0,
				4184,
				376,
				64,
				16,
				1168,
				24,
				704,
				156,
				68620376,
				1168,
				672,
				8,
				75,
				80,
				81,
				82,
				312,
				314,
				318,
				473,
				713,
				474,
				8524,
				176,
				208,
				208
			}));
		}

		public static ulong GetData(string data)
		{
			for (int i = 0; i < versionStruct.sdk.Length; i++)
			{
				if (versionStruct.sdk[i].ToString() == data)
				{
					return HexHandler.ToULong(currentVersion.sdk[i]);
				}
			}
			return 0uL;
		}

		public static void setVersion(IVersion version)
		{
			_cv = version;
		}
	}
}
