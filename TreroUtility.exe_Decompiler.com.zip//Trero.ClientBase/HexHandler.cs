using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Trero.ClientBase
{
	public class HexHandler
	{
		public static string ToHex(int value)
		{
			return value.ToString("X");
		}

		public static int ToInt(string value)
		{
			return int.Parse(value, NumberStyles.HexNumber);
		}

		public static long ToLong(string value)
		{
			return Convert.ToInt64(value, 16);
		}

		public static ulong ToULong(object value)
		{
			return Convert.ToUInt64(value);
		}

		public static string AddBytes(string hexString, int bytes)
		{
			return ToHex(ToInt(hexString) + bytes);
		}

		public static Vector2 CompassClamp(float[] array, Vector2 c)
		{
			c.y = Enumerable.First<float>((IEnumerable<float>)Enumerable.OrderBy<float, float>((IEnumerable<float>)array, (Func<float, float>)((float v) => Math.Abs((float)(long)v - (c.y + 180f) / (360f / (float)array.Length)))));
			c.x = Enumerable.First<float>((IEnumerable<float>)Enumerable.OrderBy<float, float>((IEnumerable<float>)array, (Func<float, float>)((float v) => Math.Abs((float)(long)v - (c.x + 90f) / (180f / (float)array.Length)))));
			return c;
		}
	}
}
