using System.Collections.Generic;

namespace Trero.ClientBase
{
	public class GamemodeRegistery
	{
		private readonly List<List<string>> registery = new List<List<string>>
		{
			new List<string>
			{
				"0",
				"s",
				"survival"
			},
			new List<string>
			{
				"1",
				"c",
				"creative"
			},
			new List<string>
			{
				"2",
				"a",
				"adventure"
			}
		};

		public GamemodeRegistery(out List<List<string>> list)
		{
			list = registery;
		}
	}
}
