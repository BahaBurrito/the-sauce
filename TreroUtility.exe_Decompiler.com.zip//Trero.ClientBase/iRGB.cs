namespace Trero.ClientBase
{
	public struct iRGB
	{
		public byte R;

		public byte G;

		public byte B;

		public byte A;

		public iRGB(byte R, byte G, byte B, byte A = byte.MaxValue)
		{
			this.R = R;
			this.G = G;
			this.B = B;
			this.A = A;
		}

		public override string ToString()
		{
			return R + "," + G + "," + B;
		}
	}
}
