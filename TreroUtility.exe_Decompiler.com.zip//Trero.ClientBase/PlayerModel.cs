namespace Trero.ClientBase
{
	internal class PlayerModel
	{
		public int playerModelAddr;

		public bool allowArmPositioningX
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr) != 139)
					{
						MCM.writeBaseBytes(playerModelAddr, MCM.ceByte2Bytes("8B 81 10 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr) == 139)
				{
					MCM.writeBaseBytes(playerModelAddr, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool visualHandRenderX
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 6) != 137)
					{
						MCM.writeBaseBytes(playerModelAddr + 6, MCM.ceByte2Bytes("89 81 EC 00 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 6) == 137)
				{
					MCM.writeBaseBytes(playerModelAddr + 6, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool allowArmPositioningY
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 12) != 139)
					{
						MCM.writeBaseBytes(playerModelAddr + 12, MCM.ceByte2Bytes("8B 81 14 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 12) == 139)
				{
					MCM.writeBaseBytes(playerModelAddr + 12, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool visualHandRenderY
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 18) != 137)
					{
						MCM.writeBaseBytes(playerModelAddr + 18, MCM.ceByte2Bytes("89 81 F0 00 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 18) == 137)
				{
					MCM.writeBaseBytes(playerModelAddr + 18, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool allowArmPositioningZ
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 24) != 139)
					{
						MCM.writeBaseBytes(playerModelAddr + 24, MCM.ceByte2Bytes("8B 81 18 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 24) == 139)
				{
					MCM.writeBaseBytes(playerModelAddr + 24, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool visualHandRenderZ
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 30) != 137)
					{
						MCM.writeBaseBytes(playerModelAddr + 30, MCM.ceByte2Bytes("89 81 F4 00 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 30) == 137)
				{
					MCM.writeBaseBytes(playerModelAddr + 30, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool f5RenderX
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 36) != 139)
					{
						MCM.writeBaseBytes(playerModelAddr + 36, MCM.ceByte2Bytes("8B 81 1C 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 36) == 139)
				{
					MCM.writeBaseBytes(playerModelAddr + 36, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool bodySpinningX
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 42) != 137)
					{
						MCM.writeBaseBytes(playerModelAddr + 42, MCM.ceByte2Bytes("89 81 F8 00 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 42) == 137)
				{
					MCM.writeBaseBytes(playerModelAddr + 42, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool f5RenderY
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 48) != 139)
					{
						MCM.writeBaseBytes(playerModelAddr + 48, MCM.ceByte2Bytes("8B 81 20 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 48) == 139)
				{
					MCM.writeBaseBytes(playerModelAddr + 48, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool bodySpinningY
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 54) != 137)
					{
						MCM.writeBaseBytes(playerModelAddr + 54, MCM.ceByte2Bytes("89 81 FC 00 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 54) == 137)
				{
					MCM.writeBaseBytes(playerModelAddr + 54, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool f5RenderZ
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 60) != 139)
					{
						MCM.writeBaseBytes(playerModelAddr + 60, MCM.ceByte2Bytes("8B 81 24 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 60) == 139)
				{
					MCM.writeBaseBytes(playerModelAddr + 60, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool bodySpinningZ
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 66) != 137)
					{
						MCM.writeBaseBytes(playerModelAddr + 66, MCM.ceByte2Bytes("89 81 00 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 66) == 137)
				{
					MCM.writeBaseBytes(playerModelAddr + 66, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool allowModelScalingX
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 72) != 139)
					{
						MCM.writeBaseBytes(playerModelAddr + 72, MCM.ceByte2Bytes("8B 81 28 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 72) == 139)
				{
					MCM.writeBaseBytes(playerModelAddr + 72, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool _4dScalingX
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 78) != 137)
					{
						MCM.writeBaseBytes(playerModelAddr + 78, MCM.ceByte2Bytes("89 81 04 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 78) == 137)
				{
					MCM.writeBaseBytes(playerModelAddr + 78, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool allowModelScalingY
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 84) != 139)
					{
						MCM.writeBaseBytes(playerModelAddr + 84, MCM.ceByte2Bytes("8B 81 2C 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 84) == 139)
				{
					MCM.writeBaseBytes(playerModelAddr + 84, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool _4dScalingY
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 90) != 137)
					{
						MCM.writeBaseBytes(playerModelAddr + 90, MCM.ceByte2Bytes("89 81 08 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 90) == 137)
				{
					MCM.writeBaseBytes(playerModelAddr + 90, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool allowModelScalingZ
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 96) != 139)
					{
						MCM.writeBaseBytes(playerModelAddr + 96, MCM.ceByte2Bytes("8B 81 30 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 96) == 139)
				{
					MCM.writeBaseBytes(playerModelAddr + 96, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public bool _4dScalingZ
		{
			set
			{
				if (value)
				{
					if (MCM.readBaseByte(playerModelAddr + 102) != 137)
					{
						MCM.writeBaseBytes(playerModelAddr + 102, MCM.ceByte2Bytes("89 81 0C 01 00 00"));
					}
				}
				else if (MCM.readBaseByte(playerModelAddr + 102) == 137)
				{
					MCM.writeBaseBytes(playerModelAddr + 102, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public PlayerModel(int addr)
		{
			playerModelAddr = addr;
		}
	}
}
