using System;

namespace Trero.ClientBase
{
	public struct Vector2
	{
		public float x;

		public float y;

		public Vector2(float x, float y)
		{
			this.x = x;
			this.y = y;
		}

		public Vector2(string position)
		{
			try
			{
				string[] array = position.Replace(" ", "").Split(new char[1]
				{
					','
				});
				x = Convert.ToSingle(array[0]);
				y = Convert.ToSingle(array[1]);
			}
			catch
			{
				string[] array2 = position.Replace(" ", "").Split(new char[1]
				{
					','
				});
				x = HexHandler.ToLong(array2[0]);
				y = HexHandler.ToLong(array2[1]);
			}
		}

		public override string ToString()
		{
			return x + "," + y;
		}
	}
}
