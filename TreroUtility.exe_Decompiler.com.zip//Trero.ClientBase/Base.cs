namespace Trero.ClientBase
{
	internal static class Base
	{
		public static Vector3 Vec3(float _ = 0f, float v = 0f, float c = 0f)
		{
			return new Vector3(_, v, c);
		}

		public static Vector3 Vec3(string v)
		{
			return new Vector3(v);
		}

		public static Vector3 Vec3(string x, string y, string z)
		{
			return new Vector3(x + "," + y + "," + z);
		}

		public static iVector3 IVec3(int _ = 0, int v = 0, int c = 0)
		{
			return new iVector3(_, v, c);
		}

		public static Vector2 Vec2(float _ = 0f, float v = 0f)
		{
			return new Vector2(_, v);
		}

		public static Vector2 Vec2(string v)
		{
			return new Vector2(v);
		}

		public static ulong ToAddr(object v)
		{
			return (ulong)v;
		}
	}
}
