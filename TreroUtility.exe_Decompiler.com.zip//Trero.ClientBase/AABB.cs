namespace Trero.ClientBase
{
	public struct AABB
	{
		public Vector3 lower;

		public Vector3 upper;

		public AABB(Vector3 x, Vector3 y)
		{
			lower = x;
			upper = y;
		}
	}
}
