using System.Collections.Generic;

namespace Trero.ClientBase
{
	internal class ConfigIO
	{
		public List<List<int>> moduleBypasses = new List<List<int>>();

		public List<bool> enableStates = new List<bool>();

		public List<char> moduleKeybinds = new List<char>();

		public List<string> moduleNames = new List<string>();
	}
}
