using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace Trero.ClientBase
{
	public static class Ext
	{
		public static int ClosestTo(this IEnumerable<int> collection, int target)
		{
			int result = int.MaxValue;
			int num = int.MaxValue;
			foreach (int item in collection)
			{
				long num2 = Math.Abs((long)item - (long)target);
				if (num > num2)
				{
					num = (int)num2;
					result = item;
				}
			}
			return result;
		}

		public static T Clone<T>(this T controlToClone) where T : Control
		{
			PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Instance | BindingFlags.Public);
			T val = Activator.CreateInstance<T>();
			PropertyInfo[] array = properties;
			foreach (PropertyInfo propertyInfo in array)
			{
				if (propertyInfo.CanWrite && propertyInfo.Name != "WindowTarget")
				{
					propertyInfo.SetValue(val, propertyInfo.GetValue(controlToClone, null), null);
				}
			}
			return val;
		}

		public static IEnumerable<Control> GetAllChildren(this Control root)
		{
			Stack<Control> stack = new Stack<Control>();
			stack.Push(root);
			while (Enumerable.Any<Control>((IEnumerable<Control>)stack))
			{
				Control val = stack.Pop();
				foreach (Control item in (ArrangedElementCollection)val.get_Controls())
				{
					Control val2 = item;
					stack.Push(val2);
				}
				yield return val;
			}
		}
	}
}
