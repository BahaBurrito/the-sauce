using System;
using System.Threading;
using System.Threading.Tasks;

namespace Trero.ClientBase
{
	internal class Faketernal
	{
		public static class Potions
		{
			public static bool destroy;

			public static void ClearActions()
			{
				destroy = true;
				Thread.Sleep(10);
				destroy = false;
			}

			public static void CreateAction(Action<int, int> actionTick, iRGB effectColor, int time = 30, int strength = 1, float fov = 1f, Action actionExit = null)
			{
				bool effectActive = true;
				int timeLeft = time;
				Game.effectsColor = effectColor;
				Task.Run(delegate
				{
					Game.setFieldOfView(fov);
					while (!destroy && effectActive)
					{
						actionTick(strength, strength);
						Game.effectsColor = effectColor;
					}
					Game.effectsColor = new iRGB(0, 0, 0, 0);
					Game.setFieldOfView(1f);
					if (actionExit != null)
					{
						actionExit();
					}
				});
				Task.Run(delegate
				{
					for (int i = 0; i < time; i++)
					{
						Thread.Sleep(1000);
						timeLeft = i;
					}
					effectActive = false;
				});
			}
		}

		public static class Utils
		{
			public static float NextFloat(float min, float max)
			{
				return (float)(new Random().NextDouble() * (double)(max - min) + (double)min);
			}
		}
	}
}
