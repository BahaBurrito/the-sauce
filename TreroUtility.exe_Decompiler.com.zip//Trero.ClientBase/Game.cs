using System;
using System.Collections.Generic;
using System.Linq;
using Trero.ClientBase.EntityBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.VersionBase;

namespace Trero.ClientBase
{
	internal class Game
	{
		public static class CustomDefines
		{
			public static bool antibot = true;

			public static bool[] antibotStates = new bool[2]
			{
				true,
				false
			};

			public static bool nofriends = false;

			public static List<string> friends = new List<string>
			{
				"FootlongTrero"
			};
		}

		public static Random ran = new Random();

		public static ulong clientInstance => MCM.baseEvaluatePointer(HexHandler.ToULong(VersionClass.currentVersion.sdk[0]), new ulong[2]
		{
			VersionClass.GetData("baseOffset+1"),
			VersionClass.GetData("baseOffset+2")
		});

		public static ulong loopbackSender => MCM.evaluatePointer(HexHandler.ToULong(clientInstance), new ulong[2]
		{
			208uL,
			0uL
		});

		public static ulong nopacketAddr => MCM.evaluatePointer(HexHandler.ToULong(loopbackSender), new ulong[2]
		{
			8uL,
			0uL
		});

		public static ulong timerClass2 => MCM.evaluatePointer(HexHandler.ToULong(clientInstance), new ulong[3]
		{
			VersionClass.GetData("timer1"),
			VersionClass.GetData("timer2"),
			0uL
		});

		public static float timer
		{
			get
			{
				return MCM.readFloat(timerClass2);
			}
			set
			{
				MCM.writeFloat(timerClass2, value);
			}
		}

		public static ulong localPlayer => MCM.evaluatePointer(clientInstance, new ulong[2]
		{
			VersionClass.GetData("baseOffset+3"),
			0uL
		});

		public static ulong level => MCM.readInt64(localPlayer + VersionClass.GetData("level"));

		public static ulong dimension => MCM.readInt64(localPlayer + VersionClass.GetData("dimension"));

		public static ulong vEffectsClass => MCM.readInt64(localPlayer + VersionClass.GetData("EffectsClass+1"));

		public static ulong effectsClass => MCM.readInt64(vEffectsClass + VersionClass.GetData("EffectsClass+2"));

		public static ulong speedClass => MCM.readInt64(localPlayer + VersionClass.GetData("SpeedClass+1"));

		public static ulong speedSubClass => MCM.readInt64(speedClass + VersionClass.GetData("SpeedClass+2"));

		public static ulong speedSubSubClass => MCM.readInt64(speedSubClass + VersionClass.GetData("SpeedClass+3"));

		public static ulong keyInfo => MCM.baseEvaluatePointer(VersionClass.GetData("gameMap+1"), new ulong[2]
		{
			VersionClass.GetData("gameMap+2"),
			VersionClass.GetData("gameMap+3")
		});

		public static ulong eKeyInfo => MCM.evaluatePointer(keyInfo, new ulong[2]
		{
			VersionClass.GetData("gameMap+4"),
			0uL
		});

		public static ulong EntityListStart => MCM.readInt64(dimension + VersionClass.GetData("entitylist+1"));

		public static ulong EntityListEnd => MCM.readInt64(dimension + VersionClass.GetData("entitylist+2"));

		public static bool isNull
		{
			get
			{
				if (position.ToString() != "0,0,0")
				{
					return false;
				}
				return true;
			}
		}

		public static Vector3 position
		{
			get
			{
				Vector3 result = Base.Vec3();
				result.x = MCM.readFloat(localPlayer + VersionClass.GetData("positionX"));
				result.y = MCM.readFloat(localPlayer + VersionClass.GetData("positionX") + 4);
				result.z = MCM.readFloat(localPlayer + VersionClass.GetData("positionX") + 8);
				return result;
			}
			set
			{
				teleport(value);
			}
		}

		public static iRGB effectsColor
		{
			get
			{
				iRGB result = new iRGB(0, 0, 0);
				result.R = MCM.readByte(effectsClass + VersionClass.GetData("EffectsColor"));
				result.G = MCM.readByte(effectsClass + VersionClass.GetData("EffectsColor") + 1);
				result.B = MCM.readByte(effectsClass + VersionClass.GetData("EffectsColor") + 2);
				result.A = MCM.readByte(effectsClass + VersionClass.GetData("EffectsColor") + 3);
				return result;
			}
			set
			{
				MCM.writeByte(effectsClass + VersionClass.GetData("EffectsColor"), value.R);
				MCM.writeByte(effectsClass + VersionClass.GetData("EffectsColor") + 1, value.G);
				MCM.writeByte(effectsClass + VersionClass.GetData("EffectsColor") + 2, value.B);
				MCM.writeByte(effectsClass + VersionClass.GetData("EffectsColor") + 3, value.A);
			}
		}

		public static int gamemode
		{
			get
			{
				return MCM.readInt(localPlayer + VersionClass.GetData("gamemode"));
			}
			set
			{
				MCM.writeInt(localPlayer + VersionClass.GetData("gamemode"), value);
			}
		}

		public static int isFalling
		{
			get
			{
				return (int)MCM.readInt64(localPlayer + VersionClass.GetData("JumpForBHop"));
			}
			set
			{
				MCM.writeInt(localPlayer + VersionClass.GetData("JumpForBHop"), value);
			}
		}

		public static Vector3 velocity
		{
			get
			{
				Vector3 result = Base.Vec3();
				result.x = MCM.readFloat(localPlayer + VersionClass.GetData("velocity"));
				result.y = MCM.readFloat(localPlayer + VersionClass.GetData("velocity") + 4);
				result.z = MCM.readFloat(localPlayer + VersionClass.GetData("velocity") + 8);
				return result;
			}
			set
			{
				MCM.writeFloat(localPlayer + VersionClass.GetData("velocity"), value.x);
				MCM.writeFloat(localPlayer + VersionClass.GetData("velocity") + 4, value.y);
				MCM.writeFloat(localPlayer + VersionClass.GetData("velocity") + 8, value.z);
			}
		}

		public static Vector2 bodyRots
		{
			get
			{
				Vector2 result = Base.Vec2();
				result.x = MCM.readFloat(localPlayer + VersionClass.GetData("bodyRots"));
				result.y = MCM.readFloat(localPlayer + VersionClass.GetData("bodyRots") + 4);
				return result;
			}
			set
			{
				MCM.writeFloat(localPlayer + VersionClass.GetData("bodyRots"), value.x);
				MCM.writeFloat(localPlayer + VersionClass.GetData("bodyRots") + 4, value.y);
			}
		}

		public static Vector2 compassRotations
		{
			get
			{
				Vector2 vec = bodyRots;
				vec.y = Enumerable.First<float>((IEnumerable<float>)Enumerable.OrderBy<float, float>((IEnumerable<float>)new float[4]
				{
					1f,
					2f,
					3f,
					4f
				}, (Func<float, float>)((float v) => Math.Abs((float)(long)v - (vec.y + 180f) / 90f))));
				vec.x = Enumerable.First<float>((IEnumerable<float>)Enumerable.OrderBy<float, float>((IEnumerable<float>)new float[4]
				{
					1f,
					2f,
					3f,
					4f
				}, (Func<float, float>)((float v) => Math.Abs((float)(long)v - (vec.x + 90f) / 180f))));
				return vec;
			}
		}

		public static bool onGround
		{
			get
			{
				return MCM.readByte(localPlayer + VersionClass.GetData("onGround")) == 1;
			}
			set
			{
				MCM.writeByte(localPlayer + VersionClass.GetData("onGround"), (byte)((!value) ? 1 : 0));
			}
		}

		public static bool onGround2
		{
			get
			{
				return MCM.readByte(localPlayer + VersionClass.GetData("onGround3")) == 1;
			}
			set
			{
				MCM.writeByte(localPlayer + VersionClass.GetData("onGround3"), (byte)((!value) ? 1 : 0));
			}
		}

		public static byte inMenu
		{
			get
			{
				return MCM.readByte(eKeyInfo + VersionClass.GetData("inMenu"));
			}
			set
			{
				MCM.writeByte(eKeyInfo + VersionClass.GetData("inMenu"), value);
			}
		}

		public static byte Hitting
		{
			get
			{
				return MCM.readByte(eKeyInfo + VersionClass.GetData("Hitting"));
			}
			set
			{
				MCM.writeByte(eKeyInfo + VersionClass.GetData("Hitting"), value);
			}
		}

		public static byte Placing
		{
			get
			{
				return MCM.readByte(eKeyInfo + VersionClass.GetData("Placing"));
			}
			set
			{
				MCM.writeByte(eKeyInfo + VersionClass.GetData("Placing"), value);
			}
		}

		public static byte Picking
		{
			get
			{
				return MCM.readByte(eKeyInfo + VersionClass.GetData("Picking"));
			}
			set
			{
				MCM.writeByte(eKeyInfo + VersionClass.GetData("Picking"), value);
			}
		}

		public static short mouseX
		{
			get
			{
				return MCM.readInt16(eKeyInfo + VersionClass.GetData("mouseX"));
			}
			set
			{
				MCM.writeInt16(eKeyInfo + VersionClass.GetData("mouseX"), value);
			}
		}

		public static short mouseY
		{
			get
			{
				return MCM.readInt16(eKeyInfo + VersionClass.GetData("mouseY"));
			}
			set
			{
				MCM.writeInt16(eKeyInfo + VersionClass.GetData("mouseY"), value);
			}
		}

		public static bool isFlying
		{
			get
			{
				return MCM.readInt(localPlayer + VersionClass.GetData("isFlying")) != 0;
			}
			set
			{
				MCM.writeInt(localPlayer + VersionClass.GetData("isFlying"), (!value) ? 1 : 0);
			}
		}

		public static bool isInWater => MCM.readByte(localPlayer + VersionClass.GetData("inWater")) != 0;

		public static bool isInLava => MCM.readByte(localPlayer + VersionClass.GetData("isInLava")) != 0;

		public static bool inInventory => MCM.readInt(localPlayer + VersionClass.GetData("inInventory")) != 1;

		public static bool isLookingAtEntity => MCM.readInt(localPlayer + VersionClass.GetData("lookingEntityId")) != -1;

		public static ulong lookingEntityId
		{
			get
			{
				return MCM.readInt64(localPlayer + VersionClass.GetData("lookingEntityId"));
			}
			set
			{
				MCM.writeInt64(localPlayer + VersionClass.GetData("lookingEntityId"), value);
			}
		}

		public static int touchingObject => MCM.readInt(localPlayer + VersionClass.GetData("onGround2"));

		public static int walkingIntoBlock => MCM.readByte(localPlayer + VersionClass.GetData("walkingIntoBlock"));

		public static float stepHeight
		{
			get
			{
				return MCM.readFloat(localPlayer + VersionClass.GetData("stepHeight"));
			}
			set
			{
				MCM.writeFloat(localPlayer + VersionClass.GetData("stepHeight"), value);
			}
		}

		public static float FallDistance
		{
			get
			{
				return MCM.readFloat(localPlayer + VersionClass.GetData("onGround") - 4);
			}
			set
			{
				MCM.writeFloat(localPlayer + VersionClass.GetData("onGround") - 4, value);
			}
		}

		public static float speed
		{
			get
			{
				return MCM.readFloat(speedSubSubClass + VersionClass.GetData("SpeedValue"));
			}
			set
			{
				MCM.writeFloat(speedSubSubClass + VersionClass.GetData("SpeedValue"), value);
			}
		}

		public static Vector3 lVector
		{
			get
			{
				float x = (bodyRots.y + 89.9f) * (float)Math.PI / 178f;
				float y = bodyRots.x * (float)Math.PI / 178f;
				return dirVect(x, y);
			}
		}

		public static string username
		{
			get
			{
				return MCM.readString(localPlayer + VersionClass.GetData("username"), 32uL);
			}
			set
			{
				MCM.writeString(localPlayer + VersionClass.GetData("username"), value);
			}
		}

		public static string screenData => MCM.readString(MCM.baseEvaluatePointer(HexHandler.ToULong(VersionClass.GetData("screenT+1")), new ulong[1]
		{
			VersionClass.GetData("screenT+2")
		}), 128uL);

		public static string type => MCM.readString(localPlayer + VersionClass.GetData("entityType"), 64uL);

		public static int heldItemCount => MCM.readInt(localPlayer + VersionClass.GetData("helditemCount"));

		public static int holdItem => MCM.readInt(localPlayer + VersionClass.GetData("holdItem"));

		public static int holdItemId => MCM.readInt(localPlayer + VersionClass.GetData("holdItemId"));

		public static int swingAn
		{
			get
			{
				return MCM.readInt(localPlayer + VersionClass.GetData("swingAn"));
			}
			set
			{
				MCM.writeInt(localPlayer + VersionClass.GetData("swingAn"), value);
			}
		}

		public static int worldAge
		{
			get
			{
				return MCM.readInt(localPlayer + VersionClass.GetData("worldAge"));
			}
			set
			{
				MCM.writeInt(localPlayer + VersionClass.GetData("worldAge"), value);
			}
		}

		public static byte isLookingAtBlock
		{
			get
			{
				return MCM.readByte(level + VersionClass.GetData("lookingAtBlock"));
			}
			set
			{
				MCM.writeByte(level + VersionClass.GetData("lookingAtBlock"), value);
			}
		}

		public static iVector3 SelectedBlock
		{
			get
			{
				iVector3 result = Base.IVec3();
				result.x = MCM.readInt(level + VersionClass.GetData("SelectedBlock"));
				result.y = MCM.readInt(level + VersionClass.GetData("SelectedBlock") + 4);
				result.z = MCM.readInt(level + VersionClass.GetData("SelectedBlock") + 8);
				return result;
			}
			set
			{
				MCM.writeInt(level + VersionClass.GetData("SelectedBlock"), value.x);
				MCM.writeInt(level + VersionClass.GetData("SelectedBlock") + 4, value.y);
				MCM.writeInt(level + VersionClass.GetData("SelectedBlock") + 8, value.z);
			}
		}

		public static iVector3 exactPos
		{
			get
			{
				iVector3 result = Base.IVec3();
				result.x = MCM.readInt(localPlayer + VersionClass.GetData("exactPos"));
				result.y = MCM.readInt(localPlayer + VersionClass.GetData("exactPos") + 4);
				result.z = MCM.readInt(localPlayer + VersionClass.GetData("exactPos") + 8);
				return result;
			}
			set
			{
				MCM.writeInt(localPlayer + VersionClass.GetData("exactPos"), value.x);
				MCM.writeInt(localPlayer + VersionClass.GetData("exactPos") + 4, value.y);
				MCM.writeInt(localPlayer + VersionClass.GetData("exactPos") + 8, value.z);
			}
		}

		public static byte SideSelect
		{
			get
			{
				return MCM.readByte(level + VersionClass.GetData("SideSelect"));
			}
			set
			{
				MCM.writeByte(level + VersionClass.GetData("SideSelect"), value);
			}
		}

		public static void teleport(AABB advancedAxis)
		{
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX"), advancedAxis.lower.x);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 4, advancedAxis.lower.y);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 8, advancedAxis.lower.z);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 12, advancedAxis.upper.x);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 16, advancedAxis.upper.y);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 20, advancedAxis.upper.z);
		}

		public static void vclip(float y)
		{
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX"), position.x);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 4, position.y + y);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 8, position.z);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 12, position.x + 0.6f);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 16, position.y + 1.8f + y);
			MCM.writeFloat(localPlayer + VersionClass.GetData("positionX") + 20, position.z + 0.6f);
		}

		public static void vflip(float y)
		{
			MCM.writeFloat(localPlayer + VersionClass.GetData("velocity") + 4, y);
		}

		public static void jumpForwards(float value)
		{
			Vector3 lVector = Game.lVector;
			Vector3 vec = Base.Vec3();
			vec.x = position.x / 10f + value * lVector.x;
			vec.y = position.y / 10f + value * lVector.y;
			vec.z = position.z / 10f + value * lVector.z;
			teleport(vec);
		}

		public static void swing()
		{
			swingAn = 1;
		}

		public static void teleport(float x, float y, float z)
		{
			teleport(new AABB(Base.Vec3(x, y, z), Base.Vec3(x + 0.6f, y + 1.8f, z + 0.6f)));
		}

		public static void teleport(Vector3 _Vec3)
		{
			teleport(_Vec3.x, _Vec3.y, _Vec3.z);
		}

		public static void SexActor(Actor actor, float width = 0.3f, float height = 1f)
		{
			Vector3 position = actor.position;
			position.x += Faketernal.Utils.NextFloat(0f - width, width);
			position.y += height;
			position.z += Faketernal.Utils.NextFloat(0f - width, width);
			teleport(position);
		}

		public static void setFieldOfView(float v)
		{
			MCM.writeFloat(localPlayer + VersionClass.GetData("fieldOfView"), v);
		}

		public static void resetFieldOfView()
		{
			setFieldOfView(1f);
		}

		public static void Attack(Actor actor)
		{
			lookingEntityId = actor.addr;
			Mouse.MouseEvent(Mouse.MouseEventFlags.MOUSEEVENTF_LEFTDOWN);
		}

		public static Vector3 dirVect(float x, float y)
		{
			Vector3 result = Base.Vec3();
			result.x = (float)Math.Cos(x) * (float)Math.Cos(y);
			result.y = (float)Math.Sin(y);
			result.z = (float)Math.Sin(x) * (float)Math.Cos(y);
			return result;
		}

		public static List<Actor> getTypeEntities(string type)
		{
			List<Actor> list = new List<Actor>();
			for (ulong num = EntityListStart; num < EntityListEnd; num += 8)
			{
				if (num == EntityListStart)
				{
					continue;
				}
				Actor actor = new Actor(MCM.readInt64(num));
				foreach (string friend in CustomDefines.friends)
				{
					if (friend.ToLower() == actor.username.ToLower())
					{
						_ = CustomDefines.nofriends;
					}
				}
				if (actor.type == type && actor.username.Length > 3)
				{
					list.Add(actor);
				}
			}
			return list;
		}

		public static List<Actor> getEntites()
		{
			List<Actor> list = new List<Actor>();
			for (ulong num = EntityListStart - 8; num < EntityListEnd; num += 8)
			{
				Actor item = new Actor(MCM.readInt64(num));
				list.Add(item);
			}
			return list;
		}

		public static List<Actor> parseEntities(List<Actor> list)
		{
			List<Actor> list2 = new List<Actor>();
			char[] array = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890 §".ToCharArray();
			foreach (Actor item in list)
			{
				try
				{
					bool flag = true;
					string text = item.username.Substring(0, 5);
					foreach (char c in text)
					{
						bool flag2 = false;
						char[] array2 = array;
						foreach (char c2 in array2)
						{
							if (c == c2)
							{
								flag2 = true;
							}
						}
						if (!flag2)
						{
							flag = false;
						}
					}
					if (flag)
					{
						list2.Add(item);
					}
				}
				catch
				{
					list2.Add(item);
				}
			}
			return list2;
		}

		public static List<Actor> parseHitboxes(List<Actor> list)
		{
			List<Actor> list2 = new List<Actor>();
			foreach (Actor item in list)
			{
				if (item.hitbox.ToString() == "0.6,1.8")
				{
					list2.Add(item);
				}
			}
			return list2;
		}

		public static Actor getClosestEntity()
		{
			Actor vEntity = null;
			getEntites().ForEach(delegate(Actor ent)
			{
				if (vEntity == null)
				{
					vEntity = ent;
				}
				else
				{
					float num = position.Distance(ent.position);
					float num2 = position.Distance(vEntity.position);
					if (num < num2)
					{
						vEntity = ent;
					}
				}
			});
			return vEntity;
		}

		public static Actor getClosestTypeEntity(string Type)
		{
			Actor vEntity = null;
			getTypeEntities(Type).ForEach(delegate(Actor ent)
			{
				if (vEntity == null)
				{
					vEntity = ent;
				}
				else
				{
					float num = position.Distance(ent.position);
					float num2 = position.Distance(vEntity.position);
					if (num < num2)
					{
						vEntity = ent;
					}
				}
			});
			return vEntity;
		}

		public static List<Actor> getPlayers()
		{
			List<Actor> list = getTypeEntities("player");
			if (CustomDefines.antibot)
			{
				if (CustomDefines.antibotStates[0])
				{
					list = parseEntities(list);
				}
				if (CustomDefines.antibotStates[1])
				{
					list = parseHitboxes(list);
				}
			}
			return list;
		}

		public static Actor getClosestPlayer()
		{
			Actor vEntity = null;
			new List<Actor>();
			getPlayers().ForEach(delegate(Actor ent)
			{
				foreach (string friend in CustomDefines.friends)
				{
					if (friend.ToLower() == ent.username.ToLower())
					{
						_ = CustomDefines.nofriends;
					}
				}
				if (vEntity == null)
				{
					vEntity = ent;
				}
				else
				{
					float num = position.Distance(ent.position);
					float num2 = position.Distance(vEntity.position);
					if (num < num2)
					{
						vEntity = ent;
					}
				}
			});
			return vEntity;
		}
	}
}
