using Trero.ClientBase.VersionBase;

namespace Trero.ClientBase
{
	internal class OverrideBase
	{
		public static PlayerModel entityModel = new PlayerModel(30100416);

		public static bool Pitch
		{
			set
			{
				if (value)
				{
					MCM.writeBaseBytes(31353266, MCM.ceByte2Bytes("89 87 38 01 00 00"));
				}
				else
				{
					MCM.writeBaseBytes(31353266, MCM.ceByte2Bytes("90 90 90 90 90 90"));
				}
			}
		}

		public static bool Yaw
		{
			set
			{
				if (value)
				{
					MCM.writeBaseBytes(31353255, MCM.ceByte2Bytes("89 01"));
				}
				else
				{
					MCM.writeBaseBytes(31353255, MCM.ceByte2Bytes("90 90"));
				}
			}
		}

		public static bool CanSendPackets
		{
			set
			{
				if (value)
				{
					if (MCM.readByte(Game.nopacketAddr) != 72)
					{
						MCM.writeBytes(Game.nopacketAddr, MCM.ceByte2Bytes("48 89 5C 24 08"));
					}
				}
				else if (MCM.readByte(Game.nopacketAddr) == 72)
				{
					MCM.writeBytes(Game.nopacketAddr, MCM.ceByte2Bytes("C3 C3 C3 C3 C3"));
				}
			}
		}

		public static bool ServerCanTeleportClient
		{
			set
			{
				if (value)
				{
					MCM.writeBaseBytes(31366841, MCM.ceByte2Bytes("F3 0F 11 81 C0 04 00 00"));
					MCM.writeBaseBytes(31366856, MCM.ceByte2Bytes("F3 0F 11 A1 CC 04 00 00"));
					MCM.writeBaseBytes(31366868, MCM.ceByte2Bytes("F3 0F 11 99 C4 04 00 00"));
					MCM.writeBaseBytes(31366876, MCM.ceByte2Bytes("F3 0F 11 81 C8 04 00 00"));
					MCM.writeBaseBytes(31366892, MCM.ceByte2Bytes("F3 0F 11 89 D4 04 00 00"));
					MCM.writeBaseBytes(31366900, MCM.ceByte2Bytes("F3 0F 11 99 D0 04 00 00"));
				}
				else
				{
					MCM.writeBaseBytes(31366841, MCM.ceByte2Bytes("90 90 90 90 90 90 90 90"));
					MCM.writeBaseBytes(31366856, MCM.ceByte2Bytes("90 90 90 90 90 90 90 90"));
					MCM.writeBaseBytes(31366868, MCM.ceByte2Bytes("90 90 90 90 90 90 90 90"));
					MCM.writeBaseBytes(31366876, MCM.ceByte2Bytes("90 90 90 90 90 90 90 90"));
					MCM.writeBaseBytes(31366892, MCM.ceByte2Bytes("90 90 90 90 90 90 90 90"));
					MCM.writeBaseBytes(31366900, MCM.ceByte2Bytes("90 90 90 90 90 90 90 90"));
				}
			}
		}

		public static bool lookingAtBlock
		{
			set
			{
				ulong addr = Game.level + VersionClass.GetData("lookingAtBlock");
				if (value)
				{
					MCM.freezeBytes(addr, MCM.int2Bytes(0));
				}
				else
				{
					MCM.unfreezeBytes(addr);
				}
			}
		}
	}
}
