using System;

namespace Trero.ClientBase
{
	public struct Vector3
	{
		public float x;

		public float y;

		public float z;

		public Vector3(float x, float y, float z)
		{
			this.x = x;
			this.y = y;
			this.z = z;
		}

		public Vector3(string position)
		{
			try
			{
				string[] array = position.Replace(" ", "").Split(new char[1]
				{
					','
				});
				x = Convert.ToSingle(array[0]);
				y = Convert.ToSingle(array[1]);
				z = Convert.ToSingle(array[2]);
			}
			catch
			{
				string[] array2 = position.Replace(" ", "").Split(new char[1]
				{
					','
				});
				x = HexHandler.ToLong(array2[0]);
				y = HexHandler.ToLong(array2[1]);
				z = HexHandler.ToLong(array2[2]);
			}
		}

		public float DistanceTo(Vector3 _Vec3)
		{
			float num = x - _Vec3.x;
			float num2 = y - _Vec3.y;
			float num3 = z - _Vec3.z;
			float num4 = (float)Math.Sqrt(num * num + num2 * num2 + num3 * num3);
			if ((int)num4 == 0)
			{
				num4 = _Vec3.Distance(this);
			}
			return num4;
		}

		public float Distance(Vector3 _Vec3)
		{
			float num = x - _Vec3.x;
			float num2 = y - _Vec3.y;
			float num3 = z - _Vec3.z;
			return (float)Math.Sqrt(num * num + num2 * num2 + num3 * num3);
		}

		public override string ToString()
		{
			return x + "," + y + "," + z;
		}

		internal float Distance(object postion)
		{
			throw new NotImplementedException();
		}
	}
}
