using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Forms.Layout;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.UIBase.TreroUILibrary;
using Trero.ClientBase.VersionBase;
using Trero.Modules;
using Trero.Modules.vModuleExtra;

namespace Trero.ClientBase.UIBase
{
	public class Overlay : Form
	{
		public delegate void WinEventDelegate(IntPtr hWinEventHook, uint eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime);

		public static Overlay handle;

		private Font _df = new Font(FontFamily.get_GenericSansSerif(), 12f);

		private Point _mouseDownLocation;

		public Button vMod;

		public Label cMod;

		private WinEventDelegate overDel;

		private Font df = new Font("Arial", 24f, (FontStyle)1);

		private IContainer components;

		private Panel panel2;

		private Timer timer1;

		private Panel panel3;

		private Panel panel4;

		private Label label3;

		private Label label2;

		private Label label1;

		private Panel panel1;

		private Panel panel5;

		private Label playerList;

		private Panel panel6;

		private Panel panel7;

		private Label label6;

		private Label label5;

		private Panel panel8;

		private Label label4;

		private Panel panel9;

		private Panel panel10;

		private Label label7;

		private Panel panel11;

		private Panel panel12;

		private Label label8;

		private Panel panel13;

		private Panel panel14;

		private Label label9;

		private Panel panel15;

		private Panel panel16;

		private Label label10;

		private Panel panel17;

		private Timer timer2;

		private Timer timer3;

		private Panel panel18;

		private Panel panel19;

		private Panel TestCategory;

		private Panel ClonablePanel;

		private Button ClonableButton;

		private Label label13;

		private Button button2;

		private Button button1;

		private Panel panel20;

		private NumericUpDown numericUpDown3;

		private NumericUpDown numericUpDown1;

		private NumericUpDown numericUpDown2;

		private Label UpdateLabel;

		private Panel panel21;

		private Label label11;

		private Panel panel22;

		private Button button3;

		private Button button4;

		private Button button5;

		private Button button6;

		private Button button7;

		private NumericUpDown PotionAmplifier;

		private Panel panel23;

		private Panel panel24;

		private Label label15;

		private NumericUpDown PotionDiritation;

		private Label label14;

		private Button button8;

		private Button button9;

		private Button button10;

		private Button button11;

		private Button button12;

		private Label label16;

		private Timer timer4;

		[DllImport("User32.dll")]
		public static extern int GetWindowLong(IntPtr hwnd, int nIndex);

		[DllImport("User32.dll")]
		public static extern int SetWindowLong(IntPtr hwnd, int nIndex, int dwNewLong);

		[DllImport("user32.dll")]
		public static extern IntPtr SetWinEventHook(uint eventMin, uint eventMax, IntPtr hmodWinEventProc, WinEventDelegate lpfnWinEventProc, uint idProcess, uint idThread, uint dwFlags);

		[DllImport("user32.dll")]
		public static extern uint GetWindowThreadProcessId(IntPtr hWnd, IntPtr voidProcessId);

		public Overlay()
			: this()
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Expected O, but got Unknown
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Expected O, but got Unknown
			handle = this;
			Console.WriteLine("Initializing components...");
			InitializeComponent();
			Console.WriteLine("Initialized components!");
			((Control)this).Focus();
			int windowLong = GetWindowLong(((Control)this).get_Handle(), -20);
			SetWindowLong(((Control)this).get_Handle(), -20, windowLong | 0x80000 | 0x20);
			overDel = adjust;
			Console.WriteLine("Initializing hooks...");
			SetWinEventHook(32779u, 32779u, IntPtr.Zero, overDel, MCM.procHandleId, GetWindowThreadProcessId(MCM.procHandle, IntPtr.Zero), 3u);
			SetWinEventHook(3u, 3u, IntPtr.Zero, overDel, 0u, 0u, 3u);
			Console.WriteLine("Initialized window hooks!");
			Program.moduleToggled = (EventHandler<EventArgs>)Delegate.Combine(Program.moduleToggled, new EventHandler<EventArgs>(redraw));
			Console.WriteLine("Initialized arraylist hooks!");
			((Form)this).set_TopMost(true);
		}

		private void redraw(object sender, EventArgs e)
		{
			((Control)this).Invalidate();
		}

		private void adjust(IntPtr hWinEventHook, uint eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime)
		{
			MCM.ProcessRectangle gameRect = MCM.getGameRect();
			Placement lpwndpl = default(Placement);
			GetWindowPlacement(MCM.procHandle, ref lpwndpl);
			int num = 0;
			int num2 = 0;
			if (lpwndpl.showCmd == 3)
			{
				num = 8;
				num2 = 2;
			}
			int x = gameRect.Left + 9 + num2;
			int y = gameRect.Top + 35 + num;
			int cx = gameRect.Right - gameRect.Left - 18 - num2;
			int cy = gameRect.Bottom - gameRect.Top - 44 - num;
			SetWindowPos(((Control)this).get_Handle(), MCM.isGameFocusedInsert(), x, y, cx, cy, 64u);
			try
			{
				if (MCM.isGameFocused() && !((Form)this).get_TopMost())
				{
					((Form)this).set_TopMost(true);
				}
				if (MCM.isGameFocused() || !((Form)this).get_TopMost() || Form.get_ActiveForm() == this)
				{
					return;
				}
				((Form)this).set_Opacity(1.0);
				((Form)this).set_TopMost(false);
				SetWindowPos(((Control)this).get_Handle(), new IntPtr(1), 0, 0, 0, 0, 11u);
			}
			catch
			{
			}
			((Control)this).Invalidate();
		}

		[DllImport("user32.dll")]
		public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool GetWindowPlacement(IntPtr hWnd, ref Placement lpwndpl);

		private void timer1_Tick(object sender, EventArgs e)
		{
		}

		private void updateModule(Module mod, Panel c)
		{
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			//IL_0039: Expected O, but got Unknown
			//IL_005a: Unknown result type (might be due to invalid IL or missing references)
			//IL_006c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0086: Unknown result type (might be due to invalid IL or missing references)
			//IL_0093: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
			foreach (object? item in (ArrangedElementCollection)((Control)c).get_Controls())
			{
				if (!(item!.GetType() == typeof(Button)))
				{
					continue;
				}
				Button val = (Button)item;
				if (mod.name != ((Control)val).get_Name())
				{
					break;
				}
				if (mod.enabled)
				{
					if (((Control)val).get_BackColor() != Color.FromArgb(255, 0, 103, 255))
					{
						((Control)val).set_BackColor(Color.FromArgb(255, 0, 103, 255));
					}
				}
				else if (((Control)val).get_BackColor() == Color.FromArgb(255, 0, 103, 255))
				{
					((Control)val).set_BackColor(Color.FromArgb(255, 54, 71, 96));
				}
			}
		}

		private void Overlay_Paint(object sender, PaintEventArgs e)
		{
		}

		private void panel2_MouseDown_1(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel2).BringToFront();
			}
		}

		private void panel2_MouseMove_1(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel2).set_Left(e.get_X() + ((Control)panel2).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel2).set_Top(e.get_Y() + ((Control)panel2).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void Overlay_Load(object sender, EventArgs e)
		{
			//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
			//IL_0109: Expected O, but got Unknown
			//IL_0168: Unknown result type (might be due to invalid IL or missing references)
			//IL_017a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0184: Expected O, but got Unknown
			//IL_01eb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0234: Unknown result type (might be due to invalid IL or missing references)
			//IL_023e: Expected O, but got Unknown
			foreach (Module module in Program.Modules)
			{
				Panel val = ClonablePanel.Clone<Panel>();
				Button val2 = ClonableButton.Clone<Button>();
				Label val3 = label13.Clone<Label>();
				List<Label> list = new List<Label>();
				for (int i = 0; i < module.bypasses.Count; i++)
				{
					Label val4 = label13.Clone<Label>();
					((Control)val4).set_Text(module.bypasses[i].list[module.bypasses[i].curIndex]);
					((Control)val4).set_Visible(true);
					((Control)val4).set_Dock((DockStyle)1);
					((Control)val4).set_Name(module.name + ";");
					KeyTags keyTags = new KeyTags();
					keyTags.Add("bypass", module.bypasses[i]);
					keyTags.Add("button", val4);
					keyTags.Add("index", i);
					((Control)val4).set_Tag((object)keyTags);
					((Control)val4).add_MouseClick(new MouseEventHandler(actorPress));
					list.Add(val4);
				}
				((Control)val).set_Visible(true);
				((Control)val2).set_Visible(true);
				((Control)val2).set_Name(module.name);
				((Control)val2).set_Text(module.name);
				((ButtonBase)val2).get_FlatAppearance().set_BorderSize(0);
				((ButtonBase)val2).get_FlatAppearance().set_BorderColor(((Control)TestCategory).get_BackColor());
				((Control)val2).add_MouseDown(new MouseEventHandler(keybindActivated));
				KeyTags keyTags2 = new KeyTags();
				keyTags2.Add("desc", module.desc);
				((Control)val2).set_Tag((object)keyTags2);
				((Control)val2).add_MouseEnter((EventHandler)ActivateTooltip);
				((Control)val2).add_MouseLeave((EventHandler)DeactivateTooltip);
				((Control)val3).set_Text("Keybind: None");
				if (module.keybind != '\a')
				{
					Keys val5 = (Keys)module.keybind;
					((Control)val3).set_Text("Keybind: " + ((object)(Keys)(ref val5)).ToString());
				}
				((Control)val3).set_Visible(true);
				((Control)val3).set_Dock((DockStyle)1);
				((Control)val3).set_Name(module.name + ";");
				((Control)val3).add_MouseClick(new MouseEventHandler(actorBind));
				foreach (Label item in list)
				{
					((Control)val).get_Controls().Add((Control)(object)item);
				}
				((Control)val).get_Controls().Add((Control)(object)val3);
				((Control)val).get_Controls().Add((Control)(object)val2);
				switch (module.category)
				{
				case "Flies":
					((Control)panel7).get_Controls().Add((Control)(object)val);
					break;
				case "Visual":
					((Control)panel15).get_Controls().Add((Control)(object)val);
					break;
				case "Exploits":
					((Control)panel13).get_Controls().Add((Control)(object)val);
					break;
				case "World":
					((Control)panel9).get_Controls().Add((Control)(object)val);
					break;
				case "Combat":
					((Control)panel11).get_Controls().Add((Control)(object)val);
					break;
				case "Player":
					((Control)panel17).get_Controls().Add((Control)(object)val);
					break;
				case "Other":
					((Control)TestCategory).get_Controls().Add((Control)(object)val);
					break;
				}
			}
			InvalidateCategories();
			((Control)this).SetStyle((ControlStyles)131072, true);
			((Control)this).UpdateStyles();
		}

		private void actorPress(object sender, MouseEventArgs e)
		{
			object obj = (object)(sender as Label);
			BypassBox bypassBox = (BypassBox)(((Control)obj).get_Tag() as KeyTags).Get("bypass");
			if (bypassBox.curIndex < Enumerable.Count<string>((IEnumerable<string>)bypassBox.list) - 1)
			{
				bypassBox.curIndex++;
			}
			else if (bypassBox.curIndex >= Enumerable.Count<string>((IEnumerable<string>)bypassBox.list) - 1)
			{
				bypassBox.curIndex = 0;
			}
			((Control)obj).set_Text(bypassBox.list[bypassBox.curIndex]);
			Program.moduleToggled(null, new EventArgs());
		}

		private void actorBind(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Expected O, but got Unknown
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Expected O, but got Unknown
			if ((int)e.get_Button() == 1048576)
			{
				Label val = (Label)sender;
				if (val == null)
				{
					return;
				}
				((Control)val).set_Text("Keybind: ...");
				cMod = val;
				val.add_KeyDown(new KeyEventHandler(vCatchKeybind));
				((Control)val).Select();
			}
			Program.moduleToggled(null, new EventArgs());
		}

		private void InvalidateCategories()
		{
			((Control)this).SuspendLayout();
			cValidate(panel7, panel6);
			cValidate(panel15, panel14);
			cValidate(panel13, panel12);
			cValidate(panel9, panel8);
			cValidate(panel11, panel10);
			cValidate(panel17, panel16);
			cValidate(TestCategory, panel2);
			cValidate(panel22, panel21);
			((Control)this).ResumeLayout();
		}

		private void cValidate(Panel miniPanel, Panel titlePanel)
		{
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_0060: Unknown result type (might be due to invalid IL or missing references)
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			int num = 0;
			foreach (Control item in (ArrangedElementCollection)((Control)miniPanel).get_Controls())
			{
				Control val = item;
				if (val.get_Visible())
				{
					num += val.get_Height();
				}
			}
			if (((Control)miniPanel).get_Height() != num)
			{
				((Control)miniPanel).set_Size(new Size(0, num));
				Size size = ((Control)titlePanel).get_Size();
				((Control)titlePanel).set_Size(new Size(((Size)(ref size)).get_Width(), num + 24));
			}
		}

		private void keybindActivated(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_0022: Expected O, but got Unknown
			//IL_0084: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d0: Invalid comparison between Unknown and I4
			//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00dd: Expected O, but got Unknown
			//IL_00ff: Unknown result type (might be due to invalid IL or missing references)
			//IL_012a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0131: Expected O, but got Unknown
			//IL_0170: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				Button btn = (Button)sender;
				if (btn == null)
				{
					return;
				}
				foreach (Module item in Enumerable.Where<Module>((IEnumerable<Module>)Program.Modules, (Func<Module, bool>)((Module mod) => mod.name == ((Control)btn).get_Name())))
				{
					if (item.enabled)
					{
						item.OnDisable();
						((Control)btn).set_BackColor(Color.FromArgb(255, 0, 103, 255));
					}
					else
					{
						item.OnEnable();
						((Control)btn).set_BackColor(Color.FromArgb(255, 54, 71, 96));
					}
				}
			}
			if ((int)e.get_Button() == 2097152)
			{
				Button val = (Button)sender;
				if (val == null)
				{
					return;
				}
				if (((Control)val).get_Parent().get_Height() > 30)
				{
					((Control)val).get_Parent().set_Size(((Control)ClonableButton).get_Size());
				}
				else
				{
					int num = 0;
					foreach (Control item2 in (ArrangedElementCollection)((Control)val).get_Parent().get_Controls())
					{
						Control val2 = item2;
						if (val2.get_Visible())
						{
							num += val2.get_Height();
						}
					}
					((Control)val).get_Parent().set_Size(new Size(0, num));
				}
				InvalidateCategories();
			}
			Program.moduleToggled(null, new EventArgs());
		}

		private void catchKeybind(object sender, KeyEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Invalid comparison between Unknown and I4
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Invalid comparison between Unknown and I4
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Expected O, but got Unknown
			//IL_00be: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
			//IL_0128: Unknown result type (might be due to invalid IL or missing references)
			//IL_0132: Expected O, but got Unknown
			if ((int)e.get_KeyCode() == 27 || (int)e.get_KeyCode() == 46)
			{
				((Control)vMod).remove_KeyDown(new KeyEventHandler(catchKeybind));
				((Control)vMod).set_Text(((Control)vMod).get_Name());
				foreach (Module module in Program.Modules)
				{
					if (module.name == ((Control)vMod).get_Name())
					{
						module.keybind = '\a';
					}
				}
				return;
			}
			foreach (Module module2 in Program.Modules)
			{
				if (module2.name == ((Control)vMod).get_Name())
				{
					module2.keybind = (char)e.get_KeyCode();
				}
			}
			Button obj = vMod;
			string name = ((Control)vMod).get_Name();
			Keys keyCode = e.get_KeyCode();
			((Control)obj).set_Text(name + " (" + ((object)(Keys)(ref keyCode)).ToString() + ")");
			((Control)vMod).remove_KeyDown(new KeyEventHandler(catchKeybind));
			Program.moduleToggled(null, new EventArgs());
		}

		private void vCatchKeybind(object sender, KeyEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Invalid comparison between Unknown and I4
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0012: Invalid comparison between Unknown and I4
			//IL_0021: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Expected O, but got Unknown
			//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
			//IL_00fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_0101: Unknown result type (might be due to invalid IL or missing references)
			//IL_0126: Unknown result type (might be due to invalid IL or missing references)
			//IL_0130: Expected O, but got Unknown
			if ((int)e.get_KeyCode() == 27 || (int)e.get_KeyCode() == 46)
			{
				cMod.remove_KeyDown(new KeyEventHandler(vCatchKeybind));
				((Control)cMod).set_Text("Keybind: None");
				foreach (Module module in Program.Modules)
				{
					if (module.name + ";" == ((Control)cMod).get_Name())
					{
						module.keybind = '\a';
					}
				}
				return;
			}
			foreach (Module module2 in Program.Modules)
			{
				if (module2.name + ";" == ((Control)cMod).get_Name())
				{
					module2.keybind = (char)e.get_KeyCode();
				}
			}
			Label obj = cMod;
			Keys keyCode = e.get_KeyCode();
			((Control)obj).set_Text("Keybind: " + ((object)(Keys)(ref keyCode)).ToString());
			cMod.remove_KeyDown(new KeyEventHandler(vCatchKeybind));
			Program.moduleToggled(null, new EventArgs());
		}

		private void panel3_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel3).BringToFront();
			}
		}

		private void panel3_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel3).set_Left(e.get_X() + ((Control)panel3).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel3).set_Top(e.get_Y() + ((Control)panel3).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void ClonableButton_Click(object sender, EventArgs e)
		{
		}

		private void panel1_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel1).BringToFront();
			}
		}

		private void panel1_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel1).set_Left(e.get_X() + ((Control)panel1).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel1).set_Top(e.get_Y() + ((Control)panel1).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void panel6_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel6).BringToFront();
			}
		}

		private void panel6_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel6).set_Left(e.get_X() + ((Control)panel6).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel6).set_Top(e.get_Y() + ((Control)panel6).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void panel14_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel14).BringToFront();
			}
		}

		private void panel14_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel14).set_Left(e.get_X() + ((Control)panel14).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel14).set_Top(e.get_Y() + ((Control)panel14).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void panel8_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel8).BringToFront();
			}
		}

		private void panel8_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel8).set_Left(e.get_X() + ((Control)panel8).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel8).set_Top(e.get_Y() + ((Control)panel8).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void panel10_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel10).BringToFront();
			}
		}

		private void panel10_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel10).set_Left(e.get_X() + ((Control)panel10).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel10).set_Top(e.get_Y() + ((Control)panel10).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void panel12_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel12).BringToFront();
			}
		}

		private void panel12_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel12).set_Left(e.get_X() + ((Control)panel12).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel12).set_Top(e.get_Y() + ((Control)panel12).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void panel16_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel16).BringToFront();
			}
		}

		private void panel16_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel16).set_Left(e.get_X() + ((Control)panel16).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel16).set_Top(e.get_Y() + ((Control)panel16).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void timer2_Tick(object sender, EventArgs e)
		{
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_003f: Expected O, but got Unknown
			//IL_007c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0086: Expected O, but got Unknown
			//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cd: Expected O, but got Unknown
			//IL_010a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0114: Expected O, but got Unknown
			//IL_0151: Unknown result type (might be due to invalid IL or missing references)
			//IL_015b: Expected O, but got Unknown
			//IL_0198: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a2: Expected O, but got Unknown
			//IL_01df: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e9: Expected O, but got Unknown
			try
			{
				foreach (Module module in Program.Modules)
				{
					foreach (object? item in (ArrangedElementCollection)((Control)TestCategory).get_Controls())
					{
						updateModule(module, (Panel)item);
					}
					foreach (object? item2 in (ArrangedElementCollection)((Control)panel7).get_Controls())
					{
						updateModule(module, (Panel)item2);
					}
					foreach (object? item3 in (ArrangedElementCollection)((Control)panel17).get_Controls())
					{
						updateModule(module, (Panel)item3);
					}
					foreach (object? item4 in (ArrangedElementCollection)((Control)panel15).get_Controls())
					{
						updateModule(module, (Panel)item4);
					}
					foreach (object? item5 in (ArrangedElementCollection)((Control)panel9).get_Controls())
					{
						updateModule(module, (Panel)item5);
					}
					foreach (object? item6 in (ArrangedElementCollection)((Control)panel11).get_Controls())
					{
						updateModule(module, (Panel)item6);
					}
					foreach (object? item7 in (ArrangedElementCollection)((Control)panel13).get_Controls())
					{
						updateModule(module, (Panel)item7);
					}
				}
			}
			catch
			{
			}
		}

		private void timer3_Tick(object sender, EventArgs e)
		{
			if (!Game.isNull)
			{
				((Control)UpdateLabel).set_Text(Game.username + "   |   " + VersionClass.currentVersion.name + "   |   " + Game.position.x + ", " + Game.position.y + ", " + Game.position.z);
			}
			else
			{
				((Control)UpdateLabel).set_Text("Not InGame");
			}
		}

		private void label12_Click_1(object sender, EventArgs e)
		{
		}

		private void Overlay_ResizeBegin(object sender, EventArgs e)
		{
			((Control)this).SuspendLayout();
		}

		private void Overlay_ResizeEnd(object sender, EventArgs e)
		{
			((Control)this).ResumeLayout();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			((Control)panel18).set_Visible(false);
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Game.teleport((int)numericUpDown1.get_Value(), (int)numericUpDown2.get_Value(), (int)numericUpDown3.get_Value());
		}

		private void panel18_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel18).BringToFront();
			}
		}

		private void panel18_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel18).set_Left(e.get_X() + ((Control)panel18).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel18).set_Top(e.get_Y() + ((Control)panel18).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void label4_MouseDown(object sender, MouseEventArgs e)
		{
			panel8_MouseDown(sender, e);
		}

		private void label4_MouseMove(object sender, MouseEventArgs e)
		{
			panel8_MouseMove(sender, e);
		}

		private void label10_MouseDown(object sender, MouseEventArgs e)
		{
			panel16_MouseDown(sender, e);
		}

		private void label10_MouseMove(object sender, MouseEventArgs e)
		{
			panel16_MouseMove(sender, e);
		}

		private void label8_MouseDown(object sender, MouseEventArgs e)
		{
			panel12_MouseDown(sender, e);
		}

		private void label8_MouseMove(object sender, MouseEventArgs e)
		{
			panel12_MouseMove(sender, e);
		}

		private void label6_MouseDown(object sender, MouseEventArgs e)
		{
			panel2_MouseDown_1(sender, e);
		}

		private void label6_MouseMove(object sender, MouseEventArgs e)
		{
			panel2_MouseMove_1(sender, e);
		}

		private void label5_MouseDown(object sender, MouseEventArgs e)
		{
			panel6_MouseDown(sender, e);
		}

		private void label5_MouseMove(object sender, MouseEventArgs e)
		{
			panel6_MouseMove(sender, e);
		}

		private void label9_MouseDown(object sender, MouseEventArgs e)
		{
			panel14_MouseDown(sender, e);
		}

		private void label9_MouseMove(object sender, MouseEventArgs e)
		{
			panel14_MouseMove(sender, e);
		}

		private void label7_MouseDown(object sender, MouseEventArgs e)
		{
			panel10_MouseDown(sender, e);
		}

		private void label7_MouseMove(object sender, MouseEventArgs e)
		{
			panel10_MouseMove(sender, e);
		}

		private void button3_Click(object sender, EventArgs e)
		{
			Faketernal.Potions.CreateAction(delegate(int i, int c)
			{
				if (Game.onGround)
				{
					float num = Game.bodyRots.y;
					if (Keymap.GetAsyncKeyState((Keys)87))
					{
						if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
						{
							num += 90f;
						}
						if (Keymap.GetAsyncKeyState((Keys)65))
						{
							num += 45f;
						}
						else if (Keymap.GetAsyncKeyState((Keys)68))
						{
							num += 135f;
						}
					}
					else if (Keymap.GetAsyncKeyState((Keys)83))
					{
						if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
						{
							num -= 90f;
						}
						if (Keymap.GetAsyncKeyState((Keys)65))
						{
							num -= 45f;
						}
						else if (Keymap.GetAsyncKeyState((Keys)68))
						{
							num -= 135f;
						}
					}
					else if (!Keymap.GetAsyncKeyState((Keys)87) && !Keymap.GetAsyncKeyState((Keys)83) && !Keymap.GetAsyncKeyState((Keys)65) && Keymap.GetAsyncKeyState((Keys)68))
					{
						num += 180f;
					}
					if (Keymap.GetAsyncKeyState((Keys)87) | Keymap.GetAsyncKeyState((Keys)65) | Keymap.GetAsyncKeyState((Keys)83) | Keymap.GetAsyncKeyState((Keys)68))
					{
						float num2 = num * ((float)Math.PI / 180f);
						MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity"), (float)Math.Cos(num2) * (0.05f / (float)c));
						MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 8, (float)Math.Sin(num2) * (0.05f / (float)c));
					}
				}
			}, new iRGB(129, 108, 90), (int)PotionDiritation.get_Value(), (int)PotionAmplifier.get_Value(), 0.85f);
		}

		private void button4_Click(object sender, EventArgs e)
		{
			Faketernal.Potions.ClearActions();
		}

		private void button5_Click(object sender, EventArgs e)
		{
			Faketernal.Potions.CreateAction(delegate(int i, int c)
			{
				float num = 0f - 0.1f / (float)c;
				if (Game.velocity.y < num)
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, num);
				}
			}, new iRGB(209, 239, byte.MaxValue), (int)PotionDiritation.get_Value(), (int)PotionAmplifier.get_Value());
		}

		private void panel21_MouseDown(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_000f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() == 1048576)
			{
				_mouseDownLocation = e.get_Location();
				((Control)panel21).BringToFront();
			}
		}

		private void panel21_MouseMove(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			if ((int)e.get_Button() == 1048576)
			{
				((Control)panel21).set_Left(e.get_X() + ((Control)panel21).get_Left() - ((Point)(ref _mouseDownLocation)).get_X());
				((Control)panel21).set_Top(e.get_Y() + ((Control)panel21).get_Top() - ((Point)(ref _mouseDownLocation)).get_Y());
			}
		}

		private void label11_MouseDown(object sender, MouseEventArgs e)
		{
			panel21_MouseDown(sender, e);
		}

		private void label11_MouseMove(object sender, MouseEventArgs e)
		{
			panel21_MouseMove(sender, e);
		}

		private void button6_Click(object sender, EventArgs e)
		{
			Faketernal.Potions.CreateAction(delegate(int i, int c)
			{
				Game.speed = (float)c * 0.020000001f + 0.1f;
			}, new iRGB(198, 175, 124), (int)PotionDiritation.get_Value(), (int)PotionAmplifier.get_Value(), 2f, delegate
			{
				Game.speed = 0.1f;
			});
		}

		private void button7_Click(object sender, EventArgs e)
		{
			Faketernal.Potions.CreateAction(delegate(int i, int c)
			{
				if (Game.onGround && Keymap.GetAsyncKeyState((Keys)32))
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.5f * (0.5f * (float)c));
				}
			}, new iRGB(76, byte.MaxValue, 34), (int)PotionDiritation.get_Value(), (int)PotionAmplifier.get_Value());
		}

		private void button8_Click(object sender, EventArgs e)
		{
			Faketernal.Potions.CreateAction(delegate(int i, int c)
			{
				float value = 0.1f * (float)c;
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, value);
			}, new iRGB(byte.MaxValue, byte.MaxValue, 206), (int)PotionDiritation.get_Value(), (int)PotionAmplifier.get_Value());
		}

		private void button9_Click(object sender, EventArgs e)
		{
			Faketernal.Potions.CreateAction(delegate(int i, int c)
			{
				Game.stepHeight = 0.5f * (float)(c + 1);
			}, new iRGB(220, 178, 238), (int)PotionDiritation.get_Value(), (int)PotionAmplifier.get_Value(), 1f, delegate
			{
				Game.stepHeight = 0.5f;
			});
		}

		private void button10_Click(object sender, EventArgs e)
		{
			Faketernal.Potions.CreateAction(delegate(int i, int c)
			{
				if (Game.onGround && Keymap.GetAsyncKeyState((Keys)32))
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.25f / (float)c);
				}
			}, new iRGB(118, 141, 124), (int)PotionDiritation.get_Value(), (int)PotionAmplifier.get_Value());
		}

		private void button11_Click(object sender, EventArgs e)
		{
			Vector3 position = Game.position;
			float num = 0.5f / (float)(int)PotionAmplifier.get_Value();
			Game.teleport(new AABB(position, new Vector3(position.x + num, position.y + 1.8f, position.z + num)));
			Faketernal.Potions.CreateAction(delegate
			{
			}, new iRGB(169, 202, 207), (int)PotionDiritation.get_Value(), 0, 1f, delegate
			{
				Game.teleport(Game.position);
			});
		}

		private void button12_Click(object sender, EventArgs e)
		{
			Faketernal.Potions.CreateAction(delegate(int i, int c)
			{
				Game.stepHeight = 0.5f * (float)(c + 1);
				Game.onGround = true;
				if (Game.isInWater)
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.01f * (float)c);
				}
			}, new iRGB(128, 76, 146), (int)PotionDiritation.get_Value(), (int)PotionAmplifier.get_Value(), 1f, delegate
			{
				Game.stepHeight = 0.5f;
			});
		}

		private void panel21_MouseClick(object sender, MouseEventArgs e)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Invalid comparison between Unknown and I4
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			if ((int)e.get_Button() != 2097152)
			{
				return;
			}
			foreach (Control item in (ArrangedElementCollection)((Control)panel22).get_Controls())
			{
				item.set_Visible(!item.get_Visible());
			}
			InvalidateCategories();
		}

		private void label11_MouseClick(object sender, MouseEventArgs e)
		{
			panel21_MouseClick(sender, e);
		}

		private void label15_Click(object sender, EventArgs e)
		{
		}

		private void label14_Click(object sender, EventArgs e)
		{
		}

		private void panel23_Paint(object sender, PaintEventArgs e)
		{
		}

		private void panel8_Paint(object sender, PaintEventArgs e)
		{
		}

		private void panel7_Paint(object sender, PaintEventArgs e)
		{
		}

		private void panel21_Paint(object sender, PaintEventArgs e)
		{
		}

		private void label10_Click(object sender, EventArgs e)
		{
		}

		private void label8_Click(object sender, EventArgs e)
		{
		}

		private void label11_Click(object sender, EventArgs e)
		{
		}

		private void label4_Click(object sender, EventArgs e)
		{
		}

		private void ActivateTooltip(object sender, EventArgs e)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			((Control)label16).set_Text(((KeyTags)((Control)(Button)sender).get_Tag()).Get("desc").ToString());
		}

		private void DeactivateTooltip(object sender, EventArgs e)
		{
			((Control)label16).set_Text("");
		}

		private void timer4_Tick(object sender, EventArgs e)
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && components != null)
			{
				((IDisposable)components).Dispose();
			}
			((Form)this).Dispose(disposing);
		}

		private void InitializeComponent()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_0021: Expected O, but got Unknown
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			//IL_002c: Expected O, but got Unknown
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Expected O, but got Unknown
			//IL_0038: Unknown result type (might be due to invalid IL or missing references)
			//IL_0042: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_004d: Expected O, but got Unknown
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			//IL_005f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0069: Expected O, but got Unknown
			//IL_006a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0074: Expected O, but got Unknown
			//IL_0075: Unknown result type (might be due to invalid IL or missing references)
			//IL_007f: Expected O, but got Unknown
			//IL_0080: Unknown result type (might be due to invalid IL or missing references)
			//IL_008a: Expected O, but got Unknown
			//IL_008b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0095: Expected O, but got Unknown
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a0: Expected O, but got Unknown
			//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ab: Expected O, but got Unknown
			//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b6: Expected O, but got Unknown
			//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c1: Expected O, but got Unknown
			//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cc: Expected O, but got Unknown
			//IL_00cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_00d7: Expected O, but got Unknown
			//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e2: Expected O, but got Unknown
			//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ed: Expected O, but got Unknown
			//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Expected O, but got Unknown
			//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0103: Expected O, but got Unknown
			//IL_0104: Unknown result type (might be due to invalid IL or missing references)
			//IL_010e: Expected O, but got Unknown
			//IL_010f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0119: Expected O, but got Unknown
			//IL_011a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0124: Expected O, but got Unknown
			//IL_0125: Unknown result type (might be due to invalid IL or missing references)
			//IL_012f: Expected O, but got Unknown
			//IL_0130: Unknown result type (might be due to invalid IL or missing references)
			//IL_013a: Expected O, but got Unknown
			//IL_013b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0145: Expected O, but got Unknown
			//IL_0146: Unknown result type (might be due to invalid IL or missing references)
			//IL_0150: Expected O, but got Unknown
			//IL_0151: Unknown result type (might be due to invalid IL or missing references)
			//IL_015b: Expected O, but got Unknown
			//IL_015c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0166: Expected O, but got Unknown
			//IL_0167: Unknown result type (might be due to invalid IL or missing references)
			//IL_0171: Expected O, but got Unknown
			//IL_0172: Unknown result type (might be due to invalid IL or missing references)
			//IL_017c: Expected O, but got Unknown
			//IL_0183: Unknown result type (might be due to invalid IL or missing references)
			//IL_018d: Expected O, but got Unknown
			//IL_0194: Unknown result type (might be due to invalid IL or missing references)
			//IL_019e: Expected O, but got Unknown
			//IL_019f: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a9: Expected O, but got Unknown
			//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_01b4: Expected O, but got Unknown
			//IL_01b5: Unknown result type (might be due to invalid IL or missing references)
			//IL_01bf: Expected O, but got Unknown
			//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_01ca: Expected O, but got Unknown
			//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
			//IL_01d5: Expected O, but got Unknown
			//IL_01d6: Unknown result type (might be due to invalid IL or missing references)
			//IL_01e0: Expected O, but got Unknown
			//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
			//IL_01eb: Expected O, but got Unknown
			//IL_01ec: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f6: Expected O, but got Unknown
			//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0201: Expected O, but got Unknown
			//IL_0202: Unknown result type (might be due to invalid IL or missing references)
			//IL_020c: Expected O, but got Unknown
			//IL_020d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0217: Expected O, but got Unknown
			//IL_0218: Unknown result type (might be due to invalid IL or missing references)
			//IL_0222: Expected O, but got Unknown
			//IL_0223: Unknown result type (might be due to invalid IL or missing references)
			//IL_022d: Expected O, but got Unknown
			//IL_022e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0238: Expected O, but got Unknown
			//IL_0239: Unknown result type (might be due to invalid IL or missing references)
			//IL_0243: Expected O, but got Unknown
			//IL_0244: Unknown result type (might be due to invalid IL or missing references)
			//IL_024e: Expected O, but got Unknown
			//IL_024f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0259: Expected O, but got Unknown
			//IL_025a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0264: Expected O, but got Unknown
			//IL_0265: Unknown result type (might be due to invalid IL or missing references)
			//IL_026f: Expected O, but got Unknown
			//IL_0270: Unknown result type (might be due to invalid IL or missing references)
			//IL_027a: Expected O, but got Unknown
			//IL_027b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0285: Expected O, but got Unknown
			//IL_0286: Unknown result type (might be due to invalid IL or missing references)
			//IL_0290: Expected O, but got Unknown
			//IL_0291: Unknown result type (might be due to invalid IL or missing references)
			//IL_029b: Expected O, but got Unknown
			//IL_029c: Unknown result type (might be due to invalid IL or missing references)
			//IL_02a6: Expected O, but got Unknown
			//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
			//IL_02b1: Expected O, but got Unknown
			//IL_02b2: Unknown result type (might be due to invalid IL or missing references)
			//IL_02bc: Expected O, but got Unknown
			//IL_02bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_02c7: Expected O, but got Unknown
			//IL_02c8: Unknown result type (might be due to invalid IL or missing references)
			//IL_02d2: Expected O, but got Unknown
			//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_02dd: Expected O, but got Unknown
			//IL_02e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_02ee: Expected O, but got Unknown
			//IL_02ee: Unknown result type (might be due to invalid IL or missing references)
			//IL_02f4: Expected O, but got Unknown
			//IL_041d: Unknown result type (might be due to invalid IL or missing references)
			//IL_043c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0446: Expected O, but got Unknown
			//IL_0447: Unknown result type (might be due to invalid IL or missing references)
			//IL_045c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0480: Unknown result type (might be due to invalid IL or missing references)
			//IL_04c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_0509: Unknown result type (might be due to invalid IL or missing references)
			//IL_051d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0544: Unknown result type (might be due to invalid IL or missing references)
			//IL_0577: Unknown result type (might be due to invalid IL or missing references)
			//IL_0581: Expected O, but got Unknown
			//IL_058e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0598: Expected O, but got Unknown
			//IL_05c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_05cd: Expected O, but got Unknown
			//IL_05e2: Unknown result type (might be due to invalid IL or missing references)
			//IL_05f5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0619: Unknown result type (might be due to invalid IL or missing references)
			//IL_064c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0656: Expected O, but got Unknown
			//IL_0663: Unknown result type (might be due to invalid IL or missing references)
			//IL_066d: Expected O, but got Unknown
			//IL_0673: Unknown result type (might be due to invalid IL or missing references)
			//IL_06a8: Unknown result type (might be due to invalid IL or missing references)
			//IL_06bc: Unknown result type (might be due to invalid IL or missing references)
			//IL_06e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_0705: Unknown result type (might be due to invalid IL or missing references)
			//IL_074f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0763: Unknown result type (might be due to invalid IL or missing references)
			//IL_078a: Unknown result type (might be due to invalid IL or missing references)
			//IL_07d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_07de: Expected O, but got Unknown
			//IL_07f3: Unknown result type (might be due to invalid IL or missing references)
			//IL_0806: Unknown result type (might be due to invalid IL or missing references)
			//IL_082a: Unknown result type (might be due to invalid IL or missing references)
			//IL_085c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0883: Unknown result type (might be due to invalid IL or missing references)
			//IL_08bd: Unknown result type (might be due to invalid IL or missing references)
			//IL_08c7: Expected O, but got Unknown
			//IL_08cd: Unknown result type (might be due to invalid IL or missing references)
			//IL_08df: Unknown result type (might be due to invalid IL or missing references)
			//IL_08f3: Unknown result type (might be due to invalid IL or missing references)
			//IL_091a: Unknown result type (might be due to invalid IL or missing references)
			//IL_09b0: Unknown result type (might be due to invalid IL or missing references)
			//IL_09dd: Unknown result type (might be due to invalid IL or missing references)
			//IL_09f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a18: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a47: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a51: Expected O, but got Unknown
			//IL_0a5e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0a68: Expected O, but got Unknown
			//IL_0a74: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ad5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ae9: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b10: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b42: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b4c: Expected O, but got Unknown
			//IL_0b61: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b75: Unknown result type (might be due to invalid IL or missing references)
			//IL_0b99: Unknown result type (might be due to invalid IL or missing references)
			//IL_0bdb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0be5: Expected O, but got Unknown
			//IL_0bfa: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c0e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c32: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c74: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c7e: Expected O, but got Unknown
			//IL_0c8d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ca1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0cc5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d04: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d31: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d45: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d6f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0d9e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0da8: Expected O, but got Unknown
			//IL_0db5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dbf: Expected O, but got Unknown
			//IL_0dcb: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e00: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e14: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e3e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e70: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e7a: Expected O, but got Unknown
			//IL_0e89: Unknown result type (might be due to invalid IL or missing references)
			//IL_0e9d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ec1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0eed: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f30: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f44: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f6b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0f9e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fa8: Expected O, but got Unknown
			//IL_0fb5: Unknown result type (might be due to invalid IL or missing references)
			//IL_0fbf: Expected O, but got Unknown
			//IL_0fe7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ff1: Expected O, but got Unknown
			//IL_1006: Unknown result type (might be due to invalid IL or missing references)
			//IL_1019: Unknown result type (might be due to invalid IL or missing references)
			//IL_103d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1070: Unknown result type (might be due to invalid IL or missing references)
			//IL_107a: Expected O, but got Unknown
			//IL_1087: Unknown result type (might be due to invalid IL or missing references)
			//IL_1091: Expected O, but got Unknown
			//IL_1097: Unknown result type (might be due to invalid IL or missing references)
			//IL_10b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_10ca: Unknown result type (might be due to invalid IL or missing references)
			//IL_10f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_1114: Unknown result type (might be due to invalid IL or missing references)
			//IL_111e: Expected O, but got Unknown
			//IL_1124: Unknown result type (might be due to invalid IL or missing references)
			//IL_1164: Unknown result type (might be due to invalid IL or missing references)
			//IL_1178: Unknown result type (might be due to invalid IL or missing references)
			//IL_119f: Unknown result type (might be due to invalid IL or missing references)
			//IL_11d2: Unknown result type (might be due to invalid IL or missing references)
			//IL_11dc: Expected O, but got Unknown
			//IL_11e9: Unknown result type (might be due to invalid IL or missing references)
			//IL_11f3: Expected O, but got Unknown
			//IL_1200: Unknown result type (might be due to invalid IL or missing references)
			//IL_120a: Expected O, but got Unknown
			//IL_1232: Unknown result type (might be due to invalid IL or missing references)
			//IL_123c: Expected O, but got Unknown
			//IL_1251: Unknown result type (might be due to invalid IL or missing references)
			//IL_1264: Unknown result type (might be due to invalid IL or missing references)
			//IL_1288: Unknown result type (might be due to invalid IL or missing references)
			//IL_12d2: Unknown result type (might be due to invalid IL or missing references)
			//IL_12dc: Expected O, but got Unknown
			//IL_12e9: Unknown result type (might be due to invalid IL or missing references)
			//IL_12f3: Expected O, but got Unknown
			//IL_12f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_1318: Unknown result type (might be due to invalid IL or missing references)
			//IL_132c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1353: Unknown result type (might be due to invalid IL or missing references)
			//IL_136f: Unknown result type (might be due to invalid IL or missing references)
			//IL_13b2: Unknown result type (might be due to invalid IL or missing references)
			//IL_13c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_13ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_1420: Unknown result type (might be due to invalid IL or missing references)
			//IL_142a: Expected O, but got Unknown
			//IL_1437: Unknown result type (might be due to invalid IL or missing references)
			//IL_1441: Expected O, but got Unknown
			//IL_1469: Unknown result type (might be due to invalid IL or missing references)
			//IL_1473: Expected O, but got Unknown
			//IL_1488: Unknown result type (might be due to invalid IL or missing references)
			//IL_149b: Unknown result type (might be due to invalid IL or missing references)
			//IL_14bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_14f2: Unknown result type (might be due to invalid IL or missing references)
			//IL_14fc: Expected O, but got Unknown
			//IL_1509: Unknown result type (might be due to invalid IL or missing references)
			//IL_1513: Expected O, but got Unknown
			//IL_1519: Unknown result type (might be due to invalid IL or missing references)
			//IL_1538: Unknown result type (might be due to invalid IL or missing references)
			//IL_154c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1573: Unknown result type (might be due to invalid IL or missing references)
			//IL_158f: Unknown result type (might be due to invalid IL or missing references)
			//IL_15d2: Unknown result type (might be due to invalid IL or missing references)
			//IL_15e6: Unknown result type (might be due to invalid IL or missing references)
			//IL_160d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1640: Unknown result type (might be due to invalid IL or missing references)
			//IL_164a: Expected O, but got Unknown
			//IL_1657: Unknown result type (might be due to invalid IL or missing references)
			//IL_1661: Expected O, but got Unknown
			//IL_1689: Unknown result type (might be due to invalid IL or missing references)
			//IL_1693: Expected O, but got Unknown
			//IL_16a8: Unknown result type (might be due to invalid IL or missing references)
			//IL_16bb: Unknown result type (might be due to invalid IL or missing references)
			//IL_16df: Unknown result type (might be due to invalid IL or missing references)
			//IL_1729: Unknown result type (might be due to invalid IL or missing references)
			//IL_1733: Expected O, but got Unknown
			//IL_1740: Unknown result type (might be due to invalid IL or missing references)
			//IL_174a: Expected O, but got Unknown
			//IL_1750: Unknown result type (might be due to invalid IL or missing references)
			//IL_176f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1783: Unknown result type (might be due to invalid IL or missing references)
			//IL_17aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_17c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_1808: Unknown result type (might be due to invalid IL or missing references)
			//IL_181c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1843: Unknown result type (might be due to invalid IL or missing references)
			//IL_1876: Unknown result type (might be due to invalid IL or missing references)
			//IL_1880: Expected O, but got Unknown
			//IL_188d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1897: Expected O, but got Unknown
			//IL_18bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_18c9: Expected O, but got Unknown
			//IL_18de: Unknown result type (might be due to invalid IL or missing references)
			//IL_18f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_1921: Unknown result type (might be due to invalid IL or missing references)
			//IL_1954: Unknown result type (might be due to invalid IL or missing references)
			//IL_195e: Expected O, but got Unknown
			//IL_196b: Unknown result type (might be due to invalid IL or missing references)
			//IL_1975: Expected O, but got Unknown
			//IL_197b: Unknown result type (might be due to invalid IL or missing references)
			//IL_199a: Unknown result type (might be due to invalid IL or missing references)
			//IL_19ae: Unknown result type (might be due to invalid IL or missing references)
			//IL_19d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_19f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_1a34: Unknown result type (might be due to invalid IL or missing references)
			//IL_1a48: Unknown result type (might be due to invalid IL or missing references)
			//IL_1a6f: Unknown result type (might be due to invalid IL or missing references)
			//IL_1aa2: Unknown result type (might be due to invalid IL or missing references)
			//IL_1aac: Expected O, but got Unknown
			//IL_1ab9: Unknown result type (might be due to invalid IL or missing references)
			//IL_1ac3: Expected O, but got Unknown
			//IL_1aeb: Unknown result type (might be due to invalid IL or missing references)
			//IL_1af5: Expected O, but got Unknown
			//IL_1b0a: Unknown result type (might be due to invalid IL or missing references)
			//IL_1b1d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1b41: Unknown result type (might be due to invalid IL or missing references)
			//IL_1b8b: Unknown result type (might be due to invalid IL or missing references)
			//IL_1b95: Expected O, but got Unknown
			//IL_1ba2: Unknown result type (might be due to invalid IL or missing references)
			//IL_1bac: Expected O, but got Unknown
			//IL_1bb2: Unknown result type (might be due to invalid IL or missing references)
			//IL_1bd1: Unknown result type (might be due to invalid IL or missing references)
			//IL_1be5: Unknown result type (might be due to invalid IL or missing references)
			//IL_1c0c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1c8e: Unknown result type (might be due to invalid IL or missing references)
			//IL_1cbe: Unknown result type (might be due to invalid IL or missing references)
			//IL_1cd2: Unknown result type (might be due to invalid IL or missing references)
			//IL_1cfc: Unknown result type (might be due to invalid IL or missing references)
			//IL_1d3c: Unknown result type (might be due to invalid IL or missing references)
			//IL_1d46: Expected O, but got Unknown
			//IL_1d53: Unknown result type (might be due to invalid IL or missing references)
			//IL_1d5d: Expected O, but got Unknown
			//IL_1d76: Unknown result type (might be due to invalid IL or missing references)
			//IL_1dcb: Unknown result type (might be due to invalid IL or missing references)
			//IL_1ddf: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e09: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e3d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e79: Unknown result type (might be due to invalid IL or missing references)
			//IL_1e8d: Unknown result type (might be due to invalid IL or missing references)
			//IL_1ea1: Unknown result type (might be due to invalid IL or missing references)
			//IL_1ec5: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f2b: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f67: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f7a: Unknown result type (might be due to invalid IL or missing references)
			//IL_1f8e: Unknown result type (might be due to invalid IL or missing references)
			//IL_1fb2: Unknown result type (might be due to invalid IL or missing references)
			//IL_2014: Unknown result type (might be due to invalid IL or missing references)
			//IL_2068: Unknown result type (might be due to invalid IL or missing references)
			//IL_207c: Unknown result type (might be due to invalid IL or missing references)
			//IL_20a3: Unknown result type (might be due to invalid IL or missing references)
			//IL_20c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_20fa: Unknown result type (might be due to invalid IL or missing references)
			//IL_2104: Expected O, but got Unknown
			//IL_2119: Unknown result type (might be due to invalid IL or missing references)
			//IL_2147: Unknown result type (might be due to invalid IL or missing references)
			//IL_215b: Unknown result type (might be due to invalid IL or missing references)
			//IL_21c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_21f4: Unknown result type (might be due to invalid IL or missing references)
			//IL_2229: Unknown result type (might be due to invalid IL or missing references)
			//IL_2233: Expected O, but got Unknown
			//IL_2248: Unknown result type (might be due to invalid IL or missing references)
			//IL_2276: Unknown result type (might be due to invalid IL or missing references)
			//IL_228a: Unknown result type (might be due to invalid IL or missing references)
			//IL_22f5: Unknown result type (might be due to invalid IL or missing references)
			//IL_233d: Unknown result type (might be due to invalid IL or missing references)
			//IL_2372: Unknown result type (might be due to invalid IL or missing references)
			//IL_237c: Expected O, but got Unknown
			//IL_2391: Unknown result type (might be due to invalid IL or missing references)
			//IL_23be: Unknown result type (might be due to invalid IL or missing references)
			//IL_23d2: Unknown result type (might be due to invalid IL or missing references)
			//IL_243d: Unknown result type (might be due to invalid IL or missing references)
			//IL_248a: Unknown result type (might be due to invalid IL or missing references)
			//IL_2494: Expected O, but got Unknown
			//IL_24a9: Unknown result type (might be due to invalid IL or missing references)
			//IL_24c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_24e4: Unknown result type (might be due to invalid IL or missing references)
			//IL_2520: Unknown result type (might be due to invalid IL or missing references)
			//IL_2562: Unknown result type (might be due to invalid IL or missing references)
			//IL_2576: Unknown result type (might be due to invalid IL or missing references)
			//IL_25a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_25d3: Unknown result type (might be due to invalid IL or missing references)
			//IL_25dd: Expected O, but got Unknown
			//IL_25ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_25f4: Expected O, but got Unknown
			//IL_2601: Unknown result type (might be due to invalid IL or missing references)
			//IL_260b: Expected O, but got Unknown
			//IL_2618: Unknown result type (might be due to invalid IL or missing references)
			//IL_2622: Expected O, but got Unknown
			//IL_264a: Unknown result type (might be due to invalid IL or missing references)
			//IL_2654: Expected O, but got Unknown
			//IL_2669: Unknown result type (might be due to invalid IL or missing references)
			//IL_267c: Unknown result type (might be due to invalid IL or missing references)
			//IL_26a0: Unknown result type (might be due to invalid IL or missing references)
			//IL_26ea: Unknown result type (might be due to invalid IL or missing references)
			//IL_26f4: Expected O, but got Unknown
			//IL_2701: Unknown result type (might be due to invalid IL or missing references)
			//IL_270b: Expected O, but got Unknown
			//IL_2718: Unknown result type (might be due to invalid IL or missing references)
			//IL_2722: Expected O, but got Unknown
			//IL_2728: Unknown result type (might be due to invalid IL or missing references)
			//IL_284f: Unknown result type (might be due to invalid IL or missing references)
			//IL_2863: Unknown result type (might be due to invalid IL or missing references)
			//IL_288d: Unknown result type (might be due to invalid IL or missing references)
			//IL_28af: Unknown result type (might be due to invalid IL or missing references)
			//IL_28fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_2911: Unknown result type (might be due to invalid IL or missing references)
			//IL_2938: Unknown result type (might be due to invalid IL or missing references)
			//IL_2968: Unknown result type (might be due to invalid IL or missing references)
			//IL_2972: Expected O, but got Unknown
			//IL_298a: Unknown result type (might be due to invalid IL or missing references)
			//IL_29a4: Unknown result type (might be due to invalid IL or missing references)
			//IL_29ae: Expected O, but got Unknown
			//IL_29c3: Unknown result type (might be due to invalid IL or missing references)
			//IL_29d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_29f9: Unknown result type (might be due to invalid IL or missing references)
			//IL_2a42: Unknown result type (might be due to invalid IL or missing references)
			//IL_2a74: Unknown result type (might be due to invalid IL or missing references)
			//IL_2a7e: Expected O, but got Unknown
			//IL_2a84: Unknown result type (might be due to invalid IL or missing references)
			//IL_2a97: Unknown result type (might be due to invalid IL or missing references)
			//IL_2aab: Unknown result type (might be due to invalid IL or missing references)
			//IL_2b07: Unknown result type (might be due to invalid IL or missing references)
			//IL_2b50: Unknown result type (might be due to invalid IL or missing references)
			//IL_2b9e: Unknown result type (might be due to invalid IL or missing references)
			//IL_2bb2: Unknown result type (might be due to invalid IL or missing references)
			//IL_2bd9: Unknown result type (might be due to invalid IL or missing references)
			//IL_2c14: Unknown result type (might be due to invalid IL or missing references)
			//IL_2c2e: Unknown result type (might be due to invalid IL or missing references)
			//IL_2c38: Expected O, but got Unknown
			//IL_2c4d: Unknown result type (might be due to invalid IL or missing references)
			//IL_2c5f: Unknown result type (might be due to invalid IL or missing references)
			//IL_2c83: Unknown result type (might be due to invalid IL or missing references)
			//IL_2ccc: Unknown result type (might be due to invalid IL or missing references)
			//IL_2cfe: Unknown result type (might be due to invalid IL or missing references)
			//IL_2d08: Expected O, but got Unknown
			//IL_2d0e: Unknown result type (might be due to invalid IL or missing references)
			//IL_2d21: Unknown result type (might be due to invalid IL or missing references)
			//IL_2d35: Unknown result type (might be due to invalid IL or missing references)
			//IL_2d91: Unknown result type (might be due to invalid IL or missing references)
			//IL_2dda: Unknown result type (might be due to invalid IL or missing references)
			//IL_2e01: Unknown result type (might be due to invalid IL or missing references)
			//IL_2e38: Unknown result type (might be due to invalid IL or missing references)
			//IL_2e42: Expected O, but got Unknown
			//IL_2e48: Unknown result type (might be due to invalid IL or missing references)
			//IL_2e5e: Unknown result type (might be due to invalid IL or missing references)
			//IL_2e72: Unknown result type (might be due to invalid IL or missing references)
			//IL_2e99: Unknown result type (might be due to invalid IL or missing references)
			//IL_2f0b: Unknown result type (might be due to invalid IL or missing references)
			//IL_2f32: Unknown result type (might be due to invalid IL or missing references)
			//IL_2f69: Unknown result type (might be due to invalid IL or missing references)
			//IL_2f73: Expected O, but got Unknown
			//IL_2f79: Unknown result type (might be due to invalid IL or missing references)
			//IL_2f8f: Unknown result type (might be due to invalid IL or missing references)
			//IL_2fa3: Unknown result type (might be due to invalid IL or missing references)
			//IL_2fca: Unknown result type (might be due to invalid IL or missing references)
			//IL_303c: Unknown result type (might be due to invalid IL or missing references)
			//IL_3063: Unknown result type (might be due to invalid IL or missing references)
			//IL_309a: Unknown result type (might be due to invalid IL or missing references)
			//IL_30a4: Expected O, but got Unknown
			//IL_30aa: Unknown result type (might be due to invalid IL or missing references)
			//IL_30c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_30d4: Unknown result type (might be due to invalid IL or missing references)
			//IL_30fb: Unknown result type (might be due to invalid IL or missing references)
			//IL_316d: Unknown result type (might be due to invalid IL or missing references)
			//IL_3194: Unknown result type (might be due to invalid IL or missing references)
			//IL_31cb: Unknown result type (might be due to invalid IL or missing references)
			//IL_31d5: Expected O, but got Unknown
			//IL_31db: Unknown result type (might be due to invalid IL or missing references)
			//IL_31f1: Unknown result type (might be due to invalid IL or missing references)
			//IL_3205: Unknown result type (might be due to invalid IL or missing references)
			//IL_322c: Unknown result type (might be due to invalid IL or missing references)
			//IL_329e: Unknown result type (might be due to invalid IL or missing references)
			//IL_32c5: Unknown result type (might be due to invalid IL or missing references)
			//IL_32fc: Unknown result type (might be due to invalid IL or missing references)
			//IL_3306: Expected O, but got Unknown
			//IL_330c: Unknown result type (might be due to invalid IL or missing references)
			//IL_3322: Unknown result type (might be due to invalid IL or missing references)
			//IL_3336: Unknown result type (might be due to invalid IL or missing references)
			//IL_335d: Unknown result type (might be due to invalid IL or missing references)
			//IL_33cf: Unknown result type (might be due to invalid IL or missing references)
			//IL_33f6: Unknown result type (might be due to invalid IL or missing references)
			//IL_342d: Unknown result type (might be due to invalid IL or missing references)
			//IL_3437: Expected O, but got Unknown
			//IL_343d: Unknown result type (might be due to invalid IL or missing references)
			//IL_3450: Unknown result type (might be due to invalid IL or missing references)
			//IL_3464: Unknown result type (might be due to invalid IL or missing references)
			//IL_348b: Unknown result type (might be due to invalid IL or missing references)
			//IL_34fd: Unknown result type (might be due to invalid IL or missing references)
			//IL_3524: Unknown result type (might be due to invalid IL or missing references)
			//IL_355b: Unknown result type (might be due to invalid IL or missing references)
			//IL_3565: Expected O, but got Unknown
			//IL_356b: Unknown result type (might be due to invalid IL or missing references)
			//IL_357e: Unknown result type (might be due to invalid IL or missing references)
			//IL_3592: Unknown result type (might be due to invalid IL or missing references)
			//IL_35b9: Unknown result type (might be due to invalid IL or missing references)
			//IL_362b: Unknown result type (might be due to invalid IL or missing references)
			//IL_3652: Unknown result type (might be due to invalid IL or missing references)
			//IL_3689: Unknown result type (might be due to invalid IL or missing references)
			//IL_3693: Expected O, but got Unknown
			//IL_3699: Unknown result type (might be due to invalid IL or missing references)
			//IL_36ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_36c0: Unknown result type (might be due to invalid IL or missing references)
			//IL_36e7: Unknown result type (might be due to invalid IL or missing references)
			//IL_3758: Unknown result type (might be due to invalid IL or missing references)
			//IL_377f: Unknown result type (might be due to invalid IL or missing references)
			//IL_37b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_37c0: Expected O, but got Unknown
			//IL_37c6: Unknown result type (might be due to invalid IL or missing references)
			//IL_37d9: Unknown result type (might be due to invalid IL or missing references)
			//IL_37ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_3814: Unknown result type (might be due to invalid IL or missing references)
			//IL_3885: Unknown result type (might be due to invalid IL or missing references)
			//IL_38ac: Unknown result type (might be due to invalid IL or missing references)
			//IL_38e3: Unknown result type (might be due to invalid IL or missing references)
			//IL_38ed: Expected O, but got Unknown
			//IL_38f3: Unknown result type (might be due to invalid IL or missing references)
			//IL_3905: Unknown result type (might be due to invalid IL or missing references)
			//IL_3919: Unknown result type (might be due to invalid IL or missing references)
			//IL_3940: Unknown result type (might be due to invalid IL or missing references)
			//IL_39d0: Unknown result type (might be due to invalid IL or missing references)
			//IL_39da: Expected O, but got Unknown
			//IL_39ef: Unknown result type (might be due to invalid IL or missing references)
			//IL_3a06: Unknown result type (might be due to invalid IL or missing references)
			//IL_3a2a: Unknown result type (might be due to invalid IL or missing references)
			//IL_3a8f: Unknown result type (might be due to invalid IL or missing references)
			//IL_3aa1: Unknown result type (might be due to invalid IL or missing references)
			//IL_3ab6: Unknown result type (might be due to invalid IL or missing references)
			//IL_3bbc: Unknown result type (might be due to invalid IL or missing references)
			//IL_3bf9: Unknown result type (might be due to invalid IL or missing references)
			//IL_3c41: Unknown result type (might be due to invalid IL or missing references)
			//IL_3c4b: Expected O, but got Unknown
			components = (IContainer)new Container();
			panel2 = new Panel();
			label6 = new Label();
			TestCategory = new Panel();
			ClonablePanel = new Panel();
			label13 = new Label();
			ClonableButton = new Button();
			timer1 = new Timer(components);
			panel3 = new Panel();
			panel4 = new Panel();
			label3 = new Label();
			label2 = new Label();
			label1 = new Label();
			panel1 = new Panel();
			panel5 = new Panel();
			playerList = new Label();
			panel6 = new Panel();
			label5 = new Label();
			panel7 = new Panel();
			panel8 = new Panel();
			label4 = new Label();
			panel9 = new Panel();
			panel10 = new Panel();
			label7 = new Label();
			panel11 = new Panel();
			panel12 = new Panel();
			label8 = new Label();
			panel13 = new Panel();
			panel14 = new Panel();
			label9 = new Label();
			panel15 = new Panel();
			panel16 = new Panel();
			label10 = new Label();
			panel17 = new Panel();
			timer2 = new Timer(components);
			timer3 = new Timer(components);
			panel18 = new Panel();
			panel19 = new Panel();
			button2 = new Button();
			button1 = new Button();
			panel20 = new Panel();
			numericUpDown3 = new NumericUpDown();
			numericUpDown1 = new NumericUpDown();
			numericUpDown2 = new NumericUpDown();
			UpdateLabel = new Label();
			panel21 = new Panel();
			label11 = new Label();
			panel22 = new Panel();
			panel23 = new Panel();
			label14 = new Label();
			PotionAmplifier = new NumericUpDown();
			panel24 = new Panel();
			label15 = new Label();
			PotionDiritation = new NumericUpDown();
			button12 = new Button();
			button11 = new Button();
			button10 = new Button();
			button9 = new Button();
			button8 = new Button();
			button7 = new Button();
			button6 = new Button();
			button5 = new Button();
			button3 = new Button();
			button4 = new Button();
			label16 = new Label();
			timer4 = new Timer(components);
			Label val = new Label();
			((Control)panel2).SuspendLayout();
			((Control)TestCategory).SuspendLayout();
			((Control)ClonablePanel).SuspendLayout();
			((Control)panel3).SuspendLayout();
			((Control)panel4).SuspendLayout();
			((Control)panel1).SuspendLayout();
			((Control)panel5).SuspendLayout();
			((Control)panel6).SuspendLayout();
			((Control)panel8).SuspendLayout();
			((Control)panel10).SuspendLayout();
			((Control)panel12).SuspendLayout();
			((Control)panel14).SuspendLayout();
			((Control)panel16).SuspendLayout();
			((Control)panel18).SuspendLayout();
			((Control)panel19).SuspendLayout();
			((Control)panel20).SuspendLayout();
			((ISupportInitialize)numericUpDown3).BeginInit();
			((ISupportInitialize)numericUpDown1).BeginInit();
			((ISupportInitialize)numericUpDown2).BeginInit();
			((Control)panel21).SuspendLayout();
			((Control)panel22).SuspendLayout();
			((Control)panel23).SuspendLayout();
			((ISupportInitialize)PotionAmplifier).BeginInit();
			((Control)panel24).SuspendLayout();
			((ISupportInitialize)PotionDiritation).BeginInit();
			((Control)this).SuspendLayout();
			((Control)val).set_Anchor((AnchorStyles)10);
			((Control)val).set_AutoSize(true);
			((Control)val).set_BackColor(Color.get_Transparent());
			val.set_FlatStyle((FlatStyle)1);
			((Control)val).set_Font(new Font("Azonix", 27.75f, (FontStyle)1, (GraphicsUnit)3, (byte)0));
			((Control)val).set_ForeColor(Color.get_DeepPink());
			((Control)val).set_Location(new Point(1042, 499));
			((Control)val).set_Name("label12");
			((Control)val).set_RightToLeft((RightToLeft)1);
			((Control)val).set_Size(new Size(138, 37));
			((Control)val).set_TabIndex(6);
			((Control)val).set_Tag((object)"watermark");
			((Control)val).set_Text("TuNa");
			val.set_TextAlign((ContentAlignment)4);
			((Control)val).add_Click((EventHandler)label12_Click_1);
			((Control)panel2).set_BackColor(Color.get_DeepPink());
			((Control)panel2).get_Controls().Add((Control)(object)label6);
			((Control)panel2).get_Controls().Add((Control)(object)TestCategory);
			((Control)panel2).set_Location(new Point(562, 9));
			((Control)panel2).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel2).set_Name("panel2");
			((Control)panel2).set_Size(new Size(132, 96));
			((Control)panel2).set_TabIndex(1);
			((Control)panel2).set_Tag((object)"Category");
			((Control)panel2).add_MouseDown(new MouseEventHandler(panel2_MouseDown_1));
			((Control)panel2).add_MouseMove(new MouseEventHandler(panel2_MouseMove_1));
			((Control)label6).set_Anchor((AnchorStyles)3);
			((Control)label6).set_AutoSize(true);
			((Control)label6).set_Font(new Font("Nirmala UI Semilight", 9.75f, (FontStyle)0, (GraphicsUnit)3, (byte)0));
			((Control)label6).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label6).set_Location(new Point(46, 2));
			((Control)label6).set_Name("label6");
			((Control)label6).set_Size(new Size(40, 17));
			((Control)label6).set_TabIndex(5);
			((Control)label6).set_Text("Other");
			((Control)label6).add_MouseDown(new MouseEventHandler(label6_MouseDown));
			((Control)label6).add_MouseMove(new MouseEventHandler(label6_MouseMove));
			((Control)TestCategory).set_BackColor(Color.get_HotPink());
			((Control)TestCategory).get_Controls().Add((Control)(object)ClonablePanel);
			((Control)TestCategory).set_Dock((DockStyle)2);
			((Control)TestCategory).set_Location(new Point(0, 22));
			((Control)TestCategory).set_Margin(new Padding(3, 4, 3, 4));
			((Control)TestCategory).set_Name("TestCategory");
			((Control)TestCategory).set_Size(new Size(132, 74));
			((Control)TestCategory).set_TabIndex(0);
			((Control)ClonablePanel).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)ClonablePanel).get_Controls().Add((Control)(object)label13);
			((Control)ClonablePanel).get_Controls().Add((Control)(object)ClonableButton);
			((Control)ClonablePanel).set_Dock((DockStyle)1);
			((Control)ClonablePanel).set_Location(new Point(0, 0));
			((Control)ClonablePanel).set_Margin(new Padding(3, 4, 3, 4));
			((Control)ClonablePanel).set_Name("ClonablePanel");
			((Control)ClonablePanel).set_Size(new Size(132, 28));
			((Control)ClonablePanel).set_TabIndex(5);
			((Control)ClonablePanel).set_Visible(false);
			((Control)label13).set_AutoSize(true);
			((Control)label13).set_Dock((DockStyle)1);
			((Control)label13).set_Font(new Font("Nirmala UI Semilight", 10f));
			((Control)label13).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label13).set_Location(new Point(0, 28));
			((Control)label13).set_Name("label13");
			((Control)label13).set_Size(new Size(71, 19));
			((Control)label13).set_TabIndex(6);
			((Control)label13).set_Text("Keybind: ?");
			((Control)ClonableButton).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)ClonableButton).set_Dock((DockStyle)1);
			((ButtonBase)ClonableButton).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)ClonableButton).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)ClonableButton).set_FlatStyle((FlatStyle)0);
			((Control)ClonableButton).set_Font(new Font("Nirmala UI Semilight", 9f, (FontStyle)0, (GraphicsUnit)3, (byte)0));
			((Control)ClonableButton).set_ForeColor(SystemColors.get_Control());
			((Control)ClonableButton).set_Location(new Point(0, 0));
			((Control)ClonableButton).set_Margin(new Padding(3, 4, 3, 4));
			((Control)ClonableButton).set_Name("ClonableButton");
			((Control)ClonableButton).set_Size(new Size(132, 28));
			((Control)ClonableButton).set_TabIndex(5);
			((Control)ClonableButton).set_TabStop(false);
			((Control)ClonableButton).set_Tag((object)"ModuleButton");
			((Control)ClonableButton).set_Text("TestModule");
			((ButtonBase)ClonableButton).set_UseVisualStyleBackColor(false);
			((Control)ClonableButton).set_Visible(false);
			timer1.set_Enabled(true);
			timer1.add_Tick((EventHandler)timer1_Tick);
			((Control)panel3).set_Anchor((AnchorStyles)9);
			((Control)panel3).set_BackColor(Color.FromArgb(31, 41, 55));
			((Control)panel3).get_Controls().Add((Control)(object)panel4);
			((Control)panel3).set_Location(new Point(1387, 9));
			((Control)panel3).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel3).set_Name("panel3");
			((Control)panel3).set_Size(new Size(150, 100));
			((Control)panel3).set_TabIndex(2);
			((Control)panel3).set_Visible(false);
			((Control)panel3).add_MouseDown(new MouseEventHandler(panel3_MouseDown));
			((Control)panel3).add_MouseMove(new MouseEventHandler(panel3_MouseMove));
			((Control)panel4).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)panel4).get_Controls().Add((Control)(object)label3);
			((Control)panel4).get_Controls().Add((Control)(object)label2);
			((Control)panel4).get_Controls().Add((Control)(object)label1);
			((Control)panel4).set_Dock((DockStyle)2);
			((Control)panel4).set_Location(new Point(0, 24));
			((Control)panel4).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel4).set_Name("panel4");
			((Control)panel4).set_Size(new Size(150, 76));
			((Control)panel4).set_TabIndex(0);
			((Control)label3).set_AutoSize(true);
			((Control)label3).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)label3).set_ForeColor(Color.FromArgb(255, 224, 192));
			((Control)label3).set_Location(new Point(10, 43));
			((Control)label3).set_Name("label3");
			((Control)label3).set_Size(new Size(20, 15));
			((Control)label3).set_TabIndex(5);
			((Control)label3).set_Text("0b");
			((Control)label2).set_AutoSize(true);
			((Control)label2).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)label2).set_ForeColor(Color.FromArgb(255, 192, 128));
			((Control)label2).set_Location(new Point(10, 26));
			((Control)label2).set_Name("label2");
			((Control)label2).set_Size(new Size(37, 15));
			((Control)label2).set_TabIndex(4);
			((Control)label2).set_Text("0, 0, 0");
			((Control)label1).set_AutoSize(true);
			((Control)label1).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)label1).set_ForeColor(Color.FromArgb(190, 92, 88));
			((Control)label1).set_Location(new Point(10, 9));
			((Control)label1).set_Name("label1");
			((Control)label1).set_Size(new Size(59, 15));
			((Control)label1).set_TabIndex(3);
			((Control)label1).set_Text("Username");
			((Control)panel1).set_Anchor((AnchorStyles)9);
			((Control)panel1).set_BackColor(Color.FromArgb(31, 41, 55));
			((Control)panel1).get_Controls().Add((Control)(object)panel5);
			((Control)panel1).set_Location(new Point(1387, 112));
			((Control)panel1).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel1).set_Name("panel1");
			((Control)panel1).set_Size(new Size(150, 200));
			((Control)panel1).set_TabIndex(3);
			((Control)panel1).set_Visible(false);
			((Control)panel1).add_MouseDown(new MouseEventHandler(panel1_MouseDown));
			((Control)panel1).add_MouseMove(new MouseEventHandler(panel1_MouseMove));
			((Control)panel5).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)panel5).get_Controls().Add((Control)(object)playerList);
			((Control)panel5).set_Dock((DockStyle)2);
			((Control)panel5).set_Location(new Point(0, 24));
			((Control)panel5).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel5).set_Name("panel5");
			((Control)panel5).set_Size(new Size(150, 176));
			((Control)panel5).set_TabIndex(0);
			((Control)playerList).set_AutoSize(true);
			((Control)playerList).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)playerList).set_ForeColor(Color.FromArgb(190, 92, 88));
			((Control)playerList).set_Location(new Point(10, 9));
			((Control)playerList).set_Name("playerList");
			((Control)playerList).set_Size(new Size(68, 15));
			((Control)playerList).set_TabIndex(3);
			((Control)playerList).set_Text("PlayersHere");
			((Control)panel6).set_BackColor(Color.get_DeepPink());
			((Control)panel6).get_Controls().Add((Control)(object)label5);
			((Control)panel6).get_Controls().Add((Control)(object)panel7);
			((Control)panel6).set_Location(new Point(700, 9));
			((Control)panel6).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel6).set_Name("panel6");
			((Control)panel6).set_Size(new Size(132, 96));
			((Control)panel6).set_TabIndex(2);
			((Control)panel6).set_Tag((object)"Category");
			((Control)panel6).add_MouseDown(new MouseEventHandler(panel6_MouseDown));
			((Control)panel6).add_MouseMove(new MouseEventHandler(panel6_MouseMove));
			((Control)label5).set_Anchor((AnchorStyles)3);
			((Control)label5).set_AutoSize(true);
			((Control)label5).set_Font(new Font("Nirmala UI Semilight", 9.75f));
			((Control)label5).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label5).set_Location(new Point(48, 2));
			((Control)label5).set_Name("label5");
			((Control)label5).set_Size(new Size(32, 17));
			((Control)label5).set_TabIndex(4);
			((Control)label5).set_Text("Flies");
			((Control)label5).add_MouseDown(new MouseEventHandler(label5_MouseDown));
			((Control)label5).add_MouseMove(new MouseEventHandler(label5_MouseMove));
			((Control)panel7).set_BackColor(Color.get_HotPink());
			((Control)panel7).set_Dock((DockStyle)2);
			((Control)panel7).set_Location(new Point(0, 22));
			((Control)panel7).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel7).set_Name("panel7");
			((Control)panel7).set_Size(new Size(132, 74));
			((Control)panel7).set_TabIndex(0);
			((Control)panel7).add_Paint(new PaintEventHandler(panel7_Paint));
			((Control)panel8).set_BackColor(Color.get_DeepPink());
			((Control)panel8).get_Controls().Add((Control)(object)label4);
			((Control)panel8).get_Controls().Add((Control)(object)panel9);
			((Control)panel8).set_Location(new Point(10, 9));
			((Control)panel8).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel8).set_Name("panel8");
			((Control)panel8).set_Size(new Size(132, 96));
			((Control)panel8).set_TabIndex(5);
			((Control)panel8).set_Tag((object)"Category");
			((Control)panel8).add_Paint(new PaintEventHandler(panel8_Paint));
			((Control)panel8).add_MouseDown(new MouseEventHandler(panel8_MouseDown));
			((Control)panel8).add_MouseMove(new MouseEventHandler(panel8_MouseMove));
			((Control)label4).set_Anchor((AnchorStyles)3);
			((Control)label4).set_AutoSize(true);
			((Control)label4).set_Font(new Font("Nirmala UI Semilight", 9.75f));
			((Control)label4).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label4).set_Location(new Point(40, 1));
			((Control)label4).set_Name("label4");
			((Control)label4).set_Size(new Size(41, 17));
			((Control)label4).set_TabIndex(4);
			((Control)label4).set_Text("World");
			((Control)label4).add_Click((EventHandler)label4_Click);
			((Control)label4).add_MouseDown(new MouseEventHandler(label4_MouseDown));
			((Control)label4).add_MouseMove(new MouseEventHandler(label4_MouseMove));
			((Control)panel9).set_BackColor(Color.get_HotPink());
			((Control)panel9).set_Dock((DockStyle)2);
			((Control)panel9).set_Location(new Point(0, 22));
			((Control)panel9).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel9).set_Name("panel9");
			((Control)panel9).set_Size(new Size(132, 74));
			((Control)panel9).set_TabIndex(0);
			((Control)panel10).set_BackColor(Color.get_DeepPink());
			((Control)panel10).get_Controls().Add((Control)(object)label7);
			((Control)panel10).get_Controls().Add((Control)(object)panel11);
			((Control)panel10).set_Location(new Point(148, 9));
			((Control)panel10).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel10).set_Name("panel10");
			((Control)panel10).set_Size(new Size(132, 96));
			((Control)panel10).set_TabIndex(6);
			((Control)panel10).set_Tag((object)"Category");
			((Control)panel10).add_MouseDown(new MouseEventHandler(panel10_MouseDown));
			((Control)panel10).add_MouseMove(new MouseEventHandler(panel10_MouseMove));
			((Control)label7).set_Anchor((AnchorStyles)3);
			((Control)label7).set_AutoSize(true);
			((Control)label7).set_Font(new Font("Nirmala UI Semilight", 9.75f));
			((Control)label7).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label7).set_Location(new Point(37, 2));
			((Control)label7).set_Name("label7");
			((Control)label7).set_Size(new Size(52, 17));
			((Control)label7).set_TabIndex(4);
			((Control)label7).set_Text("Combat");
			((Control)label7).add_MouseDown(new MouseEventHandler(label7_MouseDown));
			((Control)label7).add_MouseMove(new MouseEventHandler(label7_MouseMove));
			((Control)panel11).set_BackColor(Color.get_HotPink());
			((Control)panel11).set_Dock((DockStyle)2);
			((Control)panel11).set_Location(new Point(0, 22));
			((Control)panel11).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel11).set_Name("panel11");
			((Control)panel11).set_Size(new Size(132, 74));
			((Control)panel11).set_TabIndex(0);
			((Control)panel12).set_BackColor(Color.get_DeepPink());
			((Control)panel12).get_Controls().Add((Control)(object)label8);
			((Control)panel12).get_Controls().Add((Control)(object)panel13);
			((Control)panel12).set_Location(new Point(424, 9));
			((Control)panel12).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel12).set_Name("panel12");
			((Control)panel12).set_Size(new Size(132, 96));
			((Control)panel12).set_TabIndex(7);
			((Control)panel12).set_Tag((object)"Category");
			((Control)panel12).add_MouseDown(new MouseEventHandler(panel12_MouseDown));
			((Control)panel12).add_MouseMove(new MouseEventHandler(panel12_MouseMove));
			((Control)label8).set_Anchor((AnchorStyles)3);
			((Control)label8).set_AutoSize(true);
			((Control)label8).set_Font(new Font("Nirmala UI Semilight", 9.75f));
			((Control)label8).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label8).set_Location(new Point(40, 2));
			((Control)label8).set_Name("label8");
			((Control)label8).set_Size(new Size(50, 17));
			((Control)label8).set_TabIndex(4);
			((Control)label8).set_Text("Exploits");
			((Control)label8).add_Click((EventHandler)label8_Click);
			((Control)label8).add_MouseDown(new MouseEventHandler(label8_MouseDown));
			((Control)label8).add_MouseMove(new MouseEventHandler(label8_MouseMove));
			((Control)panel13).set_BackColor(Color.get_HotPink());
			((Control)panel13).set_Dock((DockStyle)2);
			((Control)panel13).set_Location(new Point(0, 22));
			((Control)panel13).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel13).set_Name("panel13");
			((Control)panel13).set_Size(new Size(132, 74));
			((Control)panel13).set_TabIndex(0);
			((Control)panel14).set_BackColor(Color.get_DeepPink());
			((Control)panel14).get_Controls().Add((Control)(object)label9);
			((Control)panel14).get_Controls().Add((Control)(object)panel15);
			((Control)panel14).set_Location(new Point(838, 8));
			((Control)panel14).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel14).set_Name("panel14");
			((Control)panel14).set_Size(new Size(132, 96));
			((Control)panel14).set_TabIndex(8);
			((Control)panel14).set_Tag((object)"Category");
			((Control)panel14).add_MouseDown(new MouseEventHandler(panel14_MouseDown));
			((Control)panel14).add_MouseMove(new MouseEventHandler(panel14_MouseMove));
			((Control)label9).set_Anchor((AnchorStyles)3);
			((Control)label9).set_AutoSize(true);
			((Control)label9).set_Font(new Font("Nirmala UI Semilight", 9.75f));
			((Control)label9).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label9).set_Location(new Point(45, 1));
			((Control)label9).set_Name("label9");
			((Control)label9).set_RightToLeft((RightToLeft)0);
			((Control)label9).set_Size(new Size(41, 17));
			((Control)label9).set_TabIndex(4);
			((Control)label9).set_Text("Visual");
			((Control)label9).add_MouseDown(new MouseEventHandler(label9_MouseDown));
			((Control)label9).add_MouseMove(new MouseEventHandler(label9_MouseMove));
			((Control)panel15).set_BackColor(Color.get_HotPink());
			((Control)panel15).set_Dock((DockStyle)2);
			((Control)panel15).set_Location(new Point(0, 22));
			((Control)panel15).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel15).set_Name("panel15");
			((Control)panel15).set_Size(new Size(132, 74));
			((Control)panel15).set_TabIndex(0);
			((Control)panel16).set_BackColor(Color.get_DeepPink());
			((Control)panel16).get_Controls().Add((Control)(object)label10);
			((Control)panel16).get_Controls().Add((Control)(object)panel17);
			((Control)panel16).set_Location(new Point(286, 9));
			((Control)panel16).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel16).set_Name("panel16");
			((Control)panel16).set_Size(new Size(132, 96));
			((Control)panel16).set_TabIndex(8);
			((Control)panel16).set_Tag((object)"Category");
			((Control)panel16).add_MouseDown(new MouseEventHandler(panel16_MouseDown));
			((Control)panel16).add_MouseMove(new MouseEventHandler(panel16_MouseMove));
			((Control)label10).set_Anchor((AnchorStyles)3);
			((Control)label10).set_AutoSize(true);
			((Control)label10).set_Font(new Font("Nirmala UI Semilight", 9.75f));
			((Control)label10).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label10).set_Location(new Point(43, 1));
			((Control)label10).set_Name("label10");
			((Control)label10).set_Size(new Size(42, 17));
			((Control)label10).set_TabIndex(4);
			((Control)label10).set_Text("Player");
			((Control)label10).add_Click((EventHandler)label10_Click);
			((Control)label10).add_MouseDown(new MouseEventHandler(label10_MouseDown));
			((Control)label10).add_MouseMove(new MouseEventHandler(label10_MouseMove));
			((Control)panel17).set_BackColor(Color.get_HotPink());
			((Control)panel17).set_Dock((DockStyle)2);
			((Control)panel17).set_Location(new Point(0, 22));
			((Control)panel17).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel17).set_Name("panel17");
			((Control)panel17).set_Size(new Size(132, 74));
			((Control)panel17).set_TabIndex(0);
			timer2.set_Enabled(true);
			timer2.add_Tick((EventHandler)timer2_Tick);
			timer3.set_Enabled(true);
			timer3.set_Interval(25);
			timer3.add_Tick((EventHandler)timer3_Tick);
			((Control)panel18).set_Anchor((AnchorStyles)10);
			((Control)panel18).set_BackColor(Color.FromArgb(31, 41, 55));
			((Control)panel18).get_Controls().Add((Control)(object)panel19);
			((Control)panel18).set_Location(new Point(1336, 337));
			((Control)panel18).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel18).set_Name("panel18");
			((Control)panel18).set_Size(new Size(201, 158));
			((Control)panel18).set_TabIndex(9);
			((Control)panel18).set_Tag((object)"TeleportUI");
			((Control)panel18).set_Visible(false);
			((Control)panel18).add_MouseDown(new MouseEventHandler(panel18_MouseDown));
			((Control)panel18).add_MouseMove(new MouseEventHandler(panel18_MouseMove));
			((Control)panel19).set_Anchor((AnchorStyles)15);
			((Control)panel19).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)panel19).get_Controls().Add((Control)(object)button2);
			((Control)panel19).get_Controls().Add((Control)(object)button1);
			((Control)panel19).get_Controls().Add((Control)(object)panel20);
			((Control)panel19).set_Location(new Point(0, 24));
			((Control)panel19).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel19).set_Name("panel19");
			((Control)panel19).set_Size(new Size(201, 134));
			((Control)panel19).set_TabIndex(0);
			((Control)button2).set_Anchor((AnchorStyles)10);
			((ButtonBase)button2).get_FlatAppearance().set_BorderColor(Color.FromArgb(44, 44, 44));
			((ButtonBase)button2).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button2).set_FlatStyle((FlatStyle)0);
			((Control)button2).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)button2).set_Location(new Point(122, 108));
			((Control)button2).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button2).set_Name("button2");
			((Control)button2).set_Size(new Size(75, 22));
			((Control)button2).set_TabIndex(3);
			((Control)button2).set_Text("Done");
			((ButtonBase)button2).set_UseVisualStyleBackColor(true);
			((Control)button2).add_Click((EventHandler)button2_Click);
			((Control)button1).set_Anchor((AnchorStyles)6);
			((ButtonBase)button1).get_FlatAppearance().set_BorderColor(Color.FromArgb(44, 44, 44));
			((ButtonBase)button1).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button1).set_FlatStyle((FlatStyle)0);
			((Control)button1).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)button1).set_Location(new Point(5, 106));
			((Control)button1).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button1).set_Name("button1");
			((Control)button1).set_Size(new Size(75, 22));
			((Control)button1).set_TabIndex(2);
			((Control)button1).set_Text("Teleport");
			((ButtonBase)button1).set_UseVisualStyleBackColor(true);
			((Control)button1).add_Click((EventHandler)button1_Click);
			((Control)panel20).set_Anchor((AnchorStyles)15);
			((Control)panel20).set_BackColor(Color.FromArgb(44, 44, 44));
			((Control)panel20).get_Controls().Add((Control)(object)numericUpDown3);
			((Control)panel20).get_Controls().Add((Control)(object)numericUpDown1);
			((Control)panel20).get_Controls().Add((Control)(object)numericUpDown2);
			((Control)panel20).set_Location(new Point(8, 7));
			((Control)panel20).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel20).set_Name("panel20");
			((Control)panel20).set_Size(new Size(185, 82));
			((Control)panel20).set_TabIndex(1);
			((Control)numericUpDown3).set_BackColor(Color.FromArgb(54, 71, 96));
			((UpDownBase)numericUpDown3).set_BorderStyle((BorderStyle)0);
			((Control)numericUpDown3).set_Dock((DockStyle)1);
			((Control)numericUpDown3).set_Font(new Font("Microsoft Sans Serif", 15.75f, (FontStyle)0, (GraphicsUnit)3, (byte)0));
			((Control)numericUpDown3).set_ForeColor(Color.FromArgb(255, 255, 254));
			numericUpDown3.set_Increment(new decimal(new int[4]
			{
				100,
				0,
				0,
				0
			}));
			((Control)numericUpDown3).set_Location(new Point(0, 54));
			((Control)numericUpDown3).set_Margin(new Padding(3, 4, 3, 4));
			numericUpDown3.set_Maximum(new decimal(new int[4]
			{
				30000000,
				0,
				0,
				0
			}));
			numericUpDown3.set_Minimum(new decimal(new int[4]
			{
				30000000,
				0,
				0,
				-2147483648
			}));
			((Control)numericUpDown3).set_Name("numericUpDown3");
			((Control)numericUpDown3).set_Size(new Size(185, 27));
			((Control)numericUpDown3).set_TabIndex(2);
			((UpDownBase)numericUpDown3).set_TextAlign((HorizontalAlignment)2);
			((Control)numericUpDown1).set_BackColor(Color.FromArgb(54, 71, 96));
			((UpDownBase)numericUpDown1).set_BorderStyle((BorderStyle)0);
			((Control)numericUpDown1).set_Dock((DockStyle)1);
			((Control)numericUpDown1).set_Font(new Font("Microsoft Sans Serif", 15.75f, (FontStyle)0, (GraphicsUnit)3, (byte)0));
			((Control)numericUpDown1).set_ForeColor(Color.FromArgb(255, 255, 254));
			numericUpDown1.set_Increment(new decimal(new int[4]
			{
				10,
				0,
				0,
				0
			}));
			((Control)numericUpDown1).set_Location(new Point(0, 27));
			((Control)numericUpDown1).set_Margin(new Padding(3, 4, 3, 4));
			numericUpDown1.set_Maximum(new decimal(new int[4]
			{
				30000000,
				0,
				0,
				0
			}));
			numericUpDown1.set_Minimum(new decimal(new int[4]
			{
				30000000,
				0,
				0,
				-2147483648
			}));
			((Control)numericUpDown1).set_Name("numericUpDown1");
			((Control)numericUpDown1).set_Size(new Size(185, 27));
			((Control)numericUpDown1).set_TabIndex(1);
			((UpDownBase)numericUpDown1).set_TextAlign((HorizontalAlignment)2);
			numericUpDown1.set_Value(new decimal(new int[4]
			{
				4,
				0,
				0,
				0
			}));
			((Control)numericUpDown2).set_BackColor(Color.FromArgb(54, 71, 96));
			((UpDownBase)numericUpDown2).set_BorderStyle((BorderStyle)0);
			((Control)numericUpDown2).set_Dock((DockStyle)1);
			((Control)numericUpDown2).set_Font(new Font("Microsoft Sans Serif", 15.75f, (FontStyle)0, (GraphicsUnit)3, (byte)0));
			((Control)numericUpDown2).set_ForeColor(Color.FromArgb(255, 255, 254));
			numericUpDown2.set_Increment(new decimal(new int[4]
			{
				100,
				0,
				0,
				0
			}));
			((Control)numericUpDown2).set_Location(new Point(0, 0));
			((Control)numericUpDown2).set_Margin(new Padding(3, 4, 3, 4));
			numericUpDown2.set_Maximum(new decimal(new int[4]
			{
				30000000,
				0,
				0,
				0
			}));
			numericUpDown2.set_Minimum(new decimal(new int[4]
			{
				30000000,
				0,
				0,
				-2147483648
			}));
			((Control)numericUpDown2).set_Name("numericUpDown2");
			((Control)numericUpDown2).set_Size(new Size(185, 27));
			((Control)numericUpDown2).set_TabIndex(0);
			((UpDownBase)numericUpDown2).set_TextAlign((HorizontalAlignment)2);
			((Control)UpdateLabel).set_Anchor((AnchorStyles)6);
			((Control)UpdateLabel).set_AutoSize(true);
			((Control)UpdateLabel).set_Font(new Font("Microsoft Sans Serif", 15.75f, (FontStyle)0, (GraphicsUnit)3, (byte)0));
			((Control)UpdateLabel).set_ForeColor(Color.FromArgb(255, 224, 192));
			((Control)UpdateLabel).set_Location(new Point(12, 511));
			((Control)UpdateLabel).set_Name("UpdateLabel");
			((Control)UpdateLabel).set_Size(new Size(125, 25));
			((Control)UpdateLabel).set_TabIndex(6);
			((Control)UpdateLabel).set_Tag((object)"CoordsHud");
			((Control)UpdateLabel).set_Text("Not InGame");
			((Control)panel21).set_BackColor(Color.get_DeepPink());
			((Control)panel21).get_Controls().Add((Control)(object)label11);
			((Control)panel21).get_Controls().Add((Control)(object)panel22);
			((Control)panel21).set_Location(new Point(990, 8));
			((Control)panel21).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel21).set_Name("panel21");
			((Control)panel21).set_Size(new Size(132, 379));
			((Control)panel21).set_TabIndex(6);
			((Control)panel21).set_Tag((object)"Category");
			((Control)panel21).add_Paint(new PaintEventHandler(panel21_Paint));
			((Control)panel21).add_MouseClick(new MouseEventHandler(panel21_MouseClick));
			((Control)panel21).add_MouseDown(new MouseEventHandler(panel21_MouseDown));
			((Control)panel21).add_MouseMove(new MouseEventHandler(panel21_MouseMove));
			((Control)label11).set_Anchor((AnchorStyles)3);
			((Control)label11).set_AutoSize(true);
			((Control)label11).set_Font(new Font("Nirmala UI Semilight", 9.75f));
			((Control)label11).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label11).set_Location(new Point(43, 2));
			((Control)label11).set_Name("label11");
			((Control)label11).set_Size(new Size(45, 17));
			((Control)label11).set_TabIndex(5);
			((Control)label11).set_Text("Effects");
			((Control)label11).add_Click((EventHandler)label11_Click);
			((Control)label11).add_MouseClick(new MouseEventHandler(label11_MouseClick));
			((Control)label11).add_MouseDown(new MouseEventHandler(label11_MouseDown));
			((Control)label11).add_MouseMove(new MouseEventHandler(label11_MouseMove));
			((Control)panel22).set_BackColor(Color.get_HotPink());
			((Control)panel22).get_Controls().Add((Control)(object)panel23);
			((Control)panel22).get_Controls().Add((Control)(object)panel24);
			((Control)panel22).get_Controls().Add((Control)(object)button12);
			((Control)panel22).get_Controls().Add((Control)(object)button11);
			((Control)panel22).get_Controls().Add((Control)(object)button10);
			((Control)panel22).get_Controls().Add((Control)(object)button9);
			((Control)panel22).get_Controls().Add((Control)(object)button8);
			((Control)panel22).get_Controls().Add((Control)(object)button7);
			((Control)panel22).get_Controls().Add((Control)(object)button6);
			((Control)panel22).get_Controls().Add((Control)(object)button5);
			((Control)panel22).get_Controls().Add((Control)(object)button3);
			((Control)panel22).get_Controls().Add((Control)(object)button4);
			((Control)panel22).set_Dock((DockStyle)2);
			((Control)panel22).set_Location(new Point(0, 24));
			((Control)panel22).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel22).set_Name("panel22");
			((Control)panel22).set_Size(new Size(132, 355));
			((Control)panel22).set_TabIndex(0);
			((Control)panel23).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)panel23).get_Controls().Add((Control)(object)label14);
			((Control)panel23).get_Controls().Add((Control)(object)PotionAmplifier);
			((Control)panel23).set_Dock((DockStyle)1);
			((Control)panel23).set_Location(new Point(0, 312));
			((Control)panel23).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel23).set_Name("panel23");
			((Control)panel23).set_Size(new Size(132, 28));
			((Control)panel23).set_TabIndex(12);
			((Control)panel23).set_Visible(false);
			((Control)panel23).add_Paint(new PaintEventHandler(panel23_Paint));
			((Control)label14).set_AutoSize(true);
			((Control)label14).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)label14).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)label14).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label14).set_Location(new Point(6, 6));
			((Control)label14).set_Name("label14");
			((Control)label14).set_Size(new Size(55, 15));
			((Control)label14).set_TabIndex(6);
			((Control)label14).set_Text("Amplifier");
			((Control)label14).add_Click((EventHandler)label14_Click);
			((Control)PotionAmplifier).set_BackColor(Color.FromArgb(54, 71, 96));
			((UpDownBase)PotionAmplifier).set_BorderStyle((BorderStyle)0);
			((Control)PotionAmplifier).set_Dock((DockStyle)4);
			((Control)PotionAmplifier).set_Font(new Font("Microsoft Sans Serif", 14f));
			((Control)PotionAmplifier).set_ForeColor(Color.get_White());
			((Control)PotionAmplifier).set_Location(new Point(58, 0));
			((Control)PotionAmplifier).set_Margin(new Padding(3, 4, 3, 4));
			PotionAmplifier.set_Maximum(new decimal(new int[4]
			{
				256,
				0,
				0,
				0
			}));
			PotionAmplifier.set_Minimum(new decimal(new int[4]
			{
				1,
				0,
				0,
				0
			}));
			((Control)PotionAmplifier).set_Name("PotionAmplifier");
			((Control)PotionAmplifier).set_Size(new Size(74, 25));
			((Control)PotionAmplifier).set_TabIndex(11);
			((UpDownBase)PotionAmplifier).set_TextAlign((HorizontalAlignment)2);
			PotionAmplifier.set_Value(new decimal(new int[4]
			{
				1,
				0,
				0,
				0
			}));
			((Control)panel24).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)panel24).get_Controls().Add((Control)(object)label15);
			((Control)panel24).get_Controls().Add((Control)(object)PotionDiritation);
			((Control)panel24).set_Dock((DockStyle)1);
			((Control)panel24).set_Location(new Point(0, 284));
			((Control)panel24).set_Margin(new Padding(3, 4, 3, 4));
			((Control)panel24).set_Name("panel24");
			((Control)panel24).set_Size(new Size(132, 28));
			((Control)panel24).set_TabIndex(13);
			((Control)panel24).set_Visible(false);
			((Control)label15).set_AutoSize(true);
			((Control)label15).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)label15).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)label15).set_ForeColor(Color.FromArgb(255, 255, 254));
			((Control)label15).set_Location(new Point(6, 6));
			((Control)label15).set_Name("label15");
			((Control)label15).set_Size(new Size(56, 15));
			((Control)label15).set_TabIndex(6);
			((Control)label15).set_Text("Diritation");
			((Control)label15).add_Click((EventHandler)label15_Click);
			((Control)PotionDiritation).set_BackColor(Color.FromArgb(54, 71, 96));
			((UpDownBase)PotionDiritation).set_BorderStyle((BorderStyle)0);
			((Control)PotionDiritation).set_Dock((DockStyle)4);
			((Control)PotionDiritation).set_Font(new Font("Microsoft Sans Serif", 14f));
			((Control)PotionDiritation).set_ForeColor(Color.get_White());
			((Control)PotionDiritation).set_Location(new Point(58, 0));
			((Control)PotionDiritation).set_Margin(new Padding(3, 4, 3, 4));
			PotionDiritation.set_Maximum(new decimal(new int[4]
			{
				99999,
				0,
				0,
				0
			}));
			PotionDiritation.set_Minimum(new decimal(new int[4]
			{
				1,
				0,
				0,
				0
			}));
			((Control)PotionDiritation).set_Name("PotionDiritation");
			((Control)PotionDiritation).set_Size(new Size(74, 25));
			((Control)PotionDiritation).set_TabIndex(11);
			((UpDownBase)PotionDiritation).set_TextAlign((HorizontalAlignment)2);
			PotionDiritation.set_Value(new decimal(new int[4]
			{
				5,
				0,
				0,
				0
			}));
			((Control)button12).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button12).set_Dock((DockStyle)1);
			((ButtonBase)button12).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button12).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button12).set_FlatStyle((FlatStyle)0);
			((Control)button12).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button12).set_ForeColor(SystemColors.get_Control());
			((Control)button12).set_Location(new Point(0, 256));
			((Control)button12).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button12).set_Name("button12");
			((Control)button12).set_Size(new Size(132, 28));
			((Control)button12).set_TabIndex(18);
			((Control)button12).set_TabStop(false);
			((Control)button12).set_Tag((object)"ModuleButton");
			((Control)button12).set_Text("Paragon Philter");
			((ButtonBase)button12).set_UseVisualStyleBackColor(false);
			((Control)button12).add_Click((EventHandler)button12_Click);
			((Control)button11).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button11).set_Dock((DockStyle)1);
			((ButtonBase)button11).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button11).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button11).set_FlatStyle((FlatStyle)0);
			((Control)button11).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button11).set_ForeColor(SystemColors.get_Control());
			((Control)button11).set_Location(new Point(0, 228));
			((Control)button11).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button11).set_Name("button11");
			((Control)button11).set_Size(new Size(132, 28));
			((Control)button11).set_TabIndex(17);
			((Control)button11).set_TabStop(false);
			((Control)button11).set_Tag((object)"ModuleButton");
			((Control)button11).set_Text("Skim");
			((ButtonBase)button11).set_UseVisualStyleBackColor(false);
			((Control)button11).add_Click((EventHandler)button11_Click);
			((Control)button10).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button10).set_Dock((DockStyle)1);
			((ButtonBase)button10).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button10).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button10).set_FlatStyle((FlatStyle)0);
			((Control)button10).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button10).set_ForeColor(SystemColors.get_Control());
			((Control)button10).set_Location(new Point(0, 200));
			((Control)button10).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button10).set_Name("button10");
			((Control)button10).set_Size(new Size(132, 28));
			((Control)button10).set_TabIndex(16);
			((Control)button10).set_TabStop(false);
			((Control)button10).set_Tag((object)"ModuleButton");
			((Control)button10).set_Text("Weight");
			((ButtonBase)button10).set_UseVisualStyleBackColor(false);
			((Control)button10).add_Click((EventHandler)button10_Click);
			((Control)button9).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button9).set_Dock((DockStyle)1);
			((ButtonBase)button9).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button9).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button9).set_FlatStyle((FlatStyle)0);
			((Control)button9).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button9).set_ForeColor(SystemColors.get_Control());
			((Control)button9).set_Location(new Point(0, 172));
			((Control)button9).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button9).set_Name("button9");
			((Control)button9).set_Size(new Size(132, 28));
			((Control)button9).set_TabIndex(15);
			((Control)button9).set_TabStop(false);
			((Control)button9).set_Tag((object)"ModuleButton");
			((Control)button9).set_Text("StepUp");
			((ButtonBase)button9).set_UseVisualStyleBackColor(false);
			((Control)button9).add_Click((EventHandler)button9_Click);
			((Control)button8).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button8).set_Dock((DockStyle)1);
			((ButtonBase)button8).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button8).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button8).set_FlatStyle((FlatStyle)0);
			((Control)button8).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button8).set_ForeColor(SystemColors.get_Control());
			((Control)button8).set_Location(new Point(0, 144));
			((Control)button8).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button8).set_Name("button8");
			((Control)button8).set_Size(new Size(132, 28));
			((Control)button8).set_TabIndex(14);
			((Control)button8).set_TabStop(false);
			((Control)button8).set_Tag((object)"ModuleButton");
			((Control)button8).set_Text("Levitation");
			((ButtonBase)button8).set_UseVisualStyleBackColor(false);
			((Control)button8).add_Click((EventHandler)button8_Click);
			((Control)button7).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button7).set_Dock((DockStyle)1);
			((ButtonBase)button7).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button7).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button7).set_FlatStyle((FlatStyle)0);
			((Control)button7).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button7).set_ForeColor(SystemColors.get_Control());
			((Control)button7).set_Location(new Point(0, 116));
			((Control)button7).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button7).set_Name("button7");
			((Control)button7).set_Size(new Size(132, 28));
			((Control)button7).set_TabIndex(10);
			((Control)button7).set_TabStop(false);
			((Control)button7).set_Tag((object)"ModuleButton");
			((Control)button7).set_Text("JumpBoost");
			((ButtonBase)button7).set_UseVisualStyleBackColor(false);
			((Control)button7).add_Click((EventHandler)button7_Click);
			((Control)button6).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button6).set_Dock((DockStyle)1);
			((ButtonBase)button6).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button6).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button6).set_FlatStyle((FlatStyle)0);
			((Control)button6).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button6).set_ForeColor(SystemColors.get_Control());
			((Control)button6).set_Location(new Point(0, 88));
			((Control)button6).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button6).set_Name("button6");
			((Control)button6).set_Size(new Size(132, 28));
			((Control)button6).set_TabIndex(9);
			((Control)button6).set_TabStop(false);
			((Control)button6).set_Tag((object)"ModuleButton");
			((Control)button6).set_Text("Speed");
			((ButtonBase)button6).set_UseVisualStyleBackColor(false);
			((Control)button6).add_Click((EventHandler)button6_Click);
			((Control)button5).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button5).set_Dock((DockStyle)1);
			((ButtonBase)button5).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button5).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button5).set_FlatStyle((FlatStyle)0);
			((Control)button5).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button5).set_ForeColor(SystemColors.get_Control());
			((Control)button5).set_Location(new Point(0, 56));
			((Control)button5).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button5).set_Name("button5");
			((Control)button5).set_Size(new Size(132, 32));
			((Control)button5).set_TabIndex(8);
			((Control)button5).set_TabStop(false);
			((Control)button5).set_Tag((object)"ModuleButton");
			((Control)button5).set_Text("Slowfalling");
			((ButtonBase)button5).set_UseVisualStyleBackColor(false);
			((Control)button5).add_Click((EventHandler)button5_Click);
			((Control)button3).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button3).set_Dock((DockStyle)1);
			((ButtonBase)button3).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button3).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button3).set_FlatStyle((FlatStyle)0);
			((Control)button3).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button3).set_ForeColor(SystemColors.get_Control());
			((Control)button3).set_Location(new Point(0, 28));
			((Control)button3).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button3).set_Name("button3");
			((Control)button3).set_Size(new Size(132, 28));
			((Control)button3).set_TabIndex(6);
			((Control)button3).set_TabStop(false);
			((Control)button3).set_Tag((object)"ModuleButton");
			((Control)button3).set_Text("Slowness");
			((ButtonBase)button3).set_UseVisualStyleBackColor(false);
			((Control)button3).add_Click((EventHandler)button3_Click);
			((Control)button4).set_BackColor(Color.FromArgb(54, 71, 96));
			((Control)button4).set_Dock((DockStyle)1);
			((ButtonBase)button4).get_FlatAppearance().set_BorderColor(Color.FromArgb(33, 33, 33));
			((ButtonBase)button4).get_FlatAppearance().set_BorderSize(0);
			((ButtonBase)button4).set_FlatStyle((FlatStyle)0);
			((Control)button4).set_Font(new Font("Nirmala UI Semilight", 9f));
			((Control)button4).set_ForeColor(SystemColors.get_Control());
			((Control)button4).set_Location(new Point(0, 0));
			((Control)button4).set_Margin(new Padding(3, 4, 3, 4));
			((Control)button4).set_Name("button4");
			((Control)button4).set_Size(new Size(132, 28));
			((Control)button4).set_TabIndex(7);
			((Control)button4).set_TabStop(false);
			((Control)button4).set_Tag((object)"ModuleButton");
			((Control)button4).set_Text("Clear Fake Effects");
			((ButtonBase)button4).set_UseVisualStyleBackColor(false);
			((Control)button4).add_Click((EventHandler)button4_Click);
			((Control)label16).set_Anchor((AnchorStyles)6);
			((Control)label16).set_AutoSize(true);
			((Control)label16).set_Font(new Font("Microsoft Sans Serif", 15.75f, (FontStyle)0, (GraphicsUnit)3, (byte)0));
			((Control)label16).set_ForeColor(Color.FromArgb(255, 224, 192));
			((Control)label16).set_Location(new Point(12, 486));
			((Control)label16).set_Name("label16");
			((Control)label16).set_Size(new Size(54, 25));
			((Control)label16).set_TabIndex(10);
			((Control)label16).set_Tag((object)"ToolTips");
			((Control)label16).set_Text("Test");
			timer4.set_Enabled(true);
			timer4.add_Tick((EventHandler)timer4_Tick);
			((ContainerControl)this).set_AutoScaleDimensions(new SizeF(6f, 13f));
			((ContainerControl)this).set_AutoScaleMode((AutoScaleMode)1);
			((Control)this).set_BackColor(Color.get_White());
			((Form)this).set_ClientSize(new Size(1192, 545));
			((Control)this).get_Controls().Add((Control)(object)label16);
			((Control)this).get_Controls().Add((Control)(object)panel21);
			((Control)this).get_Controls().Add((Control)(object)UpdateLabel);
			((Control)this).get_Controls().Add((Control)(object)val);
			((Control)this).get_Controls().Add((Control)(object)panel18);
			((Control)this).get_Controls().Add((Control)(object)panel16);
			((Control)this).get_Controls().Add((Control)(object)panel14);
			((Control)this).get_Controls().Add((Control)(object)panel12);
			((Control)this).get_Controls().Add((Control)(object)panel10);
			((Control)this).get_Controls().Add((Control)(object)panel8);
			((Control)this).get_Controls().Add((Control)(object)panel6);
			((Control)this).get_Controls().Add((Control)(object)panel1);
			((Control)this).get_Controls().Add((Control)(object)panel3);
			((Control)this).get_Controls().Add((Control)(object)panel2);
			((Control)this).set_DoubleBuffered(true);
			((Form)this).set_FormBorderStyle((FormBorderStyle)0);
			((Form)this).set_Margin(new Padding(3, 4, 3, 4));
			((Control)this).set_Name("Overlay");
			((Form)this).set_ShowIcon(false);
			((Form)this).set_ShowInTaskbar(false);
			((Form)this).set_StartPosition((FormStartPosition)4);
			((Control)this).set_Text("Overlay");
			((Form)this).set_TopMost(true);
			((Form)this).set_TransparencyKey(Color.get_White());
			((Form)this).add_Load((EventHandler)Overlay_Load);
			((Form)this).add_ResizeBegin((EventHandler)Overlay_ResizeBegin);
			((Form)this).add_ResizeEnd((EventHandler)Overlay_ResizeEnd);
			((Control)this).add_Paint(new PaintEventHandler(Overlay_Paint));
			((Control)panel2).ResumeLayout(false);
			((Control)panel2).PerformLayout();
			((Control)TestCategory).ResumeLayout(false);
			((Control)ClonablePanel).ResumeLayout(false);
			((Control)ClonablePanel).PerformLayout();
			((Control)panel3).ResumeLayout(false);
			((Control)panel4).ResumeLayout(false);
			((Control)panel4).PerformLayout();
			((Control)panel1).ResumeLayout(false);
			((Control)panel5).ResumeLayout(false);
			((Control)panel5).PerformLayout();
			((Control)panel6).ResumeLayout(false);
			((Control)panel6).PerformLayout();
			((Control)panel8).ResumeLayout(false);
			((Control)panel8).PerformLayout();
			((Control)panel10).ResumeLayout(false);
			((Control)panel10).PerformLayout();
			((Control)panel12).ResumeLayout(false);
			((Control)panel12).PerformLayout();
			((Control)panel14).ResumeLayout(false);
			((Control)panel14).PerformLayout();
			((Control)panel16).ResumeLayout(false);
			((Control)panel16).PerformLayout();
			((Control)panel18).ResumeLayout(false);
			((Control)panel19).ResumeLayout(false);
			((Control)panel20).ResumeLayout(false);
			((ISupportInitialize)numericUpDown3).EndInit();
			((ISupportInitialize)numericUpDown1).EndInit();
			((ISupportInitialize)numericUpDown2).EndInit();
			((Control)panel21).ResumeLayout(false);
			((Control)panel21).PerformLayout();
			((Control)panel22).ResumeLayout(false);
			((Control)panel23).ResumeLayout(false);
			((Control)panel23).PerformLayout();
			((ISupportInitialize)PotionAmplifier).EndInit();
			((Control)panel24).ResumeLayout(false);
			((Control)panel24).PerformLayout();
			((ISupportInitialize)PotionDiritation).EndInit();
			((Control)this).ResumeLayout(false);
			((Control)this).PerformLayout();
		}
	}
}
