namespace Trero.ClientBase.UIBase
{
	public enum SWEH_dwFlags : uint
	{
		WINEVENT_OUTOFCONTEXT = 0u,
		WINEVENT_SKIPOWNTHREAD = 1u,
		WINEVENT_SKIPOWNPROCESS = 2u,
		WINEVENT_INCONTEXT = 4u
	}
}
