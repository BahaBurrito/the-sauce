using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.VersionBase;

namespace Trero.Modules
{
	internal class HighJump : Module
	{
		public HighJump()
			: base("HighJump", '\a', "Player", "Jump higher")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull && Keymap.GetAsyncKeyState((Keys)32) && Game.onGround)
			{
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.8f);
			}
		}
	}
}
