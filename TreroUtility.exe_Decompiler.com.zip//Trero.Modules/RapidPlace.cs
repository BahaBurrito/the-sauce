using Trero.ClientBase;

namespace Trero.Modules
{
	internal class RapidPlace : Module
	{
		public RapidPlace()
			: base("RapidPlace", '\a', "Player", "Spam place packets when mousedown")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				Game.Placing = 0;
			}
		}
	}
}
