using System;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;

namespace Trero.Modules
{
	internal class Fly : Module
	{
		private int count;

		private bool isBlinking;

		public Fly()
			: base("LifeboatFly", '\a', "Flies", "Basic fly that supports minevile's disabler - Gamerclient28921 (Improved by yaami<3#3731)")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			isBlinking = false;
			Game.position = new Vector3(Game.position.x, Game.position.y + 1f, Game.position.z);
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				float num = 0.4f;
				Game.timer = 20f * num;
				Game.onGround = true;
				Vector3 vec = Base.Vec3();
				float cy = (Game.bodyRots.y + 90f) * ((float)Math.PI / 180f);
				float speed = 1.25f / num;
				if (Keymap.GetAsyncKeyState((Keys)87))
				{
					MoveCharacter(cy, speed, out vec);
				}
				if (count > 7)
				{
					isBlinking = true;
					OverrideBase.CanSendPackets = false;
					count = 0;
				}
				else
				{
					count++;
					isBlinking = false;
					OverrideBase.CanSendPackets = true;
				}
				Game.velocity = vec;
			}
		}

		public void MoveCharacter(float cy, float speed, out Vector3 vec)
		{
			Vector3 position = Game.position;
			position.y -= 0.003f;
			Game.teleport(position);
			Vector3 vector = Base.Vec3();
			vector.z = (float)Math.Sin(cy) * speed;
			vector.x = (float)Math.Cos(cy) * speed;
			vec = vector;
		}

		public override void OnDisable()
		{
			base.OnDisable();
			count = 0;
			if (isBlinking)
			{
				OverrideBase.CanSendPackets = true;
				isBlinking = false;
			}
			Game.timer = 20f;
			Game.velocity = Base.Vec3();
		}
	}
}
