namespace Trero.Modules
{
	internal class LBSH : Module
	{
		public LBSH()
			: base("LBDF", '\a', "Flies", "Useless")
		{
		}

		public override void OnTick()
		{
		}
	}
}
