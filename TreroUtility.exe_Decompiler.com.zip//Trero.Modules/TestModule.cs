using Trero.ClientBase;

namespace Trero.Modules
{
	internal class TestModule : Module
	{
		public TestModule()
			: base("TestModule", '\a', "Other", "Developer test module")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			MCM.freezeBytes(Game.localPlayer + 312, MCM.float2Bytes(Game.bodyRots.x));
		}

		public override void OnDisable()
		{
			base.OnDisable();
			MCM.unfreezeBytes(Game.localPlayer);
		}
	}
}
