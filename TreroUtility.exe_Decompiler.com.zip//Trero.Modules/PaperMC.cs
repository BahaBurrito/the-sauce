using System;
using Trero.ClientBase;

namespace Trero.Modules
{
	internal class PaperMC : Module
	{
		public PaperMC()
			: base("PaperMC", '\a', "Exploits", "Turn everyone into... Paper..?")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			MCM.writeBaseBytes(OverrideBase.entityModel.playerModelAddr + 96, MCM.ceByte2Bytes("B8 CD CC CC 3D 90"));
		}

		public override void OnDisable()
		{
			base.OnDisable();
			MCM.writeBaseBytes(OverrideBase.entityModel.playerModelAddr + 96, MCM.ceByte2Bytes("8B 81 30 01 00 00"));
			Console.WriteLine("c");
		}
	}
}
