using System;
using System.Collections.Generic;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.UIBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Module
	{
		public readonly string category;

		public readonly string name;

		public readonly string desc;

		public bool enabled;

		public char keybind;

		public List<BypassBox> bypasses = new List<BypassBox>();

		protected Module(string name, char keybind, string category, string desc, bool enabled = false)
		{
			this.name = name;
			this.keybind = keybind;
			this.category = category;
			this.enabled = enabled;
			this.desc = desc;
			Keymap.keyEvent = (EventHandler<KeyEvent>)Delegate.Combine(Keymap.keyEvent, new EventHandler<KeyEvent>(OnKeypress));
		}

		public void addBypass(BypassBox v)
		{
			bypasses.Add(v);
		}

		private void OnKeypress(object sender, KeyEvent e)
		{
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Invalid comparison between Unknown and I4
			if (Overlay.handle != null && e.vkey == VKeyCodes.KeyDown && (int)e.key == keybind)
			{
				enabled = !enabled;
				if (enabled)
				{
					OnEnable();
				}
				else
				{
					OnDisable();
				}
			}
		}

		public virtual void OnEnable()
		{
			enabled = true;
			Program.moduleToggled(null, new EventArgs());
		}

		public virtual void OnDisable()
		{
			enabled = false;
			try
			{
				Program.moduleToggled(null, new EventArgs());
			}
			catch
			{
			}
		}

		public virtual void OnTick()
		{
		}
	}
}
