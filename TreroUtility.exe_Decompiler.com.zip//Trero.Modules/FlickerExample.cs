using Trero.ClientBase;

namespace Trero.Modules
{
	internal class FlickerExample : Module
	{
		private int _flicker;

		public FlickerExample()
			: base("FlickerExample", '\a', "Other", "ExampleModule")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				_flicker++;
				if (_flicker == 300)
				{
					_flicker = 0;
				}
			}
		}
	}
}
