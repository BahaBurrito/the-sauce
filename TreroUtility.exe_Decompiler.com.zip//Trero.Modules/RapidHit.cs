using Trero.ClientBase;

namespace Trero.Modules
{
	internal class RapidHit : Module
	{
		public RapidHit()
			: base("RapidHit", '\a', "Combat", "Spam hit packets when mousedown")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				Game.Hitting = 0;
			}
		}
	}
}
