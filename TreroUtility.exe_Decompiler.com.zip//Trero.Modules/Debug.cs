using System;
using System.Runtime.InteropServices;

namespace Trero.Modules
{
	internal class Debug : Module
	{
		public Debug()
			: base("Debug", '\a', "Other", "Developer console", enabled: true)
		{
		}

		[DllImport("kernel32.dll")]
		private static extern IntPtr GetConsoleWindow();

		[DllImport("user32.dll")]
		private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

		public override void OnEnable()
		{
			ShowWindow(GetConsoleWindow(), 5);
			base.OnEnable();
		}

		public override void OnDisable()
		{
			ShowWindow(GetConsoleWindow(), 0);
			base.OnDisable();
		}
	}
}
