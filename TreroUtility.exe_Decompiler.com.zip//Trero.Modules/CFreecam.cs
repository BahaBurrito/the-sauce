using Trero.ClientBase;

namespace Trero.Modules
{
	internal class CFreecam : Module
	{
		private Vector3 savedCoords = Base.Vec3();

		private Vector3 savedVel = Base.Vec3();

		private bool flying;

		public CFreecam()
			: base("Freecam", '\a', "Others", "Freely move around client sidedly")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			OverrideBase.CanSendPackets = false;
			savedCoords = Game.position;
			savedVel = Game.velocity;
			flying = Game.isFlying;
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.teleport(savedCoords);
			Game.velocity = savedVel;
			Game.isFlying = !flying;
			OverrideBase.CanSendPackets = true;
		}

		public override void OnTick()
		{
			base.OnTick();
			Vector3 position = Game.position;
			Vector3 position2 = Game.position;
			position2.x += 0.6f;
			position2.z += 0.6f;
			Game.teleport(new AABB(position, position2));
			Game.isFlying = false;
		}
	}
}
