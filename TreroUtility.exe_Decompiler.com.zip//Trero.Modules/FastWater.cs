using System;
using Trero.ClientBase;

namespace Trero.Modules
{
	internal class FastWater : Module
	{
		public FastWater()
			: base("FastWater", '\a', "Player", "Fly at the speed of light when you touch water")
		{
		}

		public override void OnTick()
		{
			if (Game.isInWater || Game.isInLava)
			{
				Vector3 velocity = Game.velocity;
				float num = (Game.bodyRots.y + 89.9f) * ((float)Math.PI / 180f);
				velocity.z = (float)Math.Sin(num) * 2f;
				velocity.y = 0.01f;
				velocity.x = (float)Math.Cos(num) * 2f;
				Game.velocity = velocity;
			}
		}
	}
}
