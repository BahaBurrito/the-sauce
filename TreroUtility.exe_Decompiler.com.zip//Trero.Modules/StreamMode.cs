using Trero.ClientBase;

namespace Trero.Modules
{
	internal class StreamMode : Module
	{
		private string storedusr = "null";

		public StreamMode()
			: base("StreamMode", '\a', "World", "Hide your username")
		{
			storedusr = Game.username;
		}

		public override void OnEnable()
		{
			base.OnEnable();
			storedusr = Game.username;
			Game.username = "TreroExploiter";
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.username = storedusr;
		}
	}
}
