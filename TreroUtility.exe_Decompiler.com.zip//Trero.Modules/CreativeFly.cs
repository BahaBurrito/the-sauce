using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class CreativeFly : Module
	{
		public CreativeFly()
			: base("CreativeFly", '\a', "Flies", "Fly like your in creative")
		{
			addBypass(new BypassBox(new string[2]
			{
				"IsFlying: True",
				"IsFlying: False"
			}));
		}

		public override void OnTick()
		{
			Game.isFlying = bypasses[0].curIndex == 0;
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.isFlying = false;
		}
	}
}
