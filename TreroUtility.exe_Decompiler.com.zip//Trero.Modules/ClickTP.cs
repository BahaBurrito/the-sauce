using System;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;

namespace Trero.Modules
{
	internal class ClickTP : Module
	{
		public ClickTP()
			: base("ClickTP", '\a', "Exploits", "Right click to teleport to the position your looking at")
		{
			Keymap.keyEvent = (EventHandler<KeyEvent>)Delegate.Combine(Keymap.keyEvent, new EventHandler<KeyEvent>(KeyPress));
		}

		private void KeyPress(object sender, KeyEvent e)
		{
			//IL_0011: Unknown result type (might be due to invalid IL or missing references)
			//IL_0017: Invalid comparison between Unknown and I4
			if (e.vkey == VKeyCodes.KeyDown && enabled && (int)e.key == 2)
			{
				iVector3 selectedBlock = Game.SelectedBlock;
				if (selectedBlock.x != 0 && selectedBlock.y != 0 && selectedBlock.z != 0)
				{
					Game.position = Base.Vec3(selectedBlock.x, selectedBlock.y + 1, selectedBlock.z);
				}
			}
		}
	}
}
