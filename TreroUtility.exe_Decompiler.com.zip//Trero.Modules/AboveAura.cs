using Trero.ClientBase;
using Trero.ClientBase.EntityBase;

namespace Trero.Modules
{
	internal class AboveAura : Module
	{
		private int _flicker;

		public AboveAura()
			: base("AboveAura", '\a', "Exploits", "Teleport above the closest players head")
		{
		}

		public override void OnTick()
		{
			if (Game.isNull)
			{
				return;
			}
			_flicker++;
			if (_flicker != 4)
			{
				return;
			}
			_flicker = 0;
			Actor closestPlayer = Game.getClosestPlayer();
			if (closestPlayer != null)
			{
				Vector3 position = closestPlayer.position;
				if (Game.position.Distance(position) < 6f)
				{
					position.y += 2f;
					Game.position = position;
					Game.velocity = Base.Vec3(0f, -0.01f);
				}
			}
		}
	}
}
