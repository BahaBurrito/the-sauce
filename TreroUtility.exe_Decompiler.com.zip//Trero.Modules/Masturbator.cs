using System;
using Trero.ClientBase;

namespace Trero.Modules
{
	internal class Masturbator : Module
	{
		private static int _flicker;

		private static Random ran = new Random();

		public Masturbator()
			: base("Masturbator", '\a', "World", ";)")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				_flicker++;
				Game.bodyRots = new Vector2(ran.Next(-180, 180), ran.Next(-180, 180));
				if (_flicker == 16)
				{
					_flicker = 0;
					Game.swing();
				}
			}
		}
	}
}
