using Trero.ClientBase;

namespace Trero.Modules
{
	internal class NoLagBack : Module
	{
		public NoLagBack()
			: base("NoLagBack", '\a', "Exploits", "half done")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			OverrideBase.ServerCanTeleportClient = false;
		}

		public override void OnDisable()
		{
			base.OnDisable();
			OverrideBase.ServerCanTeleportClient = true;
		}
	}
}
