using Trero.ClientBase;

namespace Trero.Modules
{
	internal class FixHitbox : Module
	{
		public FixHitbox()
			: base("FixHitbox", '\a', "Others", "Debug module made to repair LP hitboxes")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			Game.teleport(Game.position);
		}
	}
}
