using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class PhaseUp : Module
	{
		public PhaseUp()
			: base("PhaseUp", '\a', "Flies", "Slowly phase upwards")
		{
			addBypass(new BypassBox(new string[3]
			{
				"Default",
				"Fast",
				"Super Fast"
			}));
		}

		public override void OnTick()
		{
			Game.velocity = Base.Vec3();
			Vector3 position = Game.position;
			if (bypasses[0].curIndex == 0)
			{
				position.y += 0.01f;
			}
			if (bypasses[0].curIndex == 1)
			{
				position.y += 0.01f;
			}
			if (bypasses[0].curIndex == 2)
			{
				position.y += 0.1f;
			}
			Game.position = position;
		}
	}
}
