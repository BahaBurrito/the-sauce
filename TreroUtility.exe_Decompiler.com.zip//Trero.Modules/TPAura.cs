using Trero.ClientBase;

namespace Trero.Modules
{
	internal class TPAura : Module
	{
		private int _flicker;

		public TPAura()
			: base("TPAura", '\a', "Exploits", "Teleport around the closest player")
		{
		}

		public override void OnTick()
		{
			if (Game.isNull)
			{
				return;
			}
			_flicker++;
			if (_flicker != 4)
			{
				return;
			}
			_flicker = 0;
			if (!Game.isNull)
			{
				_flicker++;
				if (_flicker == 300)
				{
					_flicker = 0;
					Game.onGround = false;
				}
			}
		}
	}
}
