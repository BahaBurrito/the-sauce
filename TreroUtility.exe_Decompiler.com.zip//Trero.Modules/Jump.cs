using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Jump : Module
	{
		public Jump()
			: base("Jump", '\a', "Movement", "Broken jumper movie reference")
		{
			addBypass(new BypassBox(new string[7]
			{
				"JumpDistance: 1",
				"JumpDistance: 2",
				"JumpDistance: 3",
				"JumpDistance: 4",
				"JumpDistance: 5",
				"JumpDistance: 6",
				"JumpDistance: 7"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			Game.jumpForwards(bypasses[0].curIndex + 1);
			base.OnDisable();
		}
	}
}
