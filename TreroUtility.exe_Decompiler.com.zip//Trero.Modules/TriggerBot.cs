using System.Threading;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;

namespace Trero.Modules
{
	internal class TriggerBot : Module
	{
		public TriggerBot()
			: base("TriggerBot", '\a', "Combat", "Automatically hit any entity your looking at")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull && MCM.isGameFocused() && Game.isLookingAtEntity && Game.position.Distance(Game.getClosestPlayer().position) < 7f)
			{
				new Thread((ThreadStart)delegate
				{
					Mouse.MouseEvent(Mouse.MouseEventFlags.MOUSEEVENTF_LEFTDOWN);
				}).Start();
			}
		}
	}
}
