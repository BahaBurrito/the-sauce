using Trero.ClientBase;

namespace Trero.Modules
{
	internal class Antibot : Module
	{
		public Antibot()
			: base("Antibot", '\a', "Other", "Handles entity list filtering", enabled: true)
		{
		}

		public override void OnEnable()
		{
			Game.CustomDefines.antibot = true;
			Game.CustomDefines.antibotStates = new bool[2]
			{
				true,
				false
			};
			base.OnEnable();
		}

		public override void OnDisable()
		{
			Game.CustomDefines.antibot = false;
			base.OnDisable();
		}
	}
}
