using Trero.ClientBase;

namespace Trero.Modules
{
	internal class FastFall : Module
	{
		public FastFall()
			: base("FastFall", '\a', "Movement", "Fall Faster - Xello!")
		{
		}

		public override void OnEnable()
		{
			MCM.writeBaseBytes(37566992, MCM.ceByte2Bytes("90 90 90 90 90 90 90"));
			base.OnEnable();
		}

		public override void OnDisable()
		{
			MCM.writeBaseBytes(37566992, MCM.ceByte2Bytes("C7 40 1C 00 00 00 00"));
			base.OnDisable();
		}
	}
}
