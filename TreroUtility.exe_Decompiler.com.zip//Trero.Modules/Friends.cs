using System;
using System.Threading;
using Microsoft.VisualBasic;
using Trero.ClientBase;

namespace Trero.Modules
{
	internal class Friends : Module
	{
		public Friends()
			: base("Friends", '\a', "Other", "Friend actions")
		{
		}

		public override void OnEnable()
		{
			new Thread((ThreadStart)delegate
			{
				string a = Interaction.InputBox("Please enter action (remove/add/list)", "Trero (Friends)", "", -1, -1).ToLower();
				if (a == "list")
				{
					foreach (string friend in Game.CustomDefines.friends)
					{
						Console.WriteLine(friend);
					}
				}
				else
				{
					string text = Interaction.InputBox("Please enter player username", "Trero (Friends)", "", -1, -1).ToLower();
					if (a != "remove")
					{
						if (!(a != "add"))
						{
							Game.CustomDefines.friends.Add(text);
						}
					}
					else
					{
						for (int i = 0; i < Game.CustomDefines.friends.Count; i++)
						{
							string text2 = Game.CustomDefines.friends[i];
							if (text == text2)
							{
								Game.CustomDefines.friends.Remove(text2);
							}
						}
					}
				}
			}).Start();
		}
	}
}
