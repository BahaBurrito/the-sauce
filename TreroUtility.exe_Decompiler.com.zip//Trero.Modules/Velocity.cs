using Trero.ClientBase;

namespace Trero.Modules
{
	internal class Velocity : Module
	{
		public Velocity()
			: base("Velocity", '\a', "Player", "Anti-Knockback, stop all knockback.")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			MCM.writeBaseBytes(31388786, MCM.ceByte2Bytes("90 90 90 90 90 90"));
			MCM.writeBaseBytes(31388795, MCM.ceByte2Bytes("90 90 90 90 90 90"));
			MCM.writeBaseBytes(31388804, MCM.ceByte2Bytes("90 90 90 90 90 90"));
		}

		public override void OnDisable()
		{
			base.OnDisable();
			MCM.writeBaseBytes(31388786, MCM.ceByte2Bytes("89 81 F8 04 00 00"));
			MCM.writeBaseBytes(31388795, MCM.ceByte2Bytes("89 81 FC 04 00 00"));
			MCM.writeBaseBytes(31388804, MCM.ceByte2Bytes("89 81 00 05 00 00"));
		}
	}
}
