using Trero.ClientBase;
using Trero.ClientBase.EntityBase;

namespace Trero.Modules
{
	internal class Hitbox : Module
	{
		public Hitbox()
			: base("Hitbox", '\a', "Combat", "Expand every entities hitbox to 7,7")
		{
		}

		public override void OnTick()
		{
			if (Game.isNull)
			{
				return;
			}
			foreach (Actor player in Game.getPlayers())
			{
				player.hitbox = Base.Vec2(7f, 7f);
			}
		}

		public override void OnDisable()
		{
			base.OnDisable();
			foreach (Actor player in Game.getPlayers())
			{
				player.hitbox = Base.Vec2(0.6f, 1.8f);
			}
		}
	}
}
