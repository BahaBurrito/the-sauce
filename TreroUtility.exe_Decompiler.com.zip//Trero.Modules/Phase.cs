using Trero.ClientBase;

namespace Trero.Modules
{
	internal class Phase : Module
	{
		public Phase()
			: base("Phase", '\a', "Exploits", "Move through walls")
		{
		}

		public override void OnTick()
		{
			Vector3 position = Game.position;
			Vector3 position2 = Game.position;
			position2.x += 0.6f;
			position2.z += 0.6f;
			Game.teleport(new AABB(position, position2));
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.teleport(Game.position);
		}
	}
}
