using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class AirJump : Module
	{
		public AirJump()
			: base("AirJump", '\a', "World", "Jump in thin air")
		{
			addBypass(new BypassBox(new string[2]
			{
				"onGround: True",
				"onGround: False"
			}));
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				Game.onGround = bypasses[0].curIndex != 0;
			}
		}
	}
}
