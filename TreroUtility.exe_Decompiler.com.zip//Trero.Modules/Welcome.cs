using System;

namespace Trero.Modules
{
	internal class Welcome : Module
	{
		public Welcome()
			: base("Welcome", '\a', "Other", "Display our discord in the trero debug/developer console")
		{
		}

		public override void OnEnable()
		{
			Console.Clear();
			Console.WriteLine("--- Links ---\r\nTrero: \r\ndiscord.gg/Zr6RDAJp9F\r\n");
		}
	}
}
