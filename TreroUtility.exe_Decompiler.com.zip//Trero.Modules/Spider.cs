using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.VersionBase;

namespace Trero.Modules
{
	internal class Spider : Module
	{
		public Spider()
			: base("Spider", '\a', "Player", "Climb up walls, just like a spider!")
		{
		}

		public override void OnTick()
		{
			float num = 0.4f;
			if (Game.touchingObject == 1)
			{
				if (Keymap.GetAsyncKeyState((Keys)32))
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, num);
				}
				else
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0f - num);
				}
			}
		}
	}
}
