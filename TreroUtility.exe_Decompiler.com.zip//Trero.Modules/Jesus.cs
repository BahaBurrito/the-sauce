using Trero.ClientBase;
using Trero.ClientBase.VersionBase;

namespace Trero.Modules
{
	internal class Jesus : Module
	{
		public Jesus()
			: base("Jesus", '\a', "Player", "Walk on water like jesus")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull && (Game.isInWater || Game.isInLava))
			{
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.01f);
				Game.onGround = true;
			}
		}
	}
}
