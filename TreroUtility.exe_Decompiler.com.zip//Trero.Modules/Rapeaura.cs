using Trero.ClientBase;
using Trero.ClientBase.EntityBase;
using Trero.ClientBase.KeyBase;

namespace Trero.Modules
{
	internal class Rapeaura : Module
	{
		public Rapeaura()
			: base("Rapeaura", '\a', "Combat", "Sexaura + Killaura")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				Actor closestPlayer = Game.getClosestPlayer();
				if (Game.position.Distance(closestPlayer.position) < 6f)
				{
					Game.SexActor(closestPlayer);
				}
				if (Game.isLookingAtEntity && MCM.isGameFocused())
				{
					Mouse.MouseEvent(Mouse.MouseEventFlags.MOUSEEVENTF_LEFTDOWN);
				}
			}
		}
	}
}
