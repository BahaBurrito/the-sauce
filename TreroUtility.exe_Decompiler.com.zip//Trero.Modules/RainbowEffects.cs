using System;
using Trero.ClientBase;

namespace Trero.Modules
{
	internal class RainbowEffects : Module
	{
		public Random ran = new Random();

		public RainbowEffects()
			: base("RainbowEffects", '\a', "Visual", "Client sided rainbow potion effects")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
		}

		public override void OnTick()
		{
			iRGB effectsColor = Game.effectsColor;
			effectsColor.R = (byte)ran.Next(0, 255);
			effectsColor.G = (byte)ran.Next(0, 255);
			effectsColor.B = (byte)ran.Next(0, 255);
			Game.effectsColor = effectsColor;
			base.OnTick();
		}

		public override void OnDisable()
		{
			Game.effectsColor = new iRGB(0, 0, 0, 0);
			base.OnDisable();
		}
	}
}
