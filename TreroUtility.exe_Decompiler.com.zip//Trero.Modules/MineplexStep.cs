using Trero.ClientBase;
using Trero.ClientBase.VersionBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class MineplexStep : Module
	{
		public MineplexStep()
			: base("MineplexStep", '\a', "Player", "Step made for mineplex and other servers that block it")
		{
			addBypass(new BypassBox(new string[4]
			{
				"Default",
				"Fast",
				"Super Slow",
				"Slow"
			}));
		}

		public override void OnTick()
		{
			float value = 0.4f;
			if (Game.walkingIntoBlock == 1)
			{
				switch (bypasses[0].curIndex)
				{
				case 0:
					value = 0.4f;
					break;
				case 1:
					value = 0.6f;
					break;
				case 2:
					value = 0.1f;
					break;
				case 3:
					value = 0.2f;
					break;
				}
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, value);
			}
		}
	}
}
