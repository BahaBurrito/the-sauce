using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Disabler : Module
	{
		private static int _flicker;

		public Disabler()
			: base("Disabler", '\a', "World", "Disabler for nethergames and minevile")
		{
			addBypass(new BypassBox(new string[3]
			{
				"Speed: 0.5f",
				"Speed: 0.3f",
				"Speed: 0.7f"
			}));
			addBypass(new BypassBox(new string[3]
			{
				"DownFlip: 0.1f",
				"DownFlip: 0.05f",
				"DownFlip: 0.2f"
			}));
			addBypass(new BypassBox(new string[3]
			{
				"UpFlip: 0.3f",
				"UpFlip: 0.2f",
				"UpFlip: 0.4f"
			}));
			addBypass(new BypassBox(new string[3]
			{
				"Flicker: 5",
				"Flicker: 10",
				"Flicker: 15"
			}));
			addBypass(new BypassBox(new string[3]
			{
				"VClip: 0.36f",
				"VClip: 0.46f",
				"VClip: 0.26f"
			}));
			addBypass(new BypassBox(new string[5]
			{
				"Timer: 20f",
				"Timer: 15f",
				"Timer: 18f",
				"Timer: 22f",
				"Timer: 28f"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			switch (bypasses[5].curIndex)
			{
			case 1:
				Game.timer = 15f;
				break;
			case 2:
				Game.timer = 18f;
				break;
			case 3:
				Game.timer = 22f;
				break;
			case 4:
				Game.timer = 28f;
				break;
			}
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.timer = 20f;
		}

		public override void OnTick()
		{
			if (Game.isNull)
			{
				return;
			}
			float num = 0.5f;
			switch (bypasses[0].curIndex)
			{
			case 1:
				num = 0.3f;
				break;
			case 2:
				num = 0.7f;
				break;
			}
			float num2 = 0.1f;
			switch (bypasses[1].curIndex)
			{
			case 1:
				num2 = 0.05f;
				break;
			case 2:
				num2 = 0.2f;
				break;
			}
			float y = 0.3f;
			switch (bypasses[2].curIndex)
			{
			case 1:
				y = 0.2f;
				break;
			case 2:
				y = 0.4f;
				break;
			}
			int num3 = 5;
			switch (bypasses[3].curIndex)
			{
			case 1:
				num3 = 10;
				break;
			case 2:
				num3 = 15;
				break;
			}
			float y2 = 0.36f;
			switch (bypasses[4].curIndex)
			{
			case 1:
				y2 = 0.26f;
				break;
			case 2:
				y2 = 0.46f;
				break;
			}
			bool flag = true;
			if (Game.velocity.x > num || Game.velocity.x < 0f - num || Game.velocity.z > num || Game.velocity.z < 0f - num)
			{
				flag = false;
				Game.vflip(0f - num2);
			}
			if (Game.touchingObject == 1 && !flag)
			{
				Game.vflip(y);
			}
			_flicker++;
			if (_flicker > num3)
			{
				_flicker = 0;
				if (!Game.onGround2 && !flag)
				{
					Game.vclip(y2);
				}
			}
		}
	}
}
