namespace Trero.Modules
{
	internal class CScaffold : Module
	{
		private float savedY;

		public CScaffold()
			: base("CScaffold", '\a', "World", "Place blocks under you automatically (C)")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
		}

		public override void OnDisable()
		{
			base.OnDisable();
		}

		public override void OnTick()
		{
			base.OnTick();
		}
	}
}
