using System;
using System.Drawing;
using System.Windows.Forms;
using Trero.ClientBase.UIBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class ArrayList : Module
	{
		private Font df = new Font("Arial", 24f, (FontStyle)0);

		private Brush brush1 = (Brush)new SolidBrush(Color.FromArgb(255, 0, 103, 255));

		private Brush brush2 = (Brush)new SolidBrush(Color.FromArgb(255, 54, 71, 96));

		private Brush stringColour = (Brush)new SolidBrush(Color.FromArgb(200, 200, 200));

		public ArrayList()
			: base("ArrayList", '\a', "Visual", "Display a list of modules on the side of your screen")
		{
			//IL_000c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0016: Expected O, but got Unknown
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Expected O, but got Unknown
			//IL_003f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Expected O, but got Unknown
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0063: Unknown result type (might be due to invalid IL or missing references)
			//IL_006d: Expected O, but got Unknown
			addBypass(new BypassBox(new string[3]
			{
				"Theme: Trero",
				"Theme: FontOnly",
				"Theme: Floating"
			}));
			addBypass(new BypassBox(new string[4]
			{
				"Size: 24",
				"Size: 32",
				"Size: 12",
				"Size: 17"
			}));
			addBypass(new BypassBox(new string[2]
			{
				"ShowKeybind: True",
				"ShowKeybind: False"
			}));
			addBypass(new BypassBox(new string[3]
			{
				"Font: Arial",
				"Font: GenericSansSerif",
				"Font: Impact"
			}));
			addBypass(new BypassBox(new string[6]
			{
				"Sorting: Z-A",
				"Font: A-Z",
				"Font: S-B",
				"Font: B-S",
				"Font: GDI S-B",
				"Font: GDI B-S"
			}));
			bypasses[2].curIndex = 1;
			bypasses[4].curIndex = 5;
		}

		public override void OnEnable()
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Expected O, but got Unknown
			base.OnEnable();
			((Control)Overlay.handle).add_Paint(new PaintEventHandler(renderArrayList));
		}

		public override void OnDisable()
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Expected O, but got Unknown
			base.OnDisable();
			((Control)Overlay.handle).remove_Paint(new PaintEventHandler(renderArrayList));
		}

		private void renderArrayList(object sender, PaintEventArgs e)
		{
			//IL_0099: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a3: Expected O, but got Unknown
			//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b7: Expected O, but got Unknown
			//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00cb: Expected O, but got Unknown
			//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
			//IL_00df: Expected O, but got Unknown
			//IL_027d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0282: Unknown result type (might be due to invalid IL or missing references)
			//IL_041b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0420: Unknown result type (might be due to invalid IL or missing references)
			//IL_04bf: Unknown result type (might be due to invalid IL or missing references)
			//IL_04c4: Unknown result type (might be due to invalid IL or missing references)
			string text = "Arial";
			if (bypasses[3].curIndex == 0)
			{
				text = "Arial";
			}
			if (bypasses[3].curIndex == 1)
			{
				text = "GenericSansSerif";
			}
			if (bypasses[3].curIndex == 2)
			{
				text = "Impact";
			}
			switch (bypasses[1].curIndex)
			{
			case 0:
				df = new Font(text, 24f, (FontStyle)0);
				break;
			case 1:
				df = new Font(text, 32f, (FontStyle)0);
				break;
			case 2:
				df = new Font(text, 12f, (FontStyle)0);
				break;
			case 3:
				df = new Font(text, 17f, (FontStyle)0);
				break;
			}
			if (!enabled)
			{
				return;
			}
			int num = 0;
			switch (bypasses[4].curIndex)
			{
			case 1:
				Program.Modules.Sort((Module c1, Module c2) => string.Compare(c1.name, c2.name, StringComparison.Ordinal));
				break;
			case 2:
				Program.Modules.Sort((Module c1, Module c2) => c1.name.Length.CompareTo(c2.name.Length));
				break;
			case 3:
				Program.Modules.Sort((Module c1, Module c2) => c2.name.Length.CompareTo(c1.name.Length));
				break;
			case 4:
				Program.Modules.Sort(delegate(Module c1, Module c2)
				{
					//IL_001c: Unknown result type (might be due to invalid IL or missing references)
					//IL_0021: Unknown result type (might be due to invalid IL or missing references)
					//IL_0048: Unknown result type (might be due to invalid IL or missing references)
					//IL_004d: Unknown result type (might be due to invalid IL or missing references)
					SizeF val4 = e.get_Graphics().MeasureString(c1.name, df);
					float width = ((SizeF)(ref val4)).get_Width();
					val4 = e.get_Graphics().MeasureString(c2.name, df);
					return width.CompareTo(((SizeF)(ref val4)).get_Width());
				});
				break;
			case 5:
				Program.Modules.Sort(delegate(Module c1, Module c2)
				{
					//IL_001c: Unknown result type (might be due to invalid IL or missing references)
					//IL_0021: Unknown result type (might be due to invalid IL or missing references)
					//IL_0048: Unknown result type (might be due to invalid IL or missing references)
					//IL_004d: Unknown result type (might be due to invalid IL or missing references)
					SizeF val5 = e.get_Graphics().MeasureString(c2.name, df);
					float width2 = ((SizeF)(ref val5)).get_Width();
					val5 = e.get_Graphics().MeasureString(c1.name, df);
					return width2.CompareTo(((SizeF)(ref val5)).get_Width());
				});
				break;
			}
			foreach (Module module in Program.Modules)
			{
				if (!module.enabled)
				{
					continue;
				}
				switch (bypasses[0].curIndex)
				{
				case 0:
				{
					string text4 = module.name;
					if (module.keybind != '\a' && bypasses[2].curIndex == 0)
					{
						text4 = module.name + $" [{module.keybind}]";
					}
					SizeF val3 = e.get_Graphics().MeasureString(text4, df);
					e.get_Graphics().FillRectangle(brush2, (float)((Control)Overlay.handle).get_Width() - ((SizeF)(ref val3)).get_Width() - (5f + df.get_Size() / 4f), ((SizeF)(ref val3)).get_Height() * (float)num, ((SizeF)(ref val3)).get_Width() + (5f + df.get_Size() / 4f), df.get_Size() * 1.66f);
					e.get_Graphics().FillRectangle(brush1, (float)(((Control)Overlay.handle).get_Width() - 5) - df.get_Size() / 4f, ((SizeF)(ref val3)).get_Height() * (float)num, 5f + df.get_Size() / 4f, df.get_Size() * 1.66f);
					e.get_Graphics().DrawString(text4, df, stringColour, (float)((Control)Overlay.handle).get_Width() - ((SizeF)(ref val3)).get_Width() - (5f + df.get_Size() / 4f), ((SizeF)(ref val3)).get_Height() * (float)num);
					break;
				}
				case 1:
				{
					string text3 = module.name;
					if (module.keybind != '\a' && bypasses[2].curIndex == 0)
					{
						text3 = module.name + $" [{module.keybind}]";
					}
					SizeF val2 = e.get_Graphics().MeasureString(text3, df);
					e.get_Graphics().DrawString(text3, df, stringColour, (float)((Control)Overlay.handle).get_Width() - ((SizeF)(ref val2)).get_Width(), ((SizeF)(ref val2)).get_Height() * (float)num);
					break;
				}
				case 2:
				{
					string text2 = module.name;
					if (module.keybind != '\a' && bypasses[2].curIndex == 0)
					{
						text2 = module.name + $" [{module.keybind}]";
					}
					SizeF val = e.get_Graphics().MeasureString(text2, df);
					e.get_Graphics().FillRectangle(brush1, (float)(((Control)Overlay.handle).get_Width() - 5) - df.get_Size() / 4f, ((SizeF)(ref val)).get_Height() * (float)num, 5f + df.get_Size() / 4f, df.get_Size() * 1.66f);
					e.get_Graphics().DrawString(text2, df, stringColour, (float)((Control)Overlay.handle).get_Width() - ((SizeF)(ref val)).get_Width() - (5f + df.get_Size() / 4f), ((SizeF)(ref val)).get_Height() * (float)num);
					break;
				}
				}
				num++;
			}
		}
	}
}
