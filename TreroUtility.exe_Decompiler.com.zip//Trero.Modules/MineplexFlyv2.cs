namespace Trero.Modules
{
	internal class MineplexFlyv2 : Module
	{
		public MineplexFlyv2()
			: base("BhopFlight", '\a', "Flies", "MineplexFlight version 2")
		{
		}

		public override void OnEnable()
		{
			foreach (Module module in Program.Modules)
			{
				if (module.name == "MineplexFly" || module.name == "Bhop")
				{
					module.OnEnable();
				}
			}
			base.OnEnable();
		}

		public override void OnDisable()
		{
			foreach (Module module in Program.Modules)
			{
				if (module.name == "MineplexFly" || module.name == "Bhop")
				{
					module.OnDisable();
				}
			}
			base.OnDisable();
		}
	}
}
