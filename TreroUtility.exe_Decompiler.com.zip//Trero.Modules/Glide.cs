using Trero.ClientBase;
using Trero.ClientBase.VersionBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Glide : Module
	{
		public Glide()
			: base("Glide", '\a', "Player", "Glide down like a bird")
		{
			addBypass(new BypassBox(new string[3]
			{
				"Trero",
				"Horion",
				"None"
			}));
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				if (bypasses[0].curIndex == 0)
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, -0.01f);
				}
				if (bypasses[0].curIndex == 1)
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, -0.1f);
				}
				if (bypasses[0].curIndex == 2)
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0f);
				}
			}
		}
	}
}
