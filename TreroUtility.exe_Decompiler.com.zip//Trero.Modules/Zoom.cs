using System;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Zoom : Module
	{
		public Zoom()
			: base("Zoom", 'C', "Visual", "Zoom in when pressing C just like optifine!")
		{
			addBypass(new BypassBox(new string[2]
			{
				"Minus 0.8",
				"Minus 1"
			}));
			Keymap.keyEvent = (EventHandler<KeyEvent>)Delegate.Combine(Keymap.keyEvent, new EventHandler<KeyEvent>(KeyvE));
		}

		private void KeyvE(object sender, KeyEvent e)
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			if (e.vkey == VKeyCodes.KeyUp && (ushort)e.key == keybind)
			{
				OnDisable();
			}
		}

		public override void OnEnable()
		{
			if (bypasses[0].curIndex == 0)
			{
				Game.setFieldOfView(0.2f);
			}
			if (bypasses[0].curIndex == 1)
			{
				Game.setFieldOfView(0f);
			}
			base.OnEnable();
		}

		public override void OnDisable()
		{
			Game.resetFieldOfView();
			base.OnDisable();
		}
	}
}
