using System;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.VersionBase;

namespace Trero.Modules
{
	internal class InventoryMove : Module
	{
		private const float Speed = 0.25f;

		public InventoryMove()
			: base("InventoryMove", '\a', "Player", "Move while in your inventory")
		{
		}

		public override void OnTick()
		{
			if (!Game.inInventory || Game.isNull)
			{
				return;
			}
			float num = Game.bodyRots.y;
			if (Keymap.GetAsyncKeyState((Keys)87))
			{
				if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
				{
					num += 90f;
				}
				if (Keymap.GetAsyncKeyState((Keys)65))
				{
					num += 45f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)68))
				{
					num += 135f;
				}
			}
			else if (Keymap.GetAsyncKeyState((Keys)83))
			{
				if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
				{
					num -= 90f;
				}
				if (Keymap.GetAsyncKeyState((Keys)65))
				{
					num -= 45f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)68))
				{
					num -= 135f;
				}
			}
			else if (!Keymap.GetAsyncKeyState((Keys)87) && !Keymap.GetAsyncKeyState((Keys)83) && !Keymap.GetAsyncKeyState((Keys)65) && Keymap.GetAsyncKeyState((Keys)68))
			{
				num += 180f;
			}
			if (Keymap.GetAsyncKeyState((Keys)87) | Keymap.GetAsyncKeyState((Keys)65) | Keymap.GetAsyncKeyState((Keys)83) | Keymap.GetAsyncKeyState((Keys)68))
			{
				float num2 = num * ((float)Math.PI / 180f);
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity"), (float)Math.Cos(num2) * 0.25f);
				if (Game.touchingObject == 257 && Keymap.GetAsyncKeyState((Keys)32))
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.3f);
				}
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 8, (float)Math.Sin(num2) * 0.25f);
			}
		}
	}
}
