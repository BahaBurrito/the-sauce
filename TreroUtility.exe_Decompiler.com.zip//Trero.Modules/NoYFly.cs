using System;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;

namespace Trero.Modules
{
	internal class NoYFly : Module
	{
		public NoYFly()
			: base("NoYFly", '\a', "Flies", "Fast fly without Y forwarding")
		{
		}

		public override void OnTick()
		{
			Game.onGround = true;
			Game.velocity = Base.Vec3();
			Vector3 velocity = Base.Vec3();
			float num = (Game.bodyRots.y + 89.9f) * ((float)Math.PI / 180f);
			if (Keymap.GetAsyncKeyState('W'))
			{
				velocity.z = (float)Math.Sin(num) * (8f / 9f);
			}
			if (Keymap.GetAsyncKeyState('W'))
			{
				velocity.x = (float)Math.Cos(num) * (8f / 9f);
			}
			Game.velocity = velocity;
		}
	}
}
