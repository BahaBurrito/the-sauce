using Trero.ClientBase;

namespace Trero.Modules
{
	internal class HiveAntibot : Module
	{
		public HiveAntibot()
			: base("HiveAntibot", '\a', "Other", "Antibot made for hive")
		{
		}

		public override void OnEnable()
		{
			Game.CustomDefines.antibot = true;
			Game.CustomDefines.antibotStates = new bool[2]
			{
				false,
				true
			};
			base.OnEnable();
		}

		public override void OnDisable()
		{
			Game.CustomDefines.antibot = false;
			base.OnDisable();
		}
	}
}
