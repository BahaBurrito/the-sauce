using System.Collections.Generic;
using Trero.ClientBase;

namespace Trero.Modules
{
	internal class Blink : Module
	{
		private List<Vector3> posList = new List<Vector3>();

		private Vector3 firstPos = Base.Vec3();

		public Blink()
			: base("Blink", '\a', "Exploits", "Stops sending packets then sends them all at once")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			OverrideBase.CanSendPackets = false;
			firstPos = Game.position;
			posList.Clear();
		}

		public override void OnTick()
		{
			posList.Add(Game.position);
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.teleport(firstPos);
			OverrideBase.CanSendPackets = true;
			Game.timer = 60f;
			for (int i = 0; i < 64; i++)
			{
				foreach (Vector3 pos in posList)
				{
					_ = pos;
					Game.teleport(posList[posList.Count - 1]);
				}
			}
			Game.timer = 20f;
		}
	}
}
