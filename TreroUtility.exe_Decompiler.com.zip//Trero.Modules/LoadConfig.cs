using System;
using System.IO;
using System.Web.Script.Serialization;
using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class LoadConfig : Module
	{
		public LoadConfig()
			: base("LoadConfig", '\a', "Other", "Load the current config.json file if it exists")
		{
		}

		public override void OnEnable()
		{
			//IL_0023: Unknown result type (might be due to invalid IL or missing references)
			Console.WriteLine("Checking for config...");
			if (File.Exists("config.json"))
			{
				Console.WriteLine("Found config!");
				ConfigIO configIO = new JavaScriptSerializer().Deserialize<ConfigIO>(File.ReadAllText("config.json"));
				foreach (Module module in Program.Modules)
				{
					int num = 0;
					foreach (string moduleName in configIO.moduleNames)
					{
						if (module.name == moduleName)
						{
							module.enabled = configIO.enableStates[num];
							int num2 = 0;
							foreach (BypassBox bypass in module.bypasses)
							{
								_ = bypass;
								module.bypasses[num2].curIndex = configIO.moduleBypasses[num][num2];
								num2++;
							}
							module.keybind = configIO.moduleKeybinds[num];
						}
						num++;
					}
				}
			}
			else
			{
				Console.WriteLine("No config found, ignoring...");
			}
		}
	}
}
