using System.Diagnostics;

namespace Trero.Modules
{
	internal class KillGame : Module
	{
		public KillGame()
			: base("KillGame", '\a', "Other", "Kill minecrafts process")
		{
		}

		public override void OnEnable()
		{
			Process.GetProcessesByName("ApplicationFrameHost")[0].Kill();
			Process.GetProcessesByName("Minecraft.Windows")[0].Kill();
			Program.quit = true;
		}
	}
}
