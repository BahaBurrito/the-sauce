using Trero.ClientBase;

namespace Trero.Modules
{
	internal class NoWater : Module
	{
		public NoWater()
			: base("NoWater", '\a', "Exploits", "This Module will make it so you don't slow down in water - Gamerclient28921!")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			MCM.writeBaseBytes(31430736, MCM.ceByte2Bytes("90 90 90 90 90 90"));
		}

		public override void OnDisable()
		{
			base.OnDisable();
			MCM.writeBaseBytes(31430736, MCM.ceByte2Bytes("88 86 5D 02 00 00"));
		}
	}
}
