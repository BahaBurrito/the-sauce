using Trero.ClientBase;

namespace Trero.Modules
{
	internal class AntiImmoblie : Module
	{
		public AntiImmoblie()
			: base("AntiImmoblie", '\a', "Exploits", "Stop the server from freezing you in place!")
		{
		}

		public override void OnEnable()
		{
			MCM.writeBaseBytes(18788848, MCM.ceByte2Bytes("90 90"));
			base.OnEnable();
		}

		public override void OnDisable()
		{
			MCM.writeBaseBytes(18788848, MCM.ceByte2Bytes("75 16"));
			base.OnDisable();
		}
	}
}
