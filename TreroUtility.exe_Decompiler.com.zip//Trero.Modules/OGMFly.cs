using System;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;

namespace Trero.Modules
{
	internal class OGMFly : Module
	{
		public OGMFly()
			: base("OGMFly", '\a', "Flies", "Old version of mineplex fly")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				float num = 0.7f;
				float num2 = (Game.bodyRots.y + 90f) * ((float)Math.PI / 180f);
				Vector3 velocity = Base.Vec3();
				velocity.x = (float)Math.Cos(num2) * num;
				velocity.y = 0.075f * num;
				if (Keymap.GetAsyncKeyState((Keys)160) || Keymap.GetAsyncKeyState((Keys)161))
				{
					velocity.y = 0f - 0.05f * num;
				}
				velocity.z = (float)Math.Sin(num2) * num;
				Game.velocity = velocity;
			}
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.velocity = Base.Vec3();
		}
	}
}
