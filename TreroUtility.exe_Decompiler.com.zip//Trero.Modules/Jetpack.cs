using System;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Jetpack : Module
	{
		public Jetpack()
			: base("Jetpack", '\a', "Flies", "Fly forwards a {x} speed")
		{
			addBypass(new BypassBox(new string[4]
			{
				"Default",
				"Fast",
				"Hyper speed",
				"Slow"
			}));
			Keymap.keyEvent = (EventHandler<KeyEvent>)Delegate.Combine(Keymap.keyEvent, new EventHandler<KeyEvent>(KeyvE));
		}

		private void KeyvE(object sender, KeyEvent e)
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			if (e.vkey == VKeyCodes.KeyUp && (ushort)e.key == keybind)
			{
				OnDisable();
			}
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				Vector3 velocity = Base.Vec3();
				Vector3 lVector = Game.lVector;
				float num = 0.8f;
				if (bypasses[0].curIndex == 0)
				{
					num = 0.8f;
				}
				if (bypasses[0].curIndex == 1)
				{
					num = 1.2f;
				}
				if (bypasses[0].curIndex == 2)
				{
					num = 12f;
				}
				if (bypasses[0].curIndex == 3)
				{
					num = 0.4f;
				}
				velocity.x = num * lVector.x;
				velocity.y = num * (0f - lVector.y);
				velocity.z = num * lVector.z;
				Game.velocity = velocity;
			}
		}
	}
}
