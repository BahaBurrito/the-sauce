using System;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;

namespace Trero.Modules
{
	internal class MineplexFly : Module
	{
		private int count;

		private bool isBlinking;

		public MineplexFly()
			: base("MineplexFly", '\a', "Flies", "Fly designed for mineplex")
		{
		}

		public override void OnEnable()
		{
			base.OnEnable();
			isBlinking = false;
			Game.position = new Vector3(Game.position.x, Game.position.y + 0.5f, Game.position.z);
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				float num = 0.4f;
				Game.timer = 20f * num;
				Game.onGround = true;
				Vector3 vec = Base.Vec3();
				float num2 = (Game.bodyRots.y + 90f) * ((float)Math.PI / 180f);
				float speed = 1.25f / num;
				if (Keymap.GetAsyncKeyState((Keys)87))
				{
					MoveCharacter(num2, speed, out vec);
				}
				if (Keymap.GetAsyncKeyState((Keys)65))
				{
					MoveCharacter(num2 + 55f, speed, out vec);
				}
				if (Keymap.GetAsyncKeyState((Keys)83))
				{
					MoveCharacter(num2 - 110f, speed, out vec);
				}
				if (Keymap.GetAsyncKeyState((Keys)68))
				{
					MoveCharacter(num2 - 55f, speed, out vec);
				}
				if (Keymap.GetAsyncKeyState((Keys)32))
				{
					Game.vclip(0.25f);
				}
				if (Keymap.GetAsyncKeyState((Keys)160) || Keymap.GetAsyncKeyState((Keys)161))
				{
					Game.vclip(-0.25f);
				}
				if (count > 7)
				{
					isBlinking = true;
					count = 0;
				}
				else
				{
					count++;
					isBlinking = false;
				}
				Game.velocity = vec;
			}
		}

		public void MoveCharacter(float cy, float speed, out Vector3 vec)
		{
			Vector3 vector = Base.Vec3(0f, -0.001f);
			vector.z = (float)Math.Sin(cy) * speed;
			vector.x = (float)Math.Cos(cy) * speed;
			vec = vector;
		}

		public override void OnDisable()
		{
			base.OnDisable();
			count = 0;
			if (isBlinking)
			{
				isBlinking = false;
			}
			Game.timer = 20f;
			Game.velocity = Base.Vec3();
		}
	}
}
