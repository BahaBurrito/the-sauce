using Trero.ClientBase;

namespace Trero.Modules
{
	internal class ReverseStep : Module
	{
		public ReverseStep()
			: base("ReverseStep", '\a', "Movement", "Like step but downwards - Xello!")
		{
		}

		public override void OnTick()
		{
			if (Game.onGround && Game.velocity.y < 0f && !(Game.velocity.y < -1f))
			{
				Vector3 velocity = Game.velocity;
				velocity.y = -1f;
				Game.velocity = velocity;
			}
		}
	}
}
