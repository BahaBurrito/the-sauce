using Trero.ClientBase;

namespace Trero.Modules
{
	internal class AirStuck : Module
	{
		public AirStuck()
			: base("AirStuck", '\a', "Player", "Stay frozen in the one spot")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				Game.velocity = Base.Vec3();
			}
		}
	}
}
