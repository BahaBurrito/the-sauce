using System.Collections.Generic;
using Trero.ClientBase;
using Trero.ClientBase.EntityBase;
using Trero.ClientBase.KeyBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Killaura : Module
	{
		public Killaura()
			: base("Killaura", '\a', "Combat", "Attack entities around you automatically")
		{
			addBypass(new BypassBox(new string[2]
			{
				"Mobaura: False",
				"Mobaura: True"
			}));
		}

		public override void OnTick()
		{
			List<Actor> list = Game.getPlayers();
			if (bypasses[0].curIndex == 1)
			{
				list = Game.getEntites();
			}
			foreach (Actor item in list)
			{
				if (Game.position.Distance(item.position) < 6f)
				{
					item.hitbox = Base.Vec2(7f, 7f);
				}
				else
				{
					item.hitbox = Base.Vec2(0.6f, 1.8f);
				}
			}
			if (Game.isLookingAtEntity && MCM.isGameFocused())
			{
				Mouse.MouseEvent(Mouse.MouseEventFlags.MOUSEEVENTF_LEFTDOWN);
			}
		}
	}
}
