using Trero.ClientBase;
using Trero.ClientBase.VersionBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class LongJump : Module
	{
		public LongJump()
			: base("LongJump", '\a', "Player", "Jump longer distances")
		{
			addBypass(new BypassBox(new string[3]
			{
				"Hive",
				"Large",
				"Small"
			}));
		}

		public override void OnEnable()
		{
			switch (bypasses[0].curIndex)
			{
			case 0:
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.5f);
				break;
			case 1:
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.7f);
				break;
			case 2:
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.3f);
				break;
			}
			base.OnEnable();
		}

		public override void OnTick()
		{
			Vector3 velocity = Game.velocity;
			if (velocity.y > 0f && !Game.onGround)
			{
				velocity.x *= 1.1f;
				velocity.y *= 1.06f;
				velocity.z *= 1.1f;
			}
			Game.velocity = velocity;
		}
	}
}
