using System;
using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class AutoWalk : Module
	{
		public AutoWalk()
			: base("AutoWalk", '\a', "Player", "Automatically walk forwards")
		{
			addBypass(new BypassBox(new string[3]
			{
				"Normal",
				"Fast",
				"Slow"
			}));
		}

		public override void OnTick()
		{
			Vector3 velocity = Game.velocity;
			float num = (Game.bodyRots.y + 89.9f) * ((float)Math.PI / 180f);
			int num2 = 4;
			if (bypasses[0].curIndex == 1)
			{
				num2 = 6;
			}
			if (bypasses[0].curIndex == 2)
			{
				num2 = 2;
			}
			velocity.z = (float)Math.Sin(num) * ((float)num2 / 9f);
			velocity.x = (float)Math.Cos(num) * ((float)num2 / 9f);
			Game.velocity = velocity;
		}
	}
}
