using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class NoPacket : Module
	{
		private int a;

		private bool packets;

		public NoPacket()
			: base("NoPacket", '\a', "World", "Stop sending packets")
		{
			addBypass(new BypassBox(new string[6]
			{
				"Delay: UntilDisabled",
				"Delay: 5tps",
				"Delay: 10tps",
				"Delay: 15tps",
				"Delay: 20tps",
				"Delay: 25tps"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			OverrideBase.CanSendPackets = false;
			packets = false;
		}

		public override void OnTick()
		{
			switch (bypasses[0].curIndex)
			{
			case 1:
				if (a == 5)
				{
					packets = !packets;
					OverrideBase.CanSendPackets = packets;
					a = 0;
				}
				break;
			case 2:
				if (a == 10)
				{
					packets = !packets;
					OverrideBase.CanSendPackets = packets;
					a = 0;
				}
				break;
			case 3:
				if (a == 15)
				{
					packets = !packets;
					OverrideBase.CanSendPackets = packets;
					a = 0;
				}
				break;
			case 4:
				if (a == 20)
				{
					packets = !packets;
					OverrideBase.CanSendPackets = packets;
					a = 0;
				}
				break;
			case 5:
				if (a == 25)
				{
					packets = !packets;
					OverrideBase.CanSendPackets = packets;
					a = 0;
				}
				break;
			}
			a++;
		}

		public override void OnDisable()
		{
			base.OnDisable();
			OverrideBase.CanSendPackets = true;
			packets = true;
		}
	}
}
