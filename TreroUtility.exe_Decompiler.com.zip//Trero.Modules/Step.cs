using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Step : Module
	{
		public Step()
			: base("Step", '\a', "Player", "Step up full blocks just like its a slab")
		{
			addBypass(new BypassBox(new string[2]
			{
				"Height: 1f",
				"Height: 2f"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			switch (bypasses[0].curIndex)
			{
			case 0:
				Game.stepHeight = 1f;
				break;
			case 1:
				Game.stepHeight = 2f;
				break;
			}
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.stepHeight = 0.5f;
		}
	}
}
