using Trero.ClientBase;

namespace Trero.Modules
{
	internal class Nofriends : Module
	{
		public Nofriends()
			: base("Nofriends", '\a', "Other", "Ignore all friends, just like you irl!")
		{
		}

		public override void OnEnable()
		{
			Game.CustomDefines.nofriends = true;
			base.OnEnable();
		}

		public override void OnDisable()
		{
			Game.CustomDefines.nofriends = false;
			base.OnDisable();
		}
	}
}
