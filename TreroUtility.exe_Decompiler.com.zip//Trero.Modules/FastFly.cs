using System;
using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class FastFly : Module
	{
		private int a;

		public FastFly()
			: base("FastFly", '\a', "Flies", "Bypassing fly made for mineplex & lifeboat (Speed 4 recm)")
		{
			addBypass(new BypassBox(new string[3]
			{
				"UpTeleport: 0.5f",
				"UpTeleport: 1f",
				"UpTeleport: None"
			}));
			addBypass(new BypassBox(new string[5]
			{
				"Speed: 2f",
				"Speed: 3f",
				"Speed: 4f",
				"Speed: 5f",
				"Speed: 1f"
			}));
			addBypass(new BypassBox(new string[2]
			{
				"FreezeOnDisable: True",
				"FreezeOnDisable: False"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			Vector3 position = Game.position;
			switch (bypasses[0].curIndex)
			{
			case 0:
				position.y += 0.5f;
				break;
			case 1:
				position.y += 1f;
				break;
			}
			Game.teleport(position);
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				a++;
				float num = 2f;
				switch (bypasses[1].curIndex)
				{
				case 0:
					num = 2f;
					break;
				case 1:
					num = 3f;
					break;
				case 2:
					num = 4f;
					break;
				case 3:
					num = 5f;
					break;
				case 4:
					num = 1f;
					break;
				}
				float num2 = (Game.bodyRots.y + 90f) * ((float)Math.PI / 180f);
				Vector3 velocity = Base.Vec3();
				velocity.x = (float)Math.Cos(num2) * num;
				velocity.y = 0.05f * num;
				velocity.z = (float)Math.Sin(num2) * num;
				Game.velocity = velocity;
				if (a == 30)
				{
					a = 0;
					Vector3 position = Game.position;
					position.y -= 1.25f;
					Game.teleport(position);
				}
			}
		}

		public override void OnDisable()
		{
			base.OnDisable();
			if (bypasses[2].curIndex == 0)
			{
				Game.velocity = Base.Vec3();
			}
		}
	}
}
