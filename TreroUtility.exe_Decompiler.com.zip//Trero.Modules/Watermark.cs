using System;
using System.Windows.Forms;
using System.Windows.Forms.Layout;
using Trero.ClientBase.UIBase;

namespace Trero.Modules
{
	internal class Watermark : Module
	{
		public Watermark()
			: base("Watermark", '\a', "Visual", "Toggle trero's annoying watermark >:c", enabled: true)
		{
		}

		public override void OnEnable()
		{
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Expected O, but got Unknown
			base.OnEnable();
			try
			{
				Overlay handle = Overlay.handle;
				object obj = _003C_003Ec._003C_003E9__1_0;
				if (obj == null)
				{
					MethodInvoker val = delegate
					{
						//IL_0018: Unknown result type (might be due to invalid IL or missing references)
						//IL_001e: Expected O, but got Unknown
						foreach (Control item in (ArrangedElementCollection)((Control)Overlay.handle).get_Controls())
						{
							Control val2 = item;
							if (Overlay.handle != null && (string)val2.get_Tag() == "watermark")
							{
								val2.set_Visible(true);
							}
						}
					};
					obj = (object)val;
					_003C_003Ec._003C_003E9__1_0 = val;
				}
				((Control)handle).Invoke((Delegate)obj);
			}
			catch
			{
			}
		}

		public override void OnDisable()
		{
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Expected O, but got Unknown
			base.OnDisable();
			try
			{
				Overlay handle = Overlay.handle;
				object obj = _003C_003Ec._003C_003E9__2_0;
				if (obj == null)
				{
					MethodInvoker val = delegate
					{
						//IL_0018: Unknown result type (might be due to invalid IL or missing references)
						//IL_001e: Expected O, but got Unknown
						foreach (Control item in (ArrangedElementCollection)((Control)Overlay.handle).get_Controls())
						{
							Control val2 = item;
							if (Overlay.handle != null && (string)val2.get_Tag() == "watermark")
							{
								val2.set_Visible(false);
							}
						}
					};
					obj = (object)val;
					_003C_003Ec._003C_003E9__2_0 = val;
				}
				((Control)handle).Invoke((Delegate)obj);
			}
			catch
			{
			}
		}
	}
}
