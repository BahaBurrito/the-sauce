using System;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class ElytraFlight : Module
	{
		private Vector3 savedVel = Base.Vec3();

		public ElytraFlight()
			: base("ElytraFlight", '\a', "Flies", "ElytraFlight duh")
		{
			addBypass(new BypassBox(new string[4]
			{
				"Default",
				"Fast",
				"Super fast",
				"Hyper speed"
			}));
			addBypass(new BypassBox(new string[2]
			{
				"RestoreVel: False",
				"RestoreVel: True"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			if (bypasses[1].curIndex == 1)
			{
				savedVel = Game.velocity;
			}
		}

		public override void OnDisable()
		{
			base.OnDisable();
			if (bypasses[1].curIndex == 1)
			{
				Game.velocity = savedVel;
			}
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				Game.velocity = Base.Vec3(0f, 0.05f);
				if (Keymap.GetAsyncKeyState((Keys)87))
				{
					moveTick(0);
				}
				if (Keymap.GetAsyncKeyState((Keys)65))
				{
					moveTick(55);
				}
				if (Keymap.GetAsyncKeyState((Keys)83))
				{
					moveTick(110);
				}
				if (Keymap.GetAsyncKeyState((Keys)68))
				{
					moveTick(-55);
				}
				if (Keymap.GetAsyncKeyState((Keys)160) || Keymap.GetAsyncKeyState((Keys)161))
				{
					Game.velocity = Base.Vec3(0f, 1f);
				}
			}
		}

		private void moveTick(int offset)
		{
			Vector3 velocity = Game.velocity;
			float num = (Game.bodyRots.y + 89.9f) * ((float)Math.PI / 180f);
			num += (float)offset;
			int num2 = 4;
			switch (bypasses[0].curIndex)
			{
			case 0:
				num2 = 4;
				break;
			case 1:
				num2 = 6;
				break;
			case 2:
				num2 = 10;
				break;
			case 3:
				num2 = 18;
				break;
			}
			velocity.z = (float)Math.Sin(num) * ((float)num2 / 9f);
			velocity.x = (float)Math.Cos(num) * ((float)num2 / 9f);
			Game.velocity = velocity;
		}
	}
}
