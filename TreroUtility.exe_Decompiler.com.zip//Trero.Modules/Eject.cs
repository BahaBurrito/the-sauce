using System.Windows.Forms;

namespace Trero.Modules
{
	internal class Eject : Module
	{
		public Eject()
			: base("Eject", '\a', "Other", "Eject the client ui")
		{
		}

		public override void OnEnable()
		{
			Program.quit = true;
			Application.Exit();
		}
	}
}
