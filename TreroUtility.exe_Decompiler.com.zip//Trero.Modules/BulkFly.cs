using System;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.VersionBase;

namespace Trero.Modules
{
	internal class BulkFly : Module
	{
		private static int _flicker;

		public BulkFly()
			: base("BulkFly", '\a', "Flies", "Shitty fly :yawning_face:")
		{
		}

		public override void OnTick()
		{
			if (Game.isNull)
			{
				return;
			}
			_flicker++;
			Vector3 velocity = Base.Vec3();
			_ = Game.bodyRots;
			velocity.y = -0.05f;
			switch (_flicker)
			{
			case 11:
			{
				Vector3 position2 = Game.position;
				position2.y += 0.006f;
				position2.z += 0.003f;
				position2.x += 0.003f;
				if (Keymap.GetAsyncKeyState('\u00a0'))
				{
					position2.y -= 0.006f;
				}
				if (Keymap.GetAsyncKeyState(' '))
				{
					position2.y += 0.08f;
				}
				Game.position = position2;
				break;
			}
			case 22:
			{
				Vector3 position = Game.position;
				position.y -= 0.003f;
				position.z -= 0.003f;
				position.x -= 0.003f;
				Game.position = position;
				break;
			}
			}
			if (_flicker == 11)
			{
				_flicker = 0;
			}
			Game.velocity = velocity;
			float num = Game.bodyRots.y;
			if (Keymap.GetAsyncKeyState((Keys)87))
			{
				if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
				{
					num += 90f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)65))
				{
					num += 45f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)68))
				{
					num += 135f;
				}
			}
			else if (Keymap.GetAsyncKeyState((Keys)83))
			{
				if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
				{
					num -= 90f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)65))
				{
					num -= 45f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)68))
				{
					num -= 135f;
				}
			}
			else if (!Keymap.GetAsyncKeyState((Keys)87) && !Keymap.GetAsyncKeyState((Keys)83) && !Keymap.GetAsyncKeyState((Keys)65) && Keymap.GetAsyncKeyState((Keys)68))
			{
				num += 180f;
			}
			if (Keymap.GetAsyncKeyState((Keys)87) | Keymap.GetAsyncKeyState((Keys)65) | Keymap.GetAsyncKeyState((Keys)83) | Keymap.GetAsyncKeyState((Keys)68))
			{
				float num2 = num * ((float)Math.PI / 180f);
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity"), (float)Math.Cos(num2) * 0.7f);
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 8, (float)Math.Sin(num2) * 0.7f);
			}
		}
	}
}
