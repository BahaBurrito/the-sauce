using System;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;

namespace Trero.Modules
{
	internal class Tower : Module
	{
		public Tower()
			: base("Tower", '\a', "World", "Hold right click to automatically build upwards")
		{
			Keymap.keyEvent = (EventHandler<KeyEvent>)Delegate.Combine(Keymap.keyEvent, new EventHandler<KeyEvent>(keyPress));
		}

		private void keyPress(object sender, KeyEvent e)
		{
			//IL_0012: Unknown result type (might be due to invalid IL or missing references)
			if (e.vkey == VKeyCodes.KeyHeld && enabled && (ushort)e.key == 2)
			{
				Game.Placing = 0;
				OverrideBase.Pitch = false;
				Vector2 bodyRots = Game.bodyRots;
				bodyRots.x = 90f;
				Game.bodyRots = bodyRots;
				Game.velocity = Base.Vec3(0f, 0.25f);
			}
			if (e.vkey == VKeyCodes.KeyUp)
			{
				OverrideBase.Pitch = true;
			}
		}
	}
}
