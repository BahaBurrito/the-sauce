using Trero.ClientBase;

namespace Trero.Modules
{
	internal class NoSwing : Module
	{
		public NoSwing()
			: base("NoSwing", '\a', "Visual", "Remove the swinging animation")
		{
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				Game.swingAn = 0;
			}
		}
	}
}
