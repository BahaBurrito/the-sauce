using System.Windows.Forms;
using System.Windows.Forms.Layout;
using Trero.ClientBase.UIBase;

namespace Trero.Modules
{
	internal class ClosestPlayerDisplay : Module
	{
		public ClosestPlayerDisplay()
			: base("ClosestPlayerDisplay", '\a', "Visual", "Display the closest players information")
		{
		}

		public override void OnEnable()
		{
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Expected O, but got Unknown
			base.OnEnable();
			foreach (Control item in (ArrangedElementCollection)((Control)Overlay.handle).get_Controls())
			{
				Control val = item;
				if (val.get_Name() == "panel3")
				{
					val.set_Visible(true);
				}
			}
		}

		public override void OnDisable()
		{
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Expected O, but got Unknown
			base.OnDisable();
			foreach (Control item in (ArrangedElementCollection)((Control)Overlay.handle).get_Controls())
			{
				Control val = item;
				if (val.get_Name() == "panel3")
				{
					val.set_Visible(false);
				}
			}
		}
	}
}
