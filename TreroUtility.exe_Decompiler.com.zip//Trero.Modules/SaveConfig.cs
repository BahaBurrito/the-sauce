using System.Collections.Generic;
using System.IO;
using System.Web.Script.Serialization;
using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class SaveConfig : Module
	{
		public SaveConfig()
			: base("SaveConfig", '\a', "Other", "Save your current client config as a config.json file!")
		{
		}

		public override void OnEnable()
		{
			//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
			ConfigIO configIO = new ConfigIO();
			foreach (Module module in Program.Modules)
			{
				configIO.enableStates.Add(module.enabled);
				configIO.moduleKeybinds.Add(module.keybind);
				List<int> list = new List<int>();
				foreach (BypassBox bypass in module.bypasses)
				{
					list.Add(bypass.curIndex);
				}
				configIO.moduleBypasses.Add(list);
				configIO.moduleNames.Add(module.name);
			}
			string text = new JavaScriptSerializer().Serialize((object)configIO);
			File.WriteAllText("config.json", text);
		}
	}
}
