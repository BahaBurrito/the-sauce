using Trero.ClientBase;
using Trero.ClientBase.EntityBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Sexaura : Module
	{
		public Sexaura()
			: base("Sexaura", '\a', "World", "Tp around the closest players head")
		{
			addBypass(new BypassBox(new string[2]
			{
				"Mobaura: False",
				"Mobaura: True"
			}));
			addBypass(new BypassBox(new string[2]
			{
				"Plus 0.3",
				"Plus 0.5"
			}));
			addBypass(new BypassBox(new string[2]
			{
				"Plus 1",
				"Plus 1.5"
			}));
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				float width = 0.3f;
				float height = 1f;
				if (bypasses[0].curIndex == 0)
				{
					width = 0.3f;
				}
				if (bypasses[0].curIndex == 1)
				{
					width = 0.5f;
				}
				if (bypasses[1].curIndex == 0)
				{
					height = 1f;
				}
				if (bypasses[1].curIndex == 1)
				{
					height = 1.5f;
				}
				Actor closestPlayer = Game.getClosestPlayer();
				if (Game.position.Distance(closestPlayer.position) < 6f)
				{
					Game.SexActor(closestPlayer, width, height);
				}
			}
		}
	}
}
