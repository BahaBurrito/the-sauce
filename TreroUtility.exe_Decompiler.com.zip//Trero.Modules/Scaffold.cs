using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.VersionBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Scaffold : Module
	{
		private float savedY;

		public Scaffold()
			: base("Scaffold", '\a', "World", "Place blocks under you automatically")
		{
			addBypass(new BypassBox(new string[3]
			{
				"Speed: Default",
				"Speed: 1",
				"Speed: 2"
			}));
			addBypass(new BypassBox(new string[2]
			{
				"Place Mode: Auto ",
				"Place Mode: Manual"
			}));
			addBypass(new BypassBox(new string[2]
			{
				"AntiFall: true",
				"AntiFall: false"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			savedY = Game.position.y;
			MCM.freezeBytes(Game.level + VersionClass.GetData("SelectedBlock") + 4, MCM.int2Bytes((int)Game.position.y - 1));
		}

		public override void OnDisable()
		{
			base.OnDisable();
			OverrideBase.lookingAtBlock = true;
			MCM.unfreezeBytes(Game.level + VersionClass.GetData("SelectedBlock") + 4);
		}

		public override void OnTick()
		{
			base.OnTick();
			if (!MCM.isGameFocused())
			{
				return;
			}
			Game.isLookingAtBlock = 0;
			iVector3 exactPos = Game.exactPos;
			exactPos.y = (int)savedY - 1;
			if (exactPos.y != (int)savedY - 2)
			{
				Game.SelectedBlock = exactPos;
			}
			Game.SideSelect = 1;
			if (bypasses[2].curIndex == 0 && Game.position.y < (float)(int)savedY)
			{
				if (Game.heldItemCount == 0)
				{
					Game.velocity = Base.Vec3();
				}
				else
				{
					Game.onGround = true;
					Game.velocity = Base.Vec3();
					Game.velocity = Base.Vec3(0f, 0.3f);
				}
			}
			float num = 0f;
			switch (bypasses[0].curIndex)
			{
			case 0:
				num = 0f;
				break;
			case 1:
				num = 0.13f;
				break;
			case 2:
				num = 0.16f;
				break;
			}
			if (num != 0f)
			{
				Game.speed = num;
			}
			Game.Placing = 0;
			if (bypasses[1].curIndex == 0 && MCM.isGameFocused())
			{
				Mouse.MouseEvent(Mouse.MouseEventFlags.MOUSEEVENTF_RIGHTDOWN);
			}
		}
	}
}
