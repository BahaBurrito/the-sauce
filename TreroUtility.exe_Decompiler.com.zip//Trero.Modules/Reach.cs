using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Reach : Module
	{
		public Reach()
			: base("Reach", '\a', "Combat", "Attack reach distance")
		{
			addBypass(new BypassBox(new string[4]
			{
				"Distance: 4",
				"Distance: 5",
				"Distance: 6",
				"Distance: 7"
			}));
		}

		public override void OnEnable()
		{
			switch (bypasses[0].curIndex)
			{
			case 0:
				MCM.writeBaseFloat(57006152, 4f);
				break;
			case 1:
				MCM.writeBaseFloat(57006152, 5f);
				break;
			case 2:
				MCM.writeBaseFloat(57006152, 6f);
				break;
			case 3:
				MCM.writeBaseFloat(57006152, 7f);
				break;
			}
			base.OnEnable();
		}

		public override void OnDisable()
		{
			MCM.writeBaseFloat(57006152, 3f);
			base.OnDisable();
		}
	}
}
