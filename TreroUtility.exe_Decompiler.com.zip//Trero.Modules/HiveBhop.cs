using System;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.VersionBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class HiveBhop : Module
	{
		private int jumpDelay;

		public HiveBhop()
			: base("HiveBhop", '\a', "Player", "Bhop created for hide")
		{
			addBypass(new BypassBox(new string[3]
			{
				"Speed: Slow",
				"Speed: Normal",
				"Speed: Fast"
			}));
		}

		public override void OnTick()
		{
			if (Game.isNull)
			{
				return;
			}
			if (!Game.onGround2)
			{
				Vector3 velocity = Game.velocity;
				float num = (Game.bodyRots.y + 89.9f) * ((float)Math.PI / 180f);
				if (Keymap.GetAsyncKeyState((Keys)87) || Keymap.GetAsyncKeyState((Keys)65) || Keymap.GetAsyncKeyState((Keys)83) || Keymap.GetAsyncKeyState((Keys)68))
				{
					if (Keymap.GetAsyncKeyState((Keys)65))
					{
						num += 55f;
					}
					if (Keymap.GetAsyncKeyState((Keys)83))
					{
						num += 110f;
					}
					if (Keymap.GetAsyncKeyState((Keys)68))
					{
						num -= 55f;
					}
					int num2 = 3;
					switch (bypasses[0].curIndex)
					{
					case 0:
						num2 = 3;
						break;
					case 1:
						num2 = 5;
						break;
					case 2:
						num2 = 7;
						break;
					}
					velocity.z = (float)Math.Sin(num) * ((float)num2 / 9f);
					velocity.x = (float)Math.Cos(num) * ((float)num2 / 9f);
					Game.velocity = velocity;
					if (jumpDelay != 0)
					{
						jumpDelay = 0;
					}
				}
			}
			else if (Keymap.GetAsyncKeyState((Keys)87) || Keymap.GetAsyncKeyState((Keys)65) || Keymap.GetAsyncKeyState((Keys)83) || Keymap.GetAsyncKeyState((Keys)68))
			{
				jumpDelay++;
				if (jumpDelay == 2)
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, 0.31f);
				}
			}
		}
	}
}
