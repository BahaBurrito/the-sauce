using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Microsoft.VisualBasic;
using Trero.ClientBase;
using Trero.ClientBase.EntityBase;

namespace Trero.Modules
{
	internal class PlayerTP : Module
	{
		public PlayerTP()
			: base("PlayerTP", '\a', "Exploits", "Teleport to a player of your choice")
		{
		}

		public override void OnEnable()
		{
			new Thread((ThreadStart)delegate
			{
				string username = Interaction.InputBox("Please enter player username", "Trero (PlayerTP)", "", -1, -1).ToLower();
				using IEnumerator<Actor> enumerator = Enumerable.Where<Actor>((IEnumerable<Actor>)Game.getPlayers(), (Func<Actor, bool>)((Actor entity) => entity.username.ToLower().Contains(username))).GetEnumerator();
				if (enumerator.MoveNext())
				{
					Game.position = enumerator.Current.position;
				}
			}).Start();
		}
	}
}
