using Trero.ClientBase;

namespace Trero.Modules
{
	internal class Noclip : Module
	{
		public Noclip()
			: base("Noclip", '\a', "Exploits", "Like phase but also works on the Y axis")
		{
		}

		public override void OnTick()
		{
			Vector3 position = Game.position;
			Vector3 position2 = Game.position;
			position2.x += 0.6f;
			position2.y -= 1.8f;
			position2.z += 0.6f;
			Game.teleport(new AABB(position, position2));
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.teleport(Game.position);
		}
	}
}
