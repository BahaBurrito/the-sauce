using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Timer : Module
	{
		public Timer()
			: base("Timer", '\a', "World", "Change the games internal timer")
		{
			addBypass(new BypassBox(new string[7]
			{
				"Speed: x2",
				"Speed: x3",
				"Speed: x5",
				"Speed: x0.5",
				"Speed: x0.8",
				"Speed: x0.9",
				"Speed: PinPoint"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			switch (bypasses[0].curIndex)
			{
			case 0:
				Game.timer = 40f;
				break;
			case 1:
				Game.timer = 60f;
				break;
			case 2:
				Game.timer = 100f;
				break;
			case 3:
				Game.timer = 10f;
				break;
			case 4:
				Game.timer = 16f;
				break;
			case 5:
				Game.timer = 18f;
				break;
			case 6:
				Game.timer = 19f;
				break;
			}
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.timer = 20f;
		}
	}
}
