using System;
using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class HiveFly : Module
	{
		public HiveFly()
			: base("HiveFly", '\a', "Flies", "A bypass fly with many server options")
		{
			addBypass(new BypassBox(new string[4]
			{
				"Default",
				"Hive",
				"Nethergames",
				"Mineplex"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			Vector3 position = Game.position;
			position.y += 0.25f;
			Game.teleport(position);
		}

		public override void OnTick()
		{
			if (!Game.isNull)
			{
				float num = 0.7f;
				switch (bypasses[0].curIndex)
				{
				case 0:
					num = 0.7f;
					break;
				case 1:
					num = 0.2f;
					break;
				case 2:
					num = 2f;
					break;
				case 3:
					num = 1.6f;
					break;
				}
				float num2 = (Game.bodyRots.y + 90f) * ((float)Math.PI / 180f);
				Vector3 velocity = Base.Vec3();
				velocity.x = (float)Math.Cos(num2) * num;
				velocity.z = (float)Math.Sin(num2) * num;
				Game.velocity = velocity;
				Vector3 position = Game.position;
				position.y -= 0.005f;
				Game.teleport(position);
			}
		}
	}
}
