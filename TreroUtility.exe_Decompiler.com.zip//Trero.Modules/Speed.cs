using System;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.VersionBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Speed : Module
	{
		public Speed()
			: base("Speed", '\a', "Player", "Go super fast!")
		{
			addBypass(new BypassBox(new string[2]
			{
				"Client: Trero",
				"Client: Vanilla"
			}));
			addBypass(new BypassBox(new string[3]
			{
				"Speed: 1",
				"Speed: 2",
				"Speed: 3"
			}));
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.speed = 0.1f;
		}

		public override void OnTick()
		{
			if (Game.isNull)
			{
				return;
			}
			switch (bypasses[0].curIndex)
			{
			case 0:
			{
				float num = Game.bodyRots.y;
				float num2 = 0.7f;
				switch (bypasses[1].curIndex)
				{
				case 0:
					num2 = 0.7f;
					break;
				case 1:
					num2 = 1f;
					break;
				case 2:
					num2 = 1.5f;
					break;
				}
				if (Keymap.GetAsyncKeyState((Keys)87))
				{
					if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
					{
						num += 90f;
					}
					if (Keymap.GetAsyncKeyState((Keys)65))
					{
						num += 45f;
					}
					else if (Keymap.GetAsyncKeyState((Keys)68))
					{
						num += 135f;
					}
				}
				else if (Keymap.GetAsyncKeyState((Keys)83))
				{
					if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
					{
						num -= 90f;
					}
					if (Keymap.GetAsyncKeyState((Keys)65))
					{
						num -= 45f;
					}
					else if (Keymap.GetAsyncKeyState((Keys)68))
					{
						num -= 135f;
					}
				}
				else if (!Keymap.GetAsyncKeyState((Keys)87) && !Keymap.GetAsyncKeyState((Keys)83) && !Keymap.GetAsyncKeyState((Keys)65) && Keymap.GetAsyncKeyState((Keys)68))
				{
					num += 180f;
				}
				if (Keymap.GetAsyncKeyState((Keys)87) | Keymap.GetAsyncKeyState((Keys)65) | Keymap.GetAsyncKeyState((Keys)83) | Keymap.GetAsyncKeyState((Keys)68))
				{
					float num3 = num * ((float)Math.PI / 180f);
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity"), (float)Math.Cos(num3) * num2);
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 8, (float)Math.Sin(num3) * (num2 / 5f));
				}
				break;
			}
			case 1:
				Game.speed = ((float)(bypasses[1].curIndex + 1) * 0.020000001f + 0.1f) * 2f;
				break;
			}
		}
	}
}
