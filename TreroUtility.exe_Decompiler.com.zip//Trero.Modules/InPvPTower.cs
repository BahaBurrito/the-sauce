using Trero.ClientBase;

namespace Trero.Modules
{
	internal class InPvPTower : Module
	{
		private int teleportCount;

		public InPvPTower()
			: base("InPvPTower", '\a', "World", "Break InPvP records")
		{
		}

		public override void OnTick()
		{
			switch (teleportCount)
			{
			case 0:
				Game.teleport(-246f, 52f, 910f);
				break;
			case 1:
				Game.teleport(-221f, 51f, 684f);
				break;
			default:
				teleportCount = -1;
				break;
			case 2:
			case 3:
				break;
			}
			teleportCount++;
		}
	}
}
