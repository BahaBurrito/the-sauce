using System;
using System.Windows.Forms;
using Trero.ClientBase;
using Trero.ClientBase.KeyBase;
using Trero.ClientBase.VersionBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Bhop : Module
	{
		public Bhop()
			: base("Bhop", '\a', "Exploits", "Hop around like a bunny :3")
		{
			addBypass(new BypassBox(new string[5]
			{
				"Speed: 0.7f",
				"Speed: 0.5f",
				"Speed: 0.3f",
				"Speed: 1.5f",
				"Speed: 1f"
			}));
			addBypass(new BypassBox(new string[4]
			{
				"Height: 0.3f",
				"Height: 0.2f",
				"Height: 0.1f",
				"Height: 0.05f"
			}));
		}

		public override void OnTick()
		{
			if (Game.isNull)
			{
				return;
			}
			float num = Game.bodyRots.y;
			if (Keymap.GetAsyncKeyState((Keys)87))
			{
				if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
				{
					num += 90f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)65))
				{
					num += 45f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)68))
				{
					num += 135f;
				}
			}
			else if (Keymap.GetAsyncKeyState((Keys)83))
			{
				if (!Keymap.GetAsyncKeyState((Keys)65) && !Keymap.GetAsyncKeyState((Keys)68))
				{
					num -= 90f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)65))
				{
					num -= 45f;
				}
				else if (Keymap.GetAsyncKeyState((Keys)68))
				{
					num -= 135f;
				}
			}
			else if (!Keymap.GetAsyncKeyState((Keys)87) && !Keymap.GetAsyncKeyState((Keys)83) && !Keymap.GetAsyncKeyState((Keys)65) && Keymap.GetAsyncKeyState((Keys)68))
			{
				num += 180f;
			}
			if (Keymap.GetAsyncKeyState((Keys)87) | Keymap.GetAsyncKeyState((Keys)65) | Keymap.GetAsyncKeyState((Keys)83) | Keymap.GetAsyncKeyState((Keys)68))
			{
				float num2 = num * ((float)Math.PI / 180f);
				float num3 = 0.7f;
				switch (bypasses[0].curIndex)
				{
				case 1:
					num3 = 0.5f;
					break;
				case 2:
					num3 = 0.3f;
					break;
				case 3:
					num3 = 1.5f;
					break;
				case 4:
					num3 = 1f;
					break;
				}
				float value = 0.3f;
				switch (bypasses[1].curIndex)
				{
				case 1:
					value = 0.2f;
					break;
				case 2:
					value = 0.1f;
					break;
				case 3:
					value = 0.05f;
					break;
				}
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity"), (float)Math.Cos(num2) * num3);
				if (Game.onGround2)
				{
					MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 4, value);
				}
				MCM.writeFloat(Game.localPlayer + VersionClass.GetData("velocity") + 8, (float)Math.Sin(num2) * num3);
			}
		}
	}
}
