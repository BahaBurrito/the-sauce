using Trero.ClientBase;
using Trero.Modules.vModuleExtra;

namespace Trero.Modules
{
	internal class Gamemode : Module
	{
		public Gamemode()
			: base("Gamemode", '\a', "Exploits", "Sets your gamemode to 0-1 or 2")
		{
			addBypass(new BypassBox(new string[3]
			{
				"Survival",
				"Creative",
				"Adventure"
			}));
		}

		public override void OnEnable()
		{
			base.OnEnable();
			Game.gamemode = bypasses[0].curIndex;
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Game.gamemode = 0;
		}
	}
}
